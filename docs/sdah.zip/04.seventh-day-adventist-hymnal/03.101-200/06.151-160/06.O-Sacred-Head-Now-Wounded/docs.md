---
title: 156. O Sacred Head Now Wounded - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 156. O Sacred Head Now Wounded. 1. O sacred Head, now wounded, with grief and shame weighed down, now scornfully surounded with thorns, thine only crown: how pale thou art with anguish, with sore abuse and scorn! How does that visage languish which once was bright as morn!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Sacred Head Now Wounded, O sacred Head, now wounded, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 156. O SACRED HEAD NOW WOUNDED
#### Seventh Day Adventist Hymnal

```txt



1.
O sacred Head, now wounded,
with grief and shame weighed down,
now scornfully surounded
with thorns, thine only crown:
how pale thou art with anguish,
with sore abuse and scorn!
How does that visage languish
which once was bright as morn!

2.
What thou, my Lord, has suffered
was all for sinners’ gain;
mine, mine was the transgression,
but thine the deadly pain.
Lo, here I fall, my Savior!
‘Tis I deserve thy place;
look on me with thy favor,
vouchsafe to me thy grace.

3.
What language shall I borrow
to thank thee, dearest friend,
for this thy dying sorrow,
thy pity without end?
O make me thine forever;
and should I fainting be,
Lord, let me never, never
outlive my love for thee.



```

- |   -  |
-------------|------------|
Title | O Sacred Head Now Wounded |
Key |  |
Titles | undefined |
First Line | O sacred Head, now wounded, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
