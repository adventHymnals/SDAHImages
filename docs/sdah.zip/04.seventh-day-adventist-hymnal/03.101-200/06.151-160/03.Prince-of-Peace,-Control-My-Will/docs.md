---
title: 153. Prince of Peace, Control My Will - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 153. Prince of Peace, Control My Will. 1. Prince of Peace, control my will, Bid this struggling heart be still; Bid my fears and doubtings cease, Hush my spirit into peace.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Prince of Peace, Control My Will, Prince of Peace, control my will, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 153. PRINCE OF PEACE, CONTROL MY WILL
#### Seventh Day Adventist Hymnal

```txt



1.
Prince of Peace, control my will,
Bid this struggling heart be still;
Bid my fears and doubtings cease,
Hush my spirit into peace.

2.
Thou hast bought me with Thy blood,
Opened wide the gate to God;
Peace, I ask, but peace must be,
Lord, in being one with Thee.

3.
May Thy will, not mine, be done,
May Thy will and mine be one;
Chase these doubtings from my heart,
Now Thy perfect peace impart.



```

- |   -  |
-------------|------------|
Title | Prince of Peace, Control My Will |
Key |  |
Titles | undefined |
First Line | Prince of Peace, control my will, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
