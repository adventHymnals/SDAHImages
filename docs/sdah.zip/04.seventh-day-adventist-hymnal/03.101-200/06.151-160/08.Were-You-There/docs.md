---
title: 158. Were You There? - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 158. Were You There?. 1. Were you there when they crucified my Lord? Were you there when they crucified my Lord? O! Sometimes it causes me to tremble, tremble, tremble. Were you there when they crucified my Lord?
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Were You There?, Were you there when they crucified my Lord? 
    author: Brian Onang'o
---

#### Advent Hymnals
## 158. WERE YOU THERE?
#### Seventh Day Adventist Hymnal

```txt



1.
Were you there when they crucified my Lord?
Were you there when they crucified my Lord?
O! Sometimes it causes me to tremble, tremble, tremble.
Were you there when they crucified my Lord?

2.
Were you there when they nailed Him to the tree?
Were you there when they nailed Him to the tree?
O! Sometimes it causes me to tremble, tremble, tremble.
Were you there when they nailed Him to the tree?

3.
Were you there when they pierced Him in the side?
Were you there when they pierced Him in the side?
O! Sometimes it causes me to tremble, tremble, tremble.
Were you there when they pierced Him in the side?

4.
Were you there when the sun refused to shine?
Were you there when the sun refused to shine?
O! Sometimes it causes me to tremble, tremble, tremble.
Were you there when the sun refused to shine?

5.
Were you there when they laid Him in the tomb?
Were you there when they laid Him in the tomb?
O! Sometimes it causes me to tremble, tremble, tremble.
Were you there when they laid Him in the tomb?



```

- |   -  |
-------------|------------|
Title | Were You There? |
Key |  |
Titles | undefined |
First Line | Were you there when they crucified my Lord? |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
