---
title: Seventh Day Adventist Hymnal - 151-160
metadata:
    description: |
      Seventh Day Adventist Hymnal - 151-160
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 151-160
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 151-160

# Index of Titles
# | Title                        
-- |-------------
151|[Jesus Walked This Lonesome Valley](/seventh-day-adventist-hymnal/101-200/151-160/Jesus-Walked-This-Lonesome-Valley)
152|[Tell Me the Story of Jesus](/seventh-day-adventist-hymnal/101-200/151-160/Tell-Me-the-Story-of-Jesus)
153|[Prince of Peace, Control My Will](/seventh-day-adventist-hymnal/101-200/151-160/Prince-of-Peace,-Control-My-Will)
154|[When I Survey the Wondrous Cross](/seventh-day-adventist-hymnal/101-200/151-160/When-I-Survey-the-Wondrous-Cross)
155|[When I Survey the Wondrous Cross](/seventh-day-adventist-hymnal/101-200/151-160/When-I-Survey-the-Wondrous-Cross_1)
156|[O Sacred Head Now Wounded](/seventh-day-adventist-hymnal/101-200/151-160/O-Sacred-Head-Now-Wounded)
157|[Go to Dark Gethsemane](/seventh-day-adventist-hymnal/101-200/151-160/Go-to-Dark-Gethsemane)
158|[Were You There?](/seventh-day-adventist-hymnal/101-200/151-160/Were-You-There?)
159|[The Old Rugged Cross](/seventh-day-adventist-hymnal/101-200/151-160/The-Old-Rugged-Cross)
160|[Ride On in Majesty](/seventh-day-adventist-hymnal/101-200/151-160/Ride-On-in-Majesty)