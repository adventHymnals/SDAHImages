---
title: 160. Ride On in Majesty - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 160. Ride On in Majesty. 1. Ride on! ride on in majesty! Hark, all the tribes hosanna cry; O Savior meek, pursue Thy road With palms and scattered garments strowed.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Ride On in Majesty, Ride on! ride on in majesty! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 160. RIDE ON IN MAJESTY
#### Seventh Day Adventist Hymnal

```txt



1.
Ride on! ride on in majesty!
Hark, all the tribes hosanna cry;
O Savior meek, pursue Thy road
With palms and scattered garments strowed.

2.
Ride on! ride on in majesty!
In lowly pomp ride on to die;
O Christ, Thy triumphs now begin
O’er captive death and conquered sin.

3.
Ride on! ride on in majesty!
The winged squadrons of the sky
Look down with sad and wondering eyes
To see the approaching sacrifice.

4.
Ride on! ride on in majesty!
In lowly pomp ride on to die;
Bow Thy meek head to mortal pain,
Then take, O God, Thy power and reign.



```

- |   -  |
-------------|------------|
Title | Ride On in Majesty |
Key |  |
Titles | undefined |
First Line | Ride on! ride on in majesty! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
