---
title: 155. When I Survey the Wondrous Cross - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 155. When I Survey the Wondrous Cross. 1. When I survey the wondrous cross On which the Prince of glory died, My richest gain I count but loss, And pour contempt on all my pride.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, When I Survey the Wondrous Cross, When I survey the wondrous cross 
    author: Brian Onang'o
---

#### Advent Hymnals
## 155. WHEN I SURVEY THE WONDROUS CROSS
#### Seventh Day Adventist Hymnal

```txt

1.
When I survey the wondrous cross
On which the Prince of glory died,
My richest gain I count but loss,
And pour contempt on all my pride.

2.
See, from His head, His feet,
Sorrow and love flow mingled down;
Did e’er such love and sorrow meet?
Or thorns compose so rich a crown?

3.
Since I, who was undone and lost,
Have pardon through His name and word;
Forbid it, then, that I should boast,
Save in the cross of Christ my Lord.

4.
Were the whole realm of nature mine,
That were a tribute far too small;
Love so amazing, so divine,
Demands my life, my soul, my all.

```

- |   -  |
-------------|------------|
Title | When I Survey the Wondrous Cross |
Key |  |
Titles | undefined |
First Line | When I survey the wondrous cross |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
