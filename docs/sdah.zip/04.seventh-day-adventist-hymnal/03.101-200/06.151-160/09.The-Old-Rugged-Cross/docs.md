---
title: 159. The Old Rugged Cross - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 159. The Old Rugged Cross. 1. On a hill far away stood an old rugged cross, the emblem of suffering and shame; and I love that old cross where the dearest and best for a world of lost sinners was slain. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The Old Rugged Cross, On a hill far away stood an old rugged cross, ,So I’ll cherish the old rugged cross,
    author: Brian Onang'o
---

#### Advent Hymnals
## 159. THE OLD RUGGED CROSS
#### Seventh Day Adventist Hymnal

```txt



1.
On a hill far away stood an old rugged cross,
the emblem of suffering and shame;
and I love that old cross where the dearest and best
for a world of lost sinners was slain.


Refrain:
So I’ll cherish the old rugged cross,
till my trophies at last I lay down;
I will cling to the old rugged cross,
and exchange it some day for a crown.


2.
O that old rugged cross, so despised by the world,
has a wondrous attraction for me;
for the dear Lamb of God left his glory above
to bear it to dark Calvary.


Refrain:
So I’ll cherish the old rugged cross,
till my trophies at last I lay down;
I will cling to the old rugged cross,
and exchange it some day for a crown.

3.
To that old rugged cross I will ever be true,
its shame and reproach gladly bear;
then he’ll call me some day to my home far away,
where his glory forever I’ll share.

Refrain:
So I’ll cherish the old rugged cross,
till my trophies at last I lay down;
I will cling to the old rugged cross,
and exchange it some day for a crown.




```

- |   -  |
-------------|------------|
Title | The Old Rugged Cross |
Key |  |
Titles | So I’ll cherish the old rugged cross, |
First Line | On a hill far away stood an old rugged cross, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
