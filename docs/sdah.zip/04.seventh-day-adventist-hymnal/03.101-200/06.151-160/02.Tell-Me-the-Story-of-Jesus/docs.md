---
title: 152. Tell Me the Story of Jesus - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 152. Tell Me the Story of Jesus. 1. Tell me the story of Jesus, Write on my heart every word. Tell me the story most precious, Sweetest that ever was heard. Tell how the angels in chorus, Sang as they welcomed His birth. “Glory to God in the highest! Peace and good tidings to earth.” 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Tell Me the Story of Jesus, Tell me the story of Jesus, ,Tell me the story of Jesus,
    author: Brian Onang'o
---

#### Advent Hymnals
## 152. TELL ME THE STORY OF JESUS
#### Seventh Day Adventist Hymnal

```txt



1.
Tell me the story of Jesus,
Write on my heart every word.
Tell me the story most precious,
Sweetest that ever was heard.
Tell how the angels in chorus,
Sang as they welcomed His birth.
“Glory to God in the highest!
Peace and good tidings to earth.”


Refrain:
Tell me the story of Jesus,
Write on my heart every word.
Tell me the story most precious,
Sweetest that ever was heard.


2.
Fasting alone in the desert,
Tell of the days that are past.
How for our sins He was tempted,
Yet was triumphant at last.
Tell of the years of His labor,
Tell of the sorrow He bore.
He was despised and afflicted,
Homeless, rejected and poor.


Refrain:
Tell me the story of Jesus,
Write on my heart every word.
Tell me the story most precious,
Sweetest that ever was heard.

3.
Tell of the cross where they nailed Him,
Writhing in anguish and pain.
Tell of the grave where they laid Him,
Tell how He liveth again.
Love in that story so tender,
Clearer than ever I see.
Stay, let me weep while you whisper,
Love paid the ransom for me.

Refrain:
Tell me the story of Jesus,
Write on my heart every word.
Tell me the story most precious,
Sweetest that ever was heard.




```

- |   -  |
-------------|------------|
Title | Tell Me the Story of Jesus |
Key |  |
Titles | Tell me the story of Jesus, |
First Line | Tell me the story of Jesus, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
