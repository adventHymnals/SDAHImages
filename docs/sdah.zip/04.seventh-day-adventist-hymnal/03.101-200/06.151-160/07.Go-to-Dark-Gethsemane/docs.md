---
title: 157. Go to Dark Gethsemane - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 157. Go to Dark Gethsemane. 1. Go to dark Gethsemane, Ye who feel the tempter’s power Your Redeemer’s conflict see. Watch with him one bitter hour; Turn not from his griefs away; Learn from Jesus Christ to pray.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Go to Dark Gethsemane, Go to dark Gethsemane, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 157. GO TO DARK GETHSEMANE
#### Seventh Day Adventist Hymnal

```txt



1.
Go to dark Gethsemane,
Ye who feel the tempter’s power
Your Redeemer’s conflict see.
Watch with him one bitter hour;
Turn not from his griefs away;
Learn from Jesus Christ to pray.

2.
See Him at the judgment hall,
Beaten, bound, reviled, arraigned;
See Him meekly bearing all;
Love to man His soul sustained!
Shun not suffering, shame, or loss;
Learn from him to bear the cross.

3.
Calvary’s mournful mountain climb;
There, adoring at his feet,
Mark that miracle of time,
God’s own sacrifice complete.
“It is finished!” hear him cry;
Learn from Jesus Christ to die.



```

- |   -  |
-------------|------------|
Title | Go to Dark Gethsemane |
Key |  |
Titles | undefined |
First Line | Go to dark Gethsemane, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
