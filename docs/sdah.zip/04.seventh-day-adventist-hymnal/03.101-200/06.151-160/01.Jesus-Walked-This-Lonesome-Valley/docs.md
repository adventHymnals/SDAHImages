---
title: 151. Jesus Walked This Lonesome Valley - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 151. Jesus Walked This Lonesome Valley. 1. Jesus walked this lonesome valley; He had to walk it by Himself. O nobody else could walk it for Him. He had to walk it by Himself.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Jesus Walked This Lonesome Valley, Jesus walked this lonesome valley; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 151. JESUS WALKED THIS LONESOME VALLEY
#### Seventh Day Adventist Hymnal

```txt



1.
Jesus walked this lonesome valley;
He had to walk it by Himself.
O nobody else could walk it for Him.
He had to walk it by Himself.

2.
I must go and stand my trial.
I have to stand it by myself.
O nobody else could stand it for me.
I have to stand it by myself.

3.
Jesus walked this lonesome valley;
He had to walk it by Himself.
O nobody else could walk it for Him.
He had to walk it by Himself.



```

- |   -  |
-------------|------------|
Title | Jesus Walked This Lonesome Valley |
Key |  |
Titles | undefined |
First Line | Jesus walked this lonesome valley; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
