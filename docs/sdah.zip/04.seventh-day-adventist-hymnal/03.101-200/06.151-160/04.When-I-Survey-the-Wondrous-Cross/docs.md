---
title: 154. When I Survey the Wondrous Cross - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 154. When I Survey the Wondrous Cross. 1. When I survey the wondrous cross on which the Prince of Glory died; my richest gain I count but loss, and pour contempt on all my pride.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, When I Survey the Wondrous Cross, When I survey the wondrous cross 
    author: Brian Onang'o
---

#### Advent Hymnals
## 154. WHEN I SURVEY THE WONDROUS CROSS
#### Seventh Day Adventist Hymnal

```txt



1.
When I survey the wondrous cross
on which the Prince of Glory died;
my richest gain I count but loss,
and pour contempt on all my pride.

2.
Forbid it, Lord, that I should boast,
save in the death of Christ, my God;
all the vain things that charm me most,
I sacrifice them to his blood.

3.
See, from his head, his hands, his feet,
sorrow and love flow mingled down.
Did e’er such love and sorrow meet,
or thorns compose so rich a crown.

4.
Were the whole realm of nature mine,
that were an offering far too small;
love so amazing, so divine,
demands my soul, my life, my all.



```

- |   -  |
-------------|------------|
Title | When I Survey the Wondrous Cross |
Key |  |
Titles | undefined |
First Line | When I survey the wondrous cross |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
