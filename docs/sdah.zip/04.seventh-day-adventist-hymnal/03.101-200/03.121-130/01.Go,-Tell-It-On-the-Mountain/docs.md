---
title: 121. Go, Tell It On the Mountain - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 121. Go, Tell It On the Mountain. 1. While shepherds kept their watching O’er silent flocks by night, Behold throughout the heavens There shone a holy light.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Go, Tell It On the Mountain, While shepherds kept their watching 
    author: Brian Onang'o
---

#### Advent Hymnals
## 121. GO, TELL IT ON THE MOUNTAIN
#### Seventh Day Adventist Hymnal

```txt



1.
While shepherds kept their watching
O’er silent flocks by night,
Behold throughout the heavens
There shone a holy light.

2.
The shepherds feared and trembled
When lo! Above the earth
Rang out the angel chorus
That hailed our Savior’s birth.

3.
Down in a lowly manger
The humble Christ was born,
And brought us God’s salvation
That blessed Christmas morn.



```

- |   -  |
-------------|------------|
Title | Go, Tell It On the Mountain |
Key |  |
Titles | undefined |
First Line | While shepherds kept their watching |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
