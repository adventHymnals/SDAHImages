---
title: 128. Break Forth, O Beauteous Heavenly Light - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 128. Break Forth, O Beauteous Heavenly Light. 1. Break forth, O beauteous heavenly light, And usher in the morning; Ye shepherds, shrink not with affright, But hear the angel’s warning. This Child, now weak in infancy, Our confidence and joy shall be, The power of Satan breaking, Our peace eternal making.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Break Forth, O Beauteous Heavenly Light, Break forth, O beauteous heavenly light, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 128. BREAK FORTH, O BEAUTEOUS HEAVENLY LIGHT
#### Seventh Day Adventist Hymnal

```txt



1.
Break forth, O beauteous heavenly light,
And usher in the morning;
Ye shepherds, shrink not with affright,
But hear the angel’s warning.
This Child, now weak in infancy,
Our confidence and joy shall be,
The power of Satan breaking,
Our peace eternal making.

2.
Break forth, O beauteous heavenly light,
To herald our salvation;
He stoops to earth – the God of might,
Our hope and expectation.
He comes in human flesh to dwell,
Our God with us, Immanuel,
The night of darkness ending,
Our fallen race befriending.



```

- |   -  |
-------------|------------|
Title | Break Forth, O Beauteous Heavenly Light |
Key |  |
Titles | undefined |
First Line | Break forth, O beauteous heavenly light, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
