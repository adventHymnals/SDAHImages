---
title: 127. Infant Holy, Infant Lowly - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 127. Infant Holy, Infant Lowly. 1. Infant holy, infant lowly, For His bed a cattle stall; Oxen lowing, little knowing Christ the babe is Lord of all; Swift are winging angels singing, Noels ringing, tidings bringing, Christ the babe is Lord of all, Christ the babe is Lord of all.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Infant Holy, Infant Lowly, Infant holy, infant lowly, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 127. INFANT HOLY, INFANT LOWLY
#### Seventh Day Adventist Hymnal

```txt



1.
Infant holy, infant lowly,
For His bed a cattle stall;
Oxen lowing, little knowing
Christ the babe is Lord of all;
Swift are winging angels singing,
Noels ringing, tidings bringing,
Christ the babe is Lord of all,
Christ the babe is Lord of all.

2.
Flocks were sleeping, shepherds keeping
Vigil till the morning new;
Saw the glory, heard the story,
Tidings of the gospel true;
Thus rejoicing, free from sorrow,
Praises voicing greet the morrow,
Christ the babe was born for you,
Christ the babe was born for you.



```

- |   -  |
-------------|------------|
Title | Infant Holy, Infant Lowly |
Key |  |
Titles | undefined |
First Line | Infant holy, infant lowly, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
