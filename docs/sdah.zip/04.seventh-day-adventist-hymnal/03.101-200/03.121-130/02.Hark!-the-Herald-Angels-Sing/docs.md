---
title: 122. Hark! the Herald Angels Sing - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 122. Hark! the Herald Angels Sing. 1. Hark! the herald angels sing, “Glory to the new born King, peace on earth, and mercy mild, God and sinners reconciled!” Joyful, all ye nations rise, join the triumph of the skies; with th’ angelic host proclaim, “Christ is born in Bethlehem!” Hark! the herald angels sing, “Glory to the new born King!”
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Hark! the Herald Angels Sing, Hark! the herald angels sing, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 122. HARK! THE HERALD ANGELS SING
#### Seventh Day Adventist Hymnal

```txt



1.
Hark! the herald angels sing,
“Glory to the new born King,
peace on earth, and mercy mild,
God and sinners reconciled!”
Joyful, all ye nations rise,
join the triumph of the skies;
with th’ angelic host proclaim,
“Christ is born in Bethlehem!”
Hark! the herald angels sing,
“Glory to the new born King!”

2.
Christ, by highest heaven adored;
Christ, the everlasting Lord;
late in time behold him come,
offspring of a virgin’s womb.
Veiled in flesh the Godhead see;
hail th’ incarnate Deity,
pleased with us in flesh to dwell,
Jesus, our Emmanuel.
Hark! the herald angels sing,
“Glory to the new born King!”

3.
Hail the heaven-born Prince of Peace!
Hail the Sun of Righteousness!
Light and life to all he brings,
risen with healing in his wings.
Mild he lays his glory by,
born that we no more may die,
born to raise us from the earth,
born to give us second birth.
Hark! the herald angels sing,
“Glory to the new born King!”



```

- |   -  |
-------------|------------|
Title | Hark! the Herald Angels Sing |
Key |  |
Titles | undefined |
First Line | Hark! the herald angels sing, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
