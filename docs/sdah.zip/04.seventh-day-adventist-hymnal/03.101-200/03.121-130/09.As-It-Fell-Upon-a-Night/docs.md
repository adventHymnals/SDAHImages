---
title: 129. As It Fell Upon a Night - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 129. As It Fell Upon a Night. 1. As it fell upon a night In the winter weather, Angels bright in starry height Began to sing together.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, As It Fell Upon a Night, As it fell upon a night 
    author: Brian Onang'o
---

#### Advent Hymnals
## 129. AS IT FELL UPON A NIGHT
#### Seventh Day Adventist Hymnal

```txt



1.
As it fell upon a night
In the winter weather,
Angels bright in starry height
Began to sing together.

2.
Shepherds sleeping on the plain
Woke to see the glory,
All amazed they stood and gazed
And heard the angels’ story.

3.
Unto you a child is born
In a manger lowly,
Humble, He, yet born to be
The King of Love most holy.

4.
Happy angels from afar,
Cease your singing never!
In excelsis gloria!
Forever and forever.



```

- |   -  |
-------------|------------|
Title | As It Fell Upon a Night |
Key |  |
Titles | undefined |
First Line | As it fell upon a night |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
