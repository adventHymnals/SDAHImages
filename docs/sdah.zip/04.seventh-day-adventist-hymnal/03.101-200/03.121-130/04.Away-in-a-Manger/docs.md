---
title: 124. Away in a Manger - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 124. Away in a Manger. 1. Away in a manger, no crib for a bed, The little Lord Jesus laid down his sweet head. The stars in the sky looked down where he lay, The little Lord Jesus asleep in the hay.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Away in a Manger, Away in a manger, no crib for a bed, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 124. AWAY IN A MANGER
#### Seventh Day Adventist Hymnal

```txt



1.
Away in a manger, no crib for a bed,
The little Lord Jesus laid down his sweet head.
The stars in the sky looked down where he lay,
The little Lord Jesus asleep in the hay.

2.
The cattle are lowing, the baby awakes,
But little Lord Jesus no crying he makes.
I love Thee, Lord Jesus, look down from the sky
And stay by my cradle til morning is nigh.

3.
Be near me, Lord Jesus, I ask Thee to stay
Close by me forever, and love me, I pray.
Bless all the dear children in thy tender care,
And take us to heaven, to live with Thee there.



```

- |   -  |
-------------|------------|
Title | Away in a Manger |
Key |  |
Titles | undefined |
First Line | Away in a manger, no crib for a bed, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
