---
title: 123. As With Gladness Men of Old - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 123. As With Gladness Men of Old. 1. As with gladness men of old Did the guiding star behold, As with joy they hailed its light, Leading onward, beaming bright, So, most gracious Lord, may we Evermore be led to Thee.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, As With Gladness Men of Old, As with gladness men of old 
    author: Brian Onang'o
---

#### Advent Hymnals
## 123. AS WITH GLADNESS MEN OF OLD
#### Seventh Day Adventist Hymnal

```txt



1.
As with gladness men of old
Did the guiding star behold,
As with joy they hailed its light,
Leading onward, beaming bright,
So, most gracious Lord, may we
Evermore be led to Thee.

2.
As with joyful steps they sped
To that lowly manger bed,
There to bend the knee before
Him whom heav’n and earth adore,
So may we with willing feet
Ever seek Thy mercy seat.

3.
As they offered gifts most rare
At that manger rude and bare,
So may we with holy joy,
Pure, and free from sin’s alloy,
All our costliest treasures bring,
Christ, to Thee our heav’nly King.

4.
Holy Jesus, every day
Keep us in the narrow way;
And, when earthly things are past,
Bring our ransomed souls at last
Where they need no star to guide,
Where no clouds Thy glory hide.



```

- |   -  |
-------------|------------|
Title | As With Gladness Men of Old |
Key |  |
Titles | undefined |
First Line | As with gladness men of old |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
