---
title: 126. In the Bleak Midwinter - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 126. In the Bleak Midwinter. 1. In the bleak midwinter Frosty wind made moan; Earth stood hard as iron, Water like a stone; Snow had fallen, snow on snow, Snow on snow, In the bleak midwinter, Long ago.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, In the Bleak Midwinter, In the bleak midwinter 
    author: Brian Onang'o
---

#### Advent Hymnals
## 126. IN THE BLEAK MIDWINTER
#### Seventh Day Adventist Hymnal

```txt



1.
In the bleak midwinter
Frosty wind made moan;
Earth stood hard as iron,
Water like a stone;
Snow had fallen, snow on snow,
Snow on snow,
In the bleak midwinter,
Long ago.

2.
Angels and archangels
May have gathered there,
Cherubim and seraphim
Thronged the air:
But His mother only
In her maiden bliss,
Worshipped the beloved
With a kiss.

3.
What can I give Him,
Poor as I am?
If I were a shepherd
I would bring a lamb;
If I were a wise man
I would do my part;
Yet what can I give Him?
Give my heart.



```

- |   -  |
-------------|------------|
Title | In the Bleak Midwinter |
Key |  |
Titles | undefined |
First Line | In the bleak midwinter |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
