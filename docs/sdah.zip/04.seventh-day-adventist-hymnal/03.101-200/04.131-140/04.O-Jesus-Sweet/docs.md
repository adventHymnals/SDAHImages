---
title: 134. O Jesus Sweet - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 134. O Jesus Sweet. 1. O Jesus sweet, O Jesus mild, Thy Father’s will hast Thou fulfilled; For Thou hast left Thy heavenly throne Our lowly state to make Thine own. O Jesus sweet, O Jesus mild.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Jesus Sweet, O Jesus sweet, O Jesus mild, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 134. O JESUS SWEET
#### Seventh Day Adventist Hymnal

```txt



1.
O Jesus sweet, O Jesus mild,
Thy Father’s will hast Thou fulfilled;
For Thou hast left Thy heavenly throne
Our lowly state to make Thine own.
O Jesus sweet, O Jesus mild.

2.
O Jesus sweet, O Jesus mild,
With joy hast Thou the whole world filled;
Thou comest down from heaven’s hall
To comfort us whom tears enthrall.
O Jesus sweet, O Jesus mild.

3.
O Jesus sweet, O Jesus mild,
Thou art love’s image undefiled.
Inflame our hearts with love’s pure fire,
That we may share Thy heart’s desire.
O Jesus sweet, O Jesus mild.

4.
O Jesus sweet, O Jesus mild,
Help us to do as Thou hast willed.
What’er we have belongs to Thee:
O may we ever faithful be.
O Jesus sweet, O Jesus mild.



```

- |   -  |
-------------|------------|
Title | O Jesus Sweet |
Key |  |
Titles | undefined |
First Line | O Jesus sweet, O Jesus mild, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
