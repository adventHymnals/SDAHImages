---
title: 136. Good Christians, Now Rejoice - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 136. Good Christians, Now Rejoice. 1. Good Christians, now rejoice, With heart, and soul, and voice; Give ye heed to what we say: Jesus Christ is born today; Ox and ass before Him bow, And He is in the manger now. Crist is born today! Crist is born today!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Good Christians, Now Rejoice, Good Christians, now rejoice, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 136. GOOD CHRISTIANS, NOW REJOICE
#### Seventh Day Adventist Hymnal

```txt



1.
Good Christians, now rejoice,
With heart, and soul, and voice;
Give ye heed to what we say:
Jesus Christ is born today;
Ox and ass before Him bow,
And He is in the manger now.
Crist is born today!
Crist is born today!

2.
Good Christians, now rejoice,
With heart, and soul, and voice;
Now ye hear of endless bliss:
Jesus Christ was born for this!
He hath ope’d the heav’nly door,
And we are blessed evermore.
Christ was born for this!
Christ was born for this!

3.
Good Christians, now rejoice,
With heart, and soul, and voice;
Now ye need not fear the grave:
Jesus Christ was born to save!
Calls you one and calls you all
To gain His everlasting hall.
Christ was born to save!
Christ was born to save!



```

- |   -  |
-------------|------------|
Title | Good Christians, Now Rejoice |
Key |  |
Titles | undefined |
First Line | Good Christians, now rejoice, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
