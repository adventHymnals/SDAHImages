---
title: 137. We Three Kings - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 137. We Three Kings. 1. We three kings of Orient are; Bearing gifts we traverse afar Field and fountain, moor and mountain, Following yonder star. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, We Three Kings, We three kings of Orient are; ,O star of wonder, star of night,
    author: Brian Onang'o
---

#### Advent Hymnals
## 137. WE THREE KINGS
#### Seventh Day Adventist Hymnal

```txt



1.
We three kings of Orient are;
Bearing gifts we traverse afar
Field and fountain, moor and mountain,
Following yonder star.


Refrain:
O star of wonder, star of night,
Star with royal beauty bright,
Westward leading, still proceeding,
Guide us to Thy perfect light.


2.
Born a King on Bethlehem’s plain,
Gold I bring to crown Him again,
King forever, ceasing never
Over us all to reign.


Refrain:
O star of wonder, star of night,
Star with royal beauty bright,
Westward leading, still proceeding,
Guide us to Thy perfect light.

3.
Frankincense to offer have I;
Incense owns a Deity nigh;
Prayer and praising all men raising,
Worship Him, God on high.


Refrain:
O star of wonder, star of night,
Star with royal beauty bright,
Westward leading, still proceeding,
Guide us to Thy perfect light.

4.
Myrrh is mine; its bitter perfume
Breathes a life of gathering gloom:
Sorrowing, sighing, bleeding, dying,
Sealed in the stonecold tomb.


Refrain:
O star of wonder, star of night,
Star with royal beauty bright,
Westward leading, still proceeding,
Guide us to Thy perfect light.

5.
Glorious now behold Him arise,
King and God and sacrifice;
Alleluia, Alleluia!
Sounds through the earth and skies.

Refrain:
O star of wonder, star of night,
Star with royal beauty bright,
Westward leading, still proceeding,
Guide us to Thy perfect light.




```

- |   -  |
-------------|------------|
Title | We Three Kings |
Key |  |
Titles | O star of wonder, star of night, |
First Line | We three kings of Orient are; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
