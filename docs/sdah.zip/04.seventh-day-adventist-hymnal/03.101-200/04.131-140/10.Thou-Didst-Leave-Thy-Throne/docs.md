---
title: 140. Thou Didst Leave Thy Throne - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 140. Thou Didst Leave Thy Throne. 1. Thou didst leave Thy throne And Thy kingly crown When Thou camest to earth for me; But in Bethlehem’s home Was there found no room For Thy holy nativity. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Thou Didst Leave Thy Throne, Thou didst leave Thy throne ,O come to my heart, Lord Jesus,
    author: Brian Onang'o
---

#### Advent Hymnals
## 140. THOU DIDST LEAVE THY THRONE
#### Seventh Day Adventist Hymnal

```txt



1.
Thou didst leave Thy throne
And Thy kingly crown
When Thou camest to earth for me;
But in Bethlehem’s home
Was there found no room
For Thy holy nativity.


Refrain:
O come to my heart, Lord Jesus,
There is room in my heart for Thee.


2.
Heaven’s arches rang
When the angels sang
Proclaiming Thy royal degree;
But of lowly birth
Didst Thou come to earth,
And in greatest humility.


Refrain:
O come to my heart, Lord Jesus,
There is room in my heart for Thee.

3.
The foxes found rest,
And the birds their nest
In the shade of the forest tree;
But Thy couch was the sod,
O Thou Son of God,
In the deserts of Galilee.


Refrain:
O come to my heart, Lord Jesus,
There is room in my heart for Thee.

4.
Thou camest, O Lord,
With the living word
That should set Thy people free;
But with mocking scorn,
And with crown of thorn,
They bore Thee to Calvary.


Refrain:
O come to my heart, Lord Jesus,
There is room in my heart for Thee.

5.
When the heavens shall ring,
And the angels sing,
At Thy coming to victory,
Let Thy voice call me home,
Saying, “Yet there is room,
There is room at My side for thee.”


Refrain:
O come to my heart, Lord Jesus,
There is room in my heart for Thee.

Refrain:
My heart shall rejoice, Lord Jesus,
When Thou comest and callest for me.



```

- |   -  |
-------------|------------|
Title | Thou Didst Leave Thy Throne |
Key |  |
Titles | O come to my heart, Lord Jesus, |
First Line | Thou didst leave Thy throne |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
