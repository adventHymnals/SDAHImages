---
title: Seventh Day Adventist Hymnal - 131-140
metadata:
    description: |
      Seventh Day Adventist Hymnal - 131-140
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 131-140
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 131-140

# Index of Titles
# | Title                        
-- |-------------
131|[Lo, How a Rose E\`er Blooming](/seventh-day-adventist-hymnal/101-200/131-140/Lo,-How-a-Rose-E`er-Blooming)
132|[O Come, All Ye Faithful](/seventh-day-adventist-hymnal/101-200/131-140/O-Come,-All-Ye-Faithful)
133|[Now Is Born the Divine Christ Child](/seventh-day-adventist-hymnal/101-200/131-140/Now-Is-Born-the-Divine-Christ-Child)
134|[O Jesus Sweet](/seventh-day-adventist-hymnal/101-200/131-140/O-Jesus-Sweet)
135|[O Little Town of Bethlehem](/seventh-day-adventist-hymnal/101-200/131-140/O-Little-Town-of-Bethlehem)
136|[Good Christians, Now Rejoice](/seventh-day-adventist-hymnal/101-200/131-140/Good-Christians,-Now-Rejoice)
137|[We Three Kings](/seventh-day-adventist-hymnal/101-200/131-140/We-Three-Kings)
138|[Rise Up, Shepherd, and Follow](/seventh-day-adventist-hymnal/101-200/131-140/Rise-Up,-Shepherd,-and-Follow)
139|[While Shepherds Watched Their Flocks](/seventh-day-adventist-hymnal/101-200/131-140/While-Shepherds-Watched-Their-Flocks)
140|[Thou Didst Leave Thy Throne](/seventh-day-adventist-hymnal/101-200/131-140/Thou-Didst-Leave-Thy-Throne)