---
title: 138. Rise Up, Shepherd, and Follow - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 138. Rise Up, Shepherd, and Follow. 1. There’s a star in the east on Christmas morn. Rise up, shepherd, and follow. It will lead to the place and where the Saviour’s born, Rise up, shepherd, and follow. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Rise Up, Shepherd, and Follow, There’s a star in the east on Christmas morn. ,Leave your sheep and leave your lambs,
    author: Brian Onang'o
---

#### Advent Hymnals
## 138. RISE UP, SHEPHERD, AND FOLLOW
#### Seventh Day Adventist Hymnal

```txt



1.
There’s a star in the east on Christmas morn.
Rise up, shepherd, and follow.
It will lead to the place and where the Saviour’s born,
Rise up, shepherd, and follow.


Refrain:
Leave your sheep and leave your lambs,
Rise up, shepherd, and follow.
Leave your ewes and leave your rams,
Rise up, shepherd, and follow.
Follow, follow,
Rise up shepherd, and follow.
Follow the star of Bethlehem,
Rise up, shepherd, and follow.


2.
If you take good heed to the angel’s words,
Rise up, shepherd, and follow.
You’ll forget your flocks,
you’ll forget your herds,
Rise up, shepherd, and follow.

Refrain:
Leave your sheep and leave your lambs,
Rise up, shepherd, and follow.
Leave your ewes and leave your rams,
Rise up, shepherd, and follow.
Follow, follow,
Rise up shepherd, and follow.
Follow the star of Bethlehem,
Rise up, shepherd, and follow.




```

- |   -  |
-------------|------------|
Title | Rise Up, Shepherd, and Follow |
Key |  |
Titles | Leave your sheep and leave your lambs, |
First Line | There’s a star in the east on Christmas morn. |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
