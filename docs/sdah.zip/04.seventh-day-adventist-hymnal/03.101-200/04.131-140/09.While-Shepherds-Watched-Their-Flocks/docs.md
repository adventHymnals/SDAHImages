---
title: 139. While Shepherds Watched Their Flocks - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 139. While Shepherds Watched Their Flocks. 1. While shepherds watched their flocks by night, All seated on the ground, The angel of the Lord came down, And glory shone around.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, While Shepherds Watched Their Flocks, While shepherds watched their flocks by night, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 139. WHILE SHEPHERDS WATCHED THEIR FLOCKS
#### Seventh Day Adventist Hymnal

```txt



1.
While shepherds watched their flocks by night,
All seated on the ground,
The angel of the Lord came down,
And glory shone around.

2.
“Fear nor!” said he- for mighty dread
Had seized their troubled mind-
“Glad tidings of great joy I bring,
To you and all mankind.

3.
“To you, in David’s town this day,
Is born of David’s line,
The Savior who is Christ the Lord;
And this shall be the sign:

4.
“The heavenly Babe you there shall find
To human view displayed,
All meanly wrapped in swathing bands,
And in a manger laid.”

5.
Thus spake the seraph; and forth with
Appeared a shining throng
Of angels praising God on high,
Who thus addressed their song:

6.
“All glory be to God on high,
And to the earth be peace;
Good will henceforth from heaven to men,
Begin and never cease!”



```

- |   -  |
-------------|------------|
Title | While Shepherds Watched Their Flocks |
Key |  |
Titles | undefined |
First Line | While shepherds watched their flocks by night, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
