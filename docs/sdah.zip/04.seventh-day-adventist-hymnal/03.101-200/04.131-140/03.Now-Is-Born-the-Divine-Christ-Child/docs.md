---
title: 133. Now Is Born the Divine Christ Child - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 133. Now Is Born the Divine Christ Child. 1. He was born in a stable bare, On bed of straw how He sleeps so soundly, He was born in a stable bare, Let us worship and to Him bow.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Now Is Born the Divine Christ Child, He was born in a stable bare, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 133. NOW IS BORN THE DIVINE CHRIST CHILD
#### Seventh Day Adventist Hymnal

```txt



1.
He was born in a stable bare,
On bed of straw how He sleeps so soundly,
He was born in a stable bare,
Let us worship and to Him bow.

2.
Ages long since are past and gone,
When the wise men foretold His coming,
Ages long since are past and gone,
When the wise men foretold His birth.



```

- |   -  |
-------------|------------|
Title | Now Is Born the Divine Christ Child |
Key |  |
Titles | undefined |
First Line | He was born in a stable bare, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
