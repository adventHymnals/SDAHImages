---
title: 111. It Took a Miracle - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 111. It Took a Miracle. 1. My Father is omnipotent And that you can’t deny; A God of might and miracles; ‘Tis written in the sky. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, It Took a Miracle, My Father is omnipotent ,It took a miracle to put the stars in place;
    author: Brian Onang'o
---

#### Advent Hymnals
## 111. IT TOOK A MIRACLE
#### Seventh Day Adventist Hymnal

```txt



1.
My Father is omnipotent
And that you can’t deny;
A God of might and miracles;
‘Tis written in the sky.


Refrain:
It took a miracle to put the stars in place;
It took a miracle to hang the world in space.
But when He saved my soul,
Cleansed and made me whole,
It took a miracle of love and grace!


2.
Though here His glory has been shown,
We still can’t fully see
The wonders of His might, His throne;
‘Till eternity.


Refrain:
It took a miracle to put the stars in place;
It took a miracle to hang the world in space.
But when He saved my soul,
Cleansed and made me whole,
It took a miracle of love and grace!

3.
The Bible tells us of His power
And wisdom all way through;
And every little bird and flower
Are testimonies, too.

Refrain:
It took a miracle to put the stars in place;
It took a miracle to hang the world in space.
But when He saved my soul,
Cleansed and made me whole,
It took a miracle of love and grace!




```

- |   -  |
-------------|------------|
Title | It Took a Miracle |
Key |  |
Titles | It took a miracle to put the stars in place; |
First Line | My Father is omnipotent |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
