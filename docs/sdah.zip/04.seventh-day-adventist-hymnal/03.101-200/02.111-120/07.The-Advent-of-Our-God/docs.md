---
title: 117. The Advent of Our God - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 117. The Advent of Our God. 1. The advent of our God With eager prayers we greet, And singing haste upon His road His coming reign to meet.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The Advent of Our God, The advent of our God 
    author: Brian Onang'o
---

#### Advent Hymnals
## 117. THE ADVENT OF OUR GOD
#### Seventh Day Adventist Hymnal

```txt



1.
The advent of our God
With eager prayers we greet,
And singing haste upon His road
His coming reign to meet.

2.
The everlasting Son
Was born to make us free;
And He a servant’s form put on
To gain our liberty.

3.
As Judge, on clouds of light,
He soon will come again,
His scattered people to unite
With them in heaven to reign.

4.
Praise to the incarnate Son
Who comes to set us free,
With Father, Spirit, ever one,
To all eternity.



```

- |   -  |
-------------|------------|
Title | The Advent of Our God |
Key |  |
Titles | undefined |
First Line | The advent of our God |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
