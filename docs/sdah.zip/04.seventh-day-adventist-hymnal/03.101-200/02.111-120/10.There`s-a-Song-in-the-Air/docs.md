---
title: 120. There`s a Song in the Air - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 120. There`s a Song in the Air. 1. There’s a song in the air! There’s a star in the sky! There’s a mother’s deep prayer And a baby’s low cry! And the star rains its fire while the beautiful sing, For the manger of Bethlehem cradles a King!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, There`s a Song in the Air, There’s a song in the air! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 120. THERE`S A SONG IN THE AIR
#### Seventh Day Adventist Hymnal

```txt



1.
There’s a song in the air!
There’s a star in the sky!
There’s a mother’s deep prayer
And a baby’s low cry!
And the star rains its fire
while the beautiful sing,
For the manger of Bethlehem
cradles a King!

2.
There’s a tumult of joy
O’er the wonderful birth,
For the virgin’s sweet boy
Is the Lord of the earth.
Aye! the star rains its fire
while the beautiful sing,
For the manger of Bethlehem
cradles a King!

3.
In the light of that star
Lie the ages impearled;
And that song from afar
Has swept over the world.
Every hearth is aflame
and the beautiful sing
In the homes of the nations
that Jesus is King!

4.
We rejoice in the light,
And we echo the song
That comes down through the night
From the heavenly throng.
Aye! we shout to the lovely evangel they bring,
And we greet in His cradle
our Savior and King!



```

- |   -  |
-------------|------------|
Title | There`s a Song in the Air |
Key |  |
Titles | undefined |
First Line | There’s a song in the air! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
