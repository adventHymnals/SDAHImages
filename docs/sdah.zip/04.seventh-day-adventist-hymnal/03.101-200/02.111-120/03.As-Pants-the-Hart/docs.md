---
title: 113. As Pants the Hart - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 113. As Pants the Hart. 1. As pants the hart for cooling streams When heated in the chase, So longs my soul, O God, for Thee, And Thy refreshing grace.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, As Pants the Hart, As pants the hart for cooling streams 
    author: Brian Onang'o
---

#### Advent Hymnals
## 113. AS PANTS THE HART
#### Seventh Day Adventist Hymnal

```txt



1.
As pants the hart for cooling streams
When heated in the chase,
So longs my soul, O God, for Thee,
And Thy refreshing grace.

2.
For Thee, my God, the living God,
My thirsty soul doth pine:
O when shall I behold Thy face,
Thou Majesty divine?

3.
Why restless, why cast down, my soul?
Hope still, and thou shalt sing
The praise of Him who is thy God,
Thy health’s eternal spring.

4.
To Father, Son, and Holy Ghost,
The God whom we adore,
Be glory, as it was, is now,
And shall be evermore.



```

- |   -  |
-------------|------------|
Title | As Pants the Hart |
Key |  |
Titles | undefined |
First Line | As pants the hart for cooling streams |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
