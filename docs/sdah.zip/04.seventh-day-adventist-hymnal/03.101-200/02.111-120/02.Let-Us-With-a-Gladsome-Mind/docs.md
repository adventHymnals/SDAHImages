---
title: 112. Let Us With a Gladsome Mind - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 112. Let Us With a Gladsome Mind. 1. Let us with a gladsome mind Praise the Lord, for He is kind: For His mercies shall endure, Ever faithful, ever sure.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Let Us With a Gladsome Mind, Let us with a gladsome mind 
    author: Brian Onang'o
---

#### Advent Hymnals
## 112. LET US WITH A GLADSOME MIND
#### Seventh Day Adventist Hymnal

```txt



1.
Let us with a gladsome mind
Praise the Lord, for He is kind:
For His mercies shall endure,
Ever faithful, ever sure.

2.
He, with all commanding might,
Filled the new made world with light:
For His mercies shall endure,
Ever faithful, ever sure.

3.
All things living He does feed;
His full hand supplies their need:
For His mercies shall endure,
Ever faithful, ever sure.

4.
Let us then with gladsome mind
Praise the Lord, for He is kind:
For His mercies shall endure,
Ever faithful, ever sure.



```

- |   -  |
-------------|------------|
Title | Let Us With a Gladsome Mind |
Key |  |
Titles | undefined |
First Line | Let us with a gladsome mind |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
