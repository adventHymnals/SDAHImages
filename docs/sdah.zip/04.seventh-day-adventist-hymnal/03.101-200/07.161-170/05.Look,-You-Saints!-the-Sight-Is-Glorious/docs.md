---
title: 165. Look, You Saints! the Sight Is Glorious - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 165. Look, You Saints! the Sight Is Glorious. 1. Look, you saints, the sight is glorious, See the Man of sorrows now; From the fight returned victorious, Every knee to Him shall bow. Crown Him! Crown Him! Crown Him! Crown Him! Crown Him! Crown Him! Crowns become the victor’s brow. Crowns become the victor’s brow.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Look, You Saints! the Sight Is Glorious, Look, you saints, the sight is glorious, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 165. LOOK, YOU SAINTS! THE SIGHT IS GLORIOUS
#### Seventh Day Adventist Hymnal

```txt



1.
Look, you saints, the sight is glorious,
See the Man of sorrows now;
From the fight returned victorious,
Every knee to Him shall bow.
Crown Him! Crown Him! Crown Him!
Crown Him! Crown Him! Crown Him!
Crowns become the victor’s brow.
Crowns become the victor’s brow.

2.
Crown the Savior! angels crown Him!
Rich the trophies Jesus brings;
On the seat of power enthrone Him
While the vault of heaven rings.
Crown Him! Crown Him! Crown Him!
Crown Him! Crown Him! Crown Him!
Crown the Savior, King of Kings.
Crown the Savior, King of Kings.

3.
Sinners in derision crowned Him,
Mocking thus the Savior’s claim;
Saints and angels crowd around Him,
Own His title, praise His name.
Crown Him! Crown Him! Crown Him!
Crown Him! Crown Him! Crown Him!
Spread abroad the victor’s fame!
Spread abroad the victor’s fame!

4.
Hark! those bursts of acclamation!
Hark! those loud triumphant chords!
Jesus takes the highest station;
Oh, what joy the sight affords!
Crown Him! Crown Him! Crown Him!
Crown Him! Crown Him! Crown Him!
King of kings and Lord of lords!
King of kings and Lord of lords!



```

- |   -  |
-------------|------------|
Title | Look, You Saints! the Sight Is Glorious |
Key |  |
Titles | undefined |
First Line | Look, you saints, the sight is glorious, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
