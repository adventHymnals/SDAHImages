---
title: 166. Christ the Lord Is Risen Today - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 166. Christ the Lord Is Risen Today. 1. Christ the Lord is risen today, Alleluia! Sons of man and angels say, Alleluia! Raise your joys and triumphs high, Alleluia! Sing, ye heavens, and earth reply, Alleluia!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Christ the Lord Is Risen Today, Christ the Lord is risen today, Alleluia! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 166. CHRIST THE LORD IS RISEN TODAY
#### Seventh Day Adventist Hymnal

```txt



1.
Christ the Lord is risen today, Alleluia!
Sons of man and angels say, Alleluia!
Raise your joys and triumphs high, Alleluia!
Sing, ye heavens, and earth reply, Alleluia!

2.
Lives again our glorious King, Alleluia!
Where, O death, is now thy sting? Alleluia!
Once he died our souls to save, Alleluia!
Where’s thy victory, boasting grave? Alleluia!

3.
Love’s redeeming work is done, Alleluia!
Fought the fight, the battle won, Alleluia!
Death in vain forbids him rise, Alleluia!
Christ has opened paradise, Alleluia!

4.
Soar we now where Christ has led, Alleluia!
Following our exalted Head, Alleluia!
Made like him, like him we rise, Alleluia!
Ours the cross, the grave, the skies, Alleluia!



```

- |   -  |
-------------|------------|
Title | Christ the Lord Is Risen Today |
Key |  |
Titles | undefined |
First Line | Christ the Lord is risen today, Alleluia! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
