---
title: 163. At the Cross - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 163. At the Cross. 1. Alas! and did my Savior bleed, and did my Sovereign die? Would he devote that sacred head for sinners such as I? 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, At the Cross, Alas! and did my Savior bleed, ,At the cross, at the cross,
    author: Brian Onang'o
---

#### Advent Hymnals
## 163. AT THE CROSS
#### Seventh Day Adventist Hymnal

```txt



1.
Alas! and did my Savior bleed,
and did my Sovereign die?
Would he devote that sacred head
for sinners such as I?


Refrain:
At the cross, at the cross,
where I first saw the light,
and the burden of my heart rolled away;
it was there by faith I received my sight,
and now I am happy all the day!


2.
Was it for crimes that I have done,
he groaned upon the tree?
Amazing pity! Grace unknown!
And love beyond degree!


Refrain:
At the cross, at the cross,
where I first saw the light,
and the burden of my heart rolled away;
it was there by faith I received my sight,
and now I am happy all the day!

3.
But drops of grief can ne’er repay
the debt of love I owe:
Here, Lord, I give myself away;
’tis all that I can do!

Refrain:
At the cross, at the cross,
where I first saw the light,
and the burden of my heart rolled away;
it was there by faith I received my sight,
and now I am happy all the day!




```

- |   -  |
-------------|------------|
Title | At the Cross |
Key |  |
Titles | At the cross, at the cross, |
First Line | Alas! and did my Savior bleed, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
