---
title: 162. Wondrous Love - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 162. Wondrous Love. 1. What wondrous love is this, O my soul, O my soul? What wondrous love is this, O my soul? What wondrous love is this That caused the Lord of bliss To bear the dreadful curse for my soul, for my soul; To bear the dreadful curse for my soul, for my soul;
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Wondrous Love, What wondrous love is this, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 162. WONDROUS LOVE
#### Seventh Day Adventist Hymnal

```txt



1.
What wondrous love is this,
O my soul, O my soul?
What wondrous love is this, O my soul?
What wondrous love is this
That caused the Lord of bliss
To bear the dreadful curse for my soul, for my soul;
To bear the dreadful curse for my soul, for my soul;

2.
To God and to the Lamb
I will sing, I will sing;
To God and to the Lamb, I will sing;
To God and to the Lamb
Who is the great I am,
While millions join the theme, I will sing, I will sing;
While millions join the theme, I will sing, I will sing;

3.
And when from death I’m free,
I’ll sing on, I’ll sing on;
And when from death I’m free, I’ll sing on;
And when from death I’m free,
I’ll sing and joyful be,
And through eternity I’ll sing on, I’ll sing on!
And through eternity, I’ll sing on.



```

- |   -  |
-------------|------------|
Title | Wondrous Love |
Key |  |
Titles | undefined |
First Line | What wondrous love is this, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
