---
title: Seventh Day Adventist Hymnal - 161-170
metadata:
    description: |
      Seventh Day Adventist Hymnal - 161-170
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 161-170
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 161-170

# Index of Titles
# | Title                        
-- |-------------
161|[Throned Upon the Awful Tree](/seventh-day-adventist-hymnal/101-200/161-170/Throned-Upon-the-Awful-Tree)
162|[Wondrous Love](/seventh-day-adventist-hymnal/101-200/161-170/Wondrous-Love)
163|[At the Cross](/seventh-day-adventist-hymnal/101-200/161-170/At-the-Cross)
164|[There Is a Green Hill Far Away](/seventh-day-adventist-hymnal/101-200/161-170/There-Is-a-Green-Hill-Far-Away)
165|[Look, You Saints! the Sight Is Glorious](/seventh-day-adventist-hymnal/101-200/161-170/Look,-You-Saints!-the-Sight-Is-Glorious)
166|[Christ the Lord Is Risen Today](/seventh-day-adventist-hymnal/101-200/161-170/Christ-the-Lord-Is-Risen-Today)
167|[Alleluia! Sing to Jesus!](/seventh-day-adventist-hymnal/101-200/161-170/Alleluia!-Sing-to-Jesus!)
168|[And Have the Bright Immensities](/seventh-day-adventist-hymnal/101-200/161-170/And-Have-the-Bright-Immensities)
169|[Come, You Faithful](/seventh-day-adventist-hymnal/101-200/161-170/Come,-You-Faithful)
170|[Come, You Faithful](/seventh-day-adventist-hymnal/101-200/161-170/Come,-You-Faithful_1)