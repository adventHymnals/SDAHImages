---
title: 170. Come, You Faithful
metadata:
    description: 
    keywords: Seventh Day Adventist Hymnal, Come, You Faithful, , 
    author: Brian Onang'o
---


## 170. COME, YOU FAITHFUL

```txt
1.
Come, you faithful, raise the strain
Of triumphant gladness;
God has brought His Israel
Into joy from sadness;
Loosed from Pharoah’s bitter yoke
Jacob’s sons and daughters;
Led them with unmoistened foot
Through the Red Sea waters.

2.
‘Tis the spring of souls today;
Christ has burst His prison,
And from three days’sleep in death
As a sun has risen;
All the winter of our sins,
Long and dark, is flying
From His light, to whom is giv’n
Laud and praise undying.

3.
Now the queen of seasons, bright
With the day of splendor,
With the royal feast of feasts,
Comes its joy to render;
Comes to gladden faithful hearts
Which with true affection
Welcome in unwearied strain
Jesus’resurrection.

4.
For today among the twelve
Christ appeared, be stowing
His deep peace, which evermore
Passes human knowing.
Neither could the gates of death,
Nor the tomb’s dark portal,
Nor the watchers, nor the seal,
Hold Him as a mortal.

5.
“Alleluia!” now we cry
To our King immortal,
Who, triumphant, burst the bars
Of the tomb’s dark portal;
“Alleluia” with the Son,
God the Father praising;
“Alleluia!” yet again
To the Spirit raising.
```

- |   -  |
-------------|------------|
Title | Come, You Faithful |
Key |  |
Titles |  |
First Line |  |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas | 5 |
Chorus | No |
Chorus Type | - |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
