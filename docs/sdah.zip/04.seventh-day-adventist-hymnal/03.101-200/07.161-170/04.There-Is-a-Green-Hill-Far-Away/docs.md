---
title: 164. There Is a Green Hill Far Away - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 164. There Is a Green Hill Far Away. 1. There is a green hill far away, Without a city wall, Where the dear Lord was crucified, Who died to save us all.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, There Is a Green Hill Far Away, There is a green hill far away, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 164. THERE IS A GREEN HILL FAR AWAY
#### Seventh Day Adventist Hymnal

```txt



1.
There is a green hill far away,
Without a city wall,
Where the dear Lord was crucified,
Who died to save us all.

2.
We may not know, we cannot tell,
What pains He had to bear,
But we believe it was for us
He hung and suffered there.

3.
He died that we might be forgiven,
He died to make us good,
That we might go at last to heaven,
Saved by His precious blood.

4.
There was no other good enough
To pay the price of sin;
He only could unlock the gate
Of heaven, and let us in.

5.
O dearly, dearly has He loved!
And we must love Him too,
And trust in His redeeming blood,
And try His works to do.



```

- |   -  |
-------------|------------|
Title | There Is a Green Hill Far Away |
Key |  |
Titles | undefined |
First Line | There is a green hill far away, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
