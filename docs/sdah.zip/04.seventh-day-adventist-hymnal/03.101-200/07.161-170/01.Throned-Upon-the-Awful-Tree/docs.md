---
title: 161. Throned Upon the Awful Tree - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 161. Throned Upon the Awful Tree. 1. Throned upon the awful tree, Lamb of God, Your grief we see. Darkness veils Your anguished face; None its lines of woe can trace. None can tell what pangs unknown Hold You silent and alone.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Throned Upon the Awful Tree, Throned upon the awful tree, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 161. THRONED UPON THE AWFUL TREE
#### Seventh Day Adventist Hymnal

```txt



1.
Throned upon the awful tree,
Lamb of God, Your grief we see.
Darkness veils Your anguished face;
None its lines of woe can trace.
None can tell what pangs unknown
Hold You silent and alone.

2.
Silent through those three dread hours,
Wrestling with the evil powers,
Left alone with human sin,
Gloom around You and within,
Till th’appointed time is nigh,
Till the Lamb of God may die.

3.
Hark, that cry that peals aloud
Upward through the whelming cloud!
You, the Father’s only Son,
You, His own anointed one,
You are asking- can it be?
“Why have You forsaken Me?”

4.
Lord, should fear and anguish roll
Darkly o’er our sinful soul,
You, who once were thus bereft
That Your own might ne’er be left,
Teach us by that bitter cry
In the gloom to know You nigh.



```

- |   -  |
-------------|------------|
Title | Throned Upon the Awful Tree |
Key |  |
Titles | undefined |
First Line | Throned upon the awful tree, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
