---
title: 168. And Have the Bright Immensities - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 168. And Have the Bright Immensities. 1. And have the bright immensities Received our risen Lord, Where light years frame the Pleiades And point Orion’s sword? Do flaming suns His footsteps trace Thro’corridors sublime, The Lord of inter stellar space And conqueror of time?
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, And Have the Bright Immensities, And have the bright immensities 
    author: Brian Onang'o
---

#### Advent Hymnals
## 168. AND HAVE THE BRIGHT IMMENSITIES
#### Seventh Day Adventist Hymnal

```txt



1.
And have the bright immensities
Received our risen Lord,
Where light years frame the Pleiades
And point Orion’s sword?
Do flaming suns His footsteps trace
Thro’corridors sublime,
The Lord of inter stellar space
And conqueror of time?

2.
The heav’n that hides Him from our sight
Knows neither near nor far;
A little candle sheds its light
As surely as a star.
And where His loving people meet
To share the gift divine,
There stands He with unhurrying feet;
There heav’nly splendors shine.



```

- |   -  |
-------------|------------|
Title | And Have the Bright Immensities |
Key |  |
Titles | undefined |
First Line | And have the bright immensities |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
