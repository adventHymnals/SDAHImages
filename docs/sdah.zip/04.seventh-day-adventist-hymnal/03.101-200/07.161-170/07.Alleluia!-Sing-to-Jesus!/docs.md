---
title: 167. Alleluia! Sing to Jesus! - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 167. Alleluia! Sing to Jesus!. 1. Alleluia! sing to Jesus! His the scepter, His the throne. Alleluia! His the triumph, His the victory alone. Hark! the songs of peaceful Zion thunder like a mighty flood. Jesus out of every nation has redeemed us by His blood.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Alleluia! Sing to Jesus!, Alleluia! sing to Jesus! His the scepter, His the throne. 
    author: Brian Onang'o
---

#### Advent Hymnals
## 167. ALLELUIA! SING TO JESUS!
#### Seventh Day Adventist Hymnal

```txt



1.
Alleluia! sing to Jesus! His the scepter, His the throne.
Alleluia! His the triumph, His the victory alone.
Hark! the songs of peaceful Zion thunder like a mighty flood.
Jesus out of every nation has redeemed us by His blood.

2.
Alleluia! not as orphans are we left in sorrow now;
Alleluia! He is near us, faith believes, nor questions how;
Though the cloud from sight received Him when the forty days were o’er
Shall our hearts forget His promise, “I am with you evermore”?

3.
Alleluia! bread of angels, Thou on earth our food, our stay;
Alleluia! here the sinful flee to Thee from day to day:
Intercessor, Friend of sinners, Earth’s Redeemer, plead for me,
Where the songs of all the sinless sweep across the crystal sea.



```

- |   -  |
-------------|------------|
Title | Alleluia! Sing to Jesus! |
Key |  |
Titles | undefined |
First Line | Alleluia! sing to Jesus! His the scepter, His the throne. |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
