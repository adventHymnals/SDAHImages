---
title: 169. Come, You Faithful - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 169. Come, You Faithful. 1. Come, you faithful, raise the strain Of triumphant gladness; God has brought His people Now rejoice, Jerusalem, And with true affection Welcome in unwearied strains Jesus’resurrection.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Come, You Faithful, Come, you faithful, raise the strain 
    author: Brian Onang'o
---

#### Advent Hymnals
## 169. COME, YOU FAITHFUL
#### Seventh Day Adventist Hymnal

```txt



1.
Come, you faithful, raise the strain
Of triumphant gladness;
God has brought His people
Now rejoice, Jerusalem,
And with true affection
Welcome in unwearied strains
Jesus’resurrection.

2.
‘Tis the spring of souls today;
Christ has burst His prison
From the frost and gloom of death
light and life have risen
All the winter of our sins,
Long and dark, is flying
From His ligth, to whom we give
Thanks and praise undying.

3.
“Alleluia!” now we cry
to our King immortal,
Who, triumphant, burst the
bars of the tomb’s dark portal
“Alleluia!” with the Son,
God the Father praising;
“Alleluia!” yet again to
the Spirit raising.



```

- |   -  |
-------------|------------|
Title | Come, You Faithful |
Key |  |
Titles | undefined |
First Line | Come, you faithful, raise the strain |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
