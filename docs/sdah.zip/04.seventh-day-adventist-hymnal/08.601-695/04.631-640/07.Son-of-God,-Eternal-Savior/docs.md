---
title: 637. Son of God, Eternal Savior - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 637. Son of God, Eternal Savior. 1. Son of God, eternal Savior, Source of life and truth and grace, Work made flesh, whose birth among us Hallows all our human race, You our head, who throned in glory, For Your own will ever plead: Fill us with Your love and pity, Heal our wrongs, and help our need.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Son of God, Eternal Savior, Son of God, eternal Savior, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 637. SON OF GOD, ETERNAL SAVIOR
#### Seventh Day Adventist Hymnal

```txt



1.
Son of God, eternal Savior,
Source of life and truth and grace,
Work made flesh, whose birth among us
Hallows all our human race,
You our head, who throned in glory,
For Your own will ever plead:
Fill us with Your love and pity,
Heal our wrongs, and help our need.

2.
Bind us all as one together
In Your church’s sacred fold,
Weak and healthy, poor and wealthy,
Sad and joyful, young and old.
Is there want or pain or sorrow?
Make us all the burden share.
Are there spirits crushed and broken?
Teach us, Lord, to soothe their care.

3.
As You, Lord, have lived for others,
So may we for others live.
Freely have Your gifts been granted;
Freely may Your servants give.
Yours the gold and Yours the silver,
Yours the wealth of land and sea;
We but stewards of Your bounty
Held in solemn trust will be.

4.
Come, O Christ, and reign among us,
King of love and Prince of Peace;
Hush the storm of strife and passion,
Bid its cruel discords cease.
By Your patient years of toiling,
By Your silent hours of pain,
Quench our fevered thirst of pleasure,
Stem our selfish greed of gain.

5.
Son of God, eternal Savior,
Source of life and truth and grace,
Word made flesh, whose birth among us
Hallows all our human race:
By Your praying, by Your willing
That Your people should be one,
Grant, oh, grant our hope’s fruition:
Here on earth Your will be done.



```

- |   -  |
-------------|------------|
Title | Son of God, Eternal Savior |
Key |  |
Titles | undefined |
First Line | Son of God, eternal Savior, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
