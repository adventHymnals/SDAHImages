---
title: 632. Until Then - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 632. Until Then. 1. My heart can sing when I pause to remember, A heartache here is but a stepping stone. Along a trail, thats winding always upward, This troubled world, is not my final home. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Until Then, My heart can sing when I pause to remember, ,But until then, my heart will go on singing,
    author: Brian Onang'o
---

#### Advent Hymnals
## 632. UNTIL THEN
#### Seventh Day Adventist Hymnal

```txt



1.
My heart can sing when I pause to remember,
A heartache here is but a stepping stone.
Along a trail, thats winding always upward,
This troubled world, is not my final home.


Refrain:
But until then, my heart will go on singing,
Until then, with joy I’ll carry on,
Until the day my eyes behold the city,
Until the day God calls me home.


2.
The things of earth will dim and lose their value,
If we recall they’re borrowed for awhile;
And things of earth that cause the heart to tremble,
Remembered there, will only bring a smile.

Refrain:
But until then, my heart will go on singing,
Until then, with joy I’ll carry on,
Until the day my eyes behold the city,
Until the day God calls me home.




```

- |   -  |
-------------|------------|
Title | Until Then |
Key |  |
Titles | But until then, my heart will go on singing, |
First Line | My heart can sing when I pause to remember, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
