---
title: 634. Come, All Christians, Be Committed - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 634. Come, All Christians, Be Committed. 1. Come, all Christians, be committed To the service of the lord; Make your lives for him more fitted, Tune your hearts with one accord. Come into His courts with gladness, Each his sacred vows renew, Turn away from sin and sadness, Be transformed with life anew.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Come, All Christians, Be Committed, Come, all Christians, be committed 
    author: Brian Onang'o
---

#### Advent Hymnals
## 634. COME, ALL CHRISTIANS, BE COMMITTED
#### Seventh Day Adventist Hymnal

```txt



1.
Come, all Christians, be committed
To the service of the lord;
Make your lives for him more fitted,
Tune your hearts with one accord.
Come into His courts with gladness,
Each his sacred vows renew,
Turn away from sin and sadness,
Be transformed with life anew.

2.
Of your time and talents give ye,
They are gifts from God above;
To be used by Christians freely
To proclaim His wondrous love.
Come again to serve the Savior,
Tithes and off’rings with you bring.
In your work, with Him find favor,
And with joy His praises sing.

3.
God’s command to love each other
Is required of every one;
Showing mercy to one another
Mirrors His redemptive plan.
In compassion He has given
Of His love that is divine;
On the cross sins were forgiven;
Joy and peace are fully thine.

4.
Come in praise and adoration,
All who in Christ’s name believe;
Worship Him with consecration,
Grace and love you will receive.
For His grace give Him the glory,
For the Spirit and the Word,
And repeat the gospel story
Till mankind His name has heard.



```

- |   -  |
-------------|------------|
Title | Come, All Christians, Be Committed |
Key |  |
Titles | undefined |
First Line | Come, all Christians, be committed |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
