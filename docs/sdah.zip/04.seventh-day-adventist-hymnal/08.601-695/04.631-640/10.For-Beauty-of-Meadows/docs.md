---
title: 640. For Beauty of Meadows - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 640. For Beauty of Meadows. 1. For beauty of meadows, for grandeur of trees, For flowers of woodlands, for creatures of seas, For all You created and gave us to share, We praise You, Creator, extolling your care.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, For Beauty of Meadows, For beauty of meadows, for grandeur of trees, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 640. FOR BEAUTY OF MEADOWS
#### Seventh Day Adventist Hymnal

```txt



1.
For beauty of meadows, for grandeur of trees,
For flowers of woodlands, for creatures of seas,
For all You created and gave us to share,
We praise You,
Creator, extolling your care.

2.
As stewards of beauty received at Your hand,
As creatures who hear Your most urgent command,
We turn from our wasteful destruction of life,
Confessing our failures, confessing our strife.

3.
Teach us once again to be gardeners in peace;
All nature around us is ours but on lease;
Your name we would hallow in all that we do,
Fulfilling our calling, creating with You.



```

- |   -  |
-------------|------------|
Title | For Beauty of Meadows |
Key |  |
Titles | undefined |
First Line | For beauty of meadows, for grandeur of trees, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
