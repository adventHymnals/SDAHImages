---
title: 638. The Wise May Bring Their Learning - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 638. The Wise May Bring Their Learning. 1. wise may bring their learning, The rich may bring their wealth, And some may bring their greatness, And some their strength and health: We too would bring our treasures To offer to the King, We have no wealth or learning— What shall we children bring?
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The Wise May Bring Their Learning, wise may bring their learning, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 638. THE WISE MAY BRING THEIR LEARNING
#### Seventh Day Adventist Hymnal

```txt



1.
wise may bring their learning,
The rich may bring their wealth,
And some may bring their greatness,
And some their strength and health:
We too would bring our treasures
To offer to the King,
We have no wealth or learning—
What shall we children bring?

2.
We’ll bring Him hearts that love Him,
We’ll bring Him thankful praise,
And young souls meekly striving
To follow in His ways:
And these be the treasures
We offer to the King,
And these are gifts that ever
The poorest child may bring.

3.
We’ll bring the little duties
We have to do each day;
We’ll try our best to please Him
At home, at school, at play:
And better are these treasures
To offer to the King
Than richest gift without them:
Yet these a child may bring.



```

- |   -  |
-------------|------------|
Title | The Wise May Bring Their Learning |
Key |  |
Titles | undefined |
First Line | wise may bring their learning, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
