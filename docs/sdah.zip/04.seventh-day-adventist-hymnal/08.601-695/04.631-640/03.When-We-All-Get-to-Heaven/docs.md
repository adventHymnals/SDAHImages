---
title: 633. When We All Get to Heaven - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 633. When We All Get to Heaven. 1. Sing the wondrous love of Jesus; Sing his mercy and his grace. In the mansions bright and blessed He’ll prepare for us a place. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, When We All Get to Heaven, Sing the wondrous love of Jesus; ,When we all get to heaven,
    author: Brian Onang'o
---

#### Advent Hymnals
## 633. WHEN WE ALL GET TO HEAVEN
#### Seventh Day Adventist Hymnal

```txt



1.
Sing the wondrous love of Jesus;
Sing his mercy and his grace.
In the mansions bright and blessed
He’ll prepare for us a place.


Refrain:
When we all get to heaven,
What a day of rejoicing that will be!
When we all see Jesus,
We’ll sing and shout the victory!


2.
While we walk the pilgrim pathway,
Clouds will overspread the sky;
But when traveling days are over,
Not a shadow, not a sigh.


Refrain:
When we all get to heaven,
What a day of rejoicing that will be!
When we all see Jesus,
We’ll sing and shout the victory!

3.
Let us then be true and faithful,
Trusting, serving every day;
Just one glimpse of him in glory
Will the toils of life repay.


Refrain:
When we all get to heaven,
What a day of rejoicing that will be!
When we all see Jesus,
We’ll sing and shout the victory!

4.
Onward to the prize before us!
Soon his beauty we’ll behold;
Soon the pearly gates will open;
We shall tread the streets of gold.

Refrain:
When we all get to heaven,
What a day of rejoicing that will be!
When we all see Jesus,
We’ll sing and shout the victory!




```

- |   -  |
-------------|------------|
Title | When We All Get to Heaven |
Key |  |
Titles | When we all get to heaven, |
First Line | Sing the wondrous love of Jesus; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
