---
title: 639. A Diligent and Grateful Heart - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 639. A Diligent and Grateful Heart. 1. A diligent and grateful heart Prompts me to sing Thy praise. Thy love and mercies from the start Have blessed me all my days.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, A Diligent and Grateful Heart, A diligent and grateful heart 
    author: Brian Onang'o
---

#### Advent Hymnals
## 639. A DILIGENT AND GRATEFUL HEART
#### Seventh Day Adventist Hymnal

```txt



1.
A diligent and grateful heart
Prompts me to sing Thy praise.
Thy love and mercies from the start
Have blessed me all my days.

2.
I thank Thee for the means to serve
With talents and with tithes,
For sharing brings the utmost joy
When lifting other lives.

3.
My thanks I give you for stewardship
To minister through deeds,
To serve and share with patient care
Thy people in their needs.

4.
O Lord, I dedicate my all
In this response to Thee.
Help me to magnify this call
In deep humility.



```

- |   -  |
-------------|------------|
Title | A Diligent and Grateful Heart |
Key |  |
Titles | undefined |
First Line | A diligent and grateful heart |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
