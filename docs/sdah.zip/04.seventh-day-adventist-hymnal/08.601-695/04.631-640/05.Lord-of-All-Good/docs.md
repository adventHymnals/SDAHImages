---
title: 635. Lord of All Good - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 635. Lord of All Good. 1. Lord of all good, our gifts we bring You now; Use them Your holy purpose to fulfill. Tokens of love and pledges they shall be That our whole life is offered to Your will.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord of All Good, Lord of all good, our gifts we bring You now; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 635. LORD OF ALL GOOD
#### Seventh Day Adventist Hymnal

```txt



1.
Lord of all good, our gifts we bring You now;
Use them Your holy purpose to fulfill.
Tokens of love and pledges they shall be
That our whole life is offered to Your will.

2.
We give our minds to understand Your ways;
Hands, voices, eyes to serve Your great design;
Hearts with the flame of your own love ablaze:
Thus for Your glory all our pow’rs combine.

3.
Father, whose bounty all creation shows;
Christ, by whose willing sacrifice we live;
Spirit, from whom all life in fullness flows:
To You with grateful hearts ourselves we give.



```

- |   -  |
-------------|------------|
Title | Lord of All Good |
Key |  |
Titles | undefined |
First Line | Lord of all good, our gifts we bring You now; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
