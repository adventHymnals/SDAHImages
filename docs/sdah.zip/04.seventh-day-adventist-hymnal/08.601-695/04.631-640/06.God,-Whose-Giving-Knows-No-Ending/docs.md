---
title: 636. God, Whose Giving Knows No Ending - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 636. God, Whose Giving Knows No Ending. 1. God, whose giving knows no ending, From Your rich and endless store: Nature’s wonder, Jesus’ wisdom, Costly cross, grave’s shattered door. Gifted by You, we turn to You, Off’ring up ourselves in praise: Thankful song shall rise forever, Gracious donor of our days.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God, Whose Giving Knows No Ending, God, whose giving knows no ending, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 636. GOD, WHOSE GIVING KNOWS NO ENDING
#### Seventh Day Adventist Hymnal

```txt



1.
God, whose giving knows no ending,
From Your rich and endless store:
Nature’s wonder, Jesus’ wisdom,
Costly cross, grave’s shattered door.
Gifted by You, we turn to You,
Off’ring up ourselves in praise:
Thankful song shall rise forever,
Gracious donor of our days.

2.
Skills and time are ours for pressing
Toward the goals of Christ, Your Son:
All at peace in health and freedom,
Races joined, the church made one.
Now direct our daily labor,
Lest we strive for self alone:
Born with talents, make us servants
Fit to answer at Your throne.

3.
Treasure, too, You have entrusted,
Gain through pow’rs Your grace conferred:
Ours to use for home and kindred,
And to spread the Gospel Word.
Open wide our hands in sharing,
As we heed Christ’s ageless call.
Healing, teaching, and reclaiming,
Serving You by loving all.



```

- |   -  |
-------------|------------|
Title | God, Whose Giving Knows No Ending |
Key |  |
Titles | undefined |
First Line | God, whose giving knows no ending, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
