---
title: 631. When on Life a Darkness Falls - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 631. When on Life a Darkness Falls. 1. When on life a darkness falls, When the mist flows chilling, Paths and sign posts lost in doubt, Loveless, unfulfilling, Reach us, Jesus, from Your cross, Though we feel forsaken; Keep us through the aching night Till new dawns awaken.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, When on Life a Darkness Falls, When on life a darkness falls, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 631. WHEN ON LIFE A DARKNESS FALLS
#### Seventh Day Adventist Hymnal

```txt



1.
When on life a darkness falls,
When the mist flows chilling,
Paths and sign posts lost in doubt,
Loveless, unfulfilling,
Reach us, Jesus, from Your cross,
Though we feel forsaken;
Keep us through the aching night
Till new dawns awaken.

2.
When the dreams and vows of youth
Painfully accuse us,
Stab our conscience, steal our worth,
Christ will not refuse us:
Peace the world cannot provide,
Daily resurrection,
Strong companion at our side
For each new direction.

3.
Come and meet Him, Friend and Lord,
Thro’ the gospel story:
Open door to life and peace,
Window into glory.
All who seek Him, soon are found,
Made His close relation:
Christ our pathway, Christ our home,
Christ our sure foundation.



```

- |   -  |
-------------|------------|
Title | When on Life a Darkness Falls |
Key |  |
Titles | undefined |
First Line | When on life a darkness falls, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
