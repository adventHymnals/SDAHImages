---
title: 671. Now, Dear Lord, As We Pray - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 671. Now, Dear Lord, As We Pray. 1. Now, dear Lord, as we pray, take our hearts and minds far away from the press of the world all around to your throne where grace does abound. May our lives be transformed by Your love, may our souls be refreshed from above. At this moment, let people everywhere join us now as we come to You in prayer.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Now, Dear Lord, As We Pray, Now, dear Lord, as we pray, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 671. NOW, DEAR LORD, AS WE PRAY
#### Seventh Day Adventist Hymnal

```txt



1.
Now, dear Lord, as we pray,
take our hearts and minds far away
from the press of the world all around
to your throne where grace does abound.
May our lives be transformed by Your love,
may our souls be refreshed from above.
At this moment, let people everywhere
join us now as we come to You in prayer.



```

- |   -  |
-------------|------------|
Title | Now, Dear Lord, As We Pray |
Key |  |
Titles | undefined |
First Line | Now, dear Lord, as we pray, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
