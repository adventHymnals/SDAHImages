---
title: 678. God Be in My Head - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 678. God Be in My Head. 1. God be in my head, and in my understanding; God be in mine eyes, and in my looking; God be in my mouth, and in my speaking; God be in my heart, and in my thinking; God be at mine end, and at my departing.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God Be in My Head, God be in my head, and in my understanding; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 678. GOD BE IN MY HEAD
#### Seventh Day Adventist Hymnal

```txt



1.
God be in my head, and in my understanding;
God be in mine eyes, and in my looking;
God be in my mouth, and in my speaking;
God be in my heart, and in my thinking;
God be at mine end, and at my departing.



```

- |   -  |
-------------|------------|
Title | God Be in My Head |
Key |  |
Titles | undefined |
First Line | God be in my head, and in my understanding; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
