---
title: 679. God Be in My Head
metadata:
    description: 
    keywords: Seventh Day Adventist Hymnal, God Be in My Head, , 
    author: Brian Onang'o
---


## 679. GOD BE IN MY HEAD

```txt
1.
God be in my head,
And in my thinking.
god be in my eyes,
And in my looking.
God be in my mouth
And in my speaking.
Oh, God be in my hear,
And in my understanding.
```

- |   -  |
-------------|------------|
Title | God Be in My Head |
Key |  |
Titles |  |
First Line |  |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas | 1 |
Chorus | No |
Chorus Type | - |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
