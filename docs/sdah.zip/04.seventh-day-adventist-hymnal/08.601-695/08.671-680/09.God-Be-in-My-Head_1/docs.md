---
title: 679. God Be in My Head - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 679. God Be in My Head. 1. God be in my head, And in my thinking. god be in my eyes, And in my looking. God be in my mouth And in my speaking. Oh, God be in my hear, And in my understanding.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God Be in My Head, God be in my head, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 679. GOD BE IN MY HEAD
#### Seventh Day Adventist Hymnal

```txt

1.
God be in my head,
And in my thinking.
god be in my eyes,
And in my looking.
God be in my mouth
And in my speaking.
Oh, God be in my hear,
And in my understanding.

```

- |   -  |
-------------|------------|
Title | God Be in My Head |
Key |  |
Titles | undefined |
First Line | God be in my head, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
