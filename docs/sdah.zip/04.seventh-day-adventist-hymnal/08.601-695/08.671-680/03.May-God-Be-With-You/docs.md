---
title: 673. May God Be With You - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 673. May God Be With You. 1. May God be with you Till we meet again, May God be with you, Keep you safe till then; And may His blessings Be within your heart, May God be with you While we’re apart, May God be with you.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, May God Be With You, May God be with you Till we meet again, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 673. MAY GOD BE WITH YOU
#### Seventh Day Adventist Hymnal

```txt



1.
May God be with you Till we meet again,
May God be with you, Keep you safe till then;
And may His blessings Be within your heart,
May God be with you While we’re apart,
May God be with you.

2.
May God be with you, Watch you from above,
May God protect you in His tender love;
And with the dawning Of each bright, new day,
May God be with you, To guide your way,
May God be with you.



```

- |   -  |
-------------|------------|
Title | May God Be With You |
Key |  |
Titles | undefined |
First Line | May God be with you Till we meet again, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
