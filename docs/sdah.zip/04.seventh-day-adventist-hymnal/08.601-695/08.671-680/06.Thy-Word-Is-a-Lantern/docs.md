---
title: 676. Thy Word Is a Lantern - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 676. Thy Word Is a Lantern. 1. Thy Word is a lantern unto my feet, And a light unto my path.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Thy Word Is a Lantern, Thy Word is a lantern unto my feet, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 676. THY WORD IS A LANTERN
#### Seventh Day Adventist Hymnal

```txt



1.
Thy Word is a lantern unto my feet,
And a light unto my path.



```

- |   -  |
-------------|------------|
Title | Thy Word Is a Lantern |
Key |  |
Titles | undefined |
First Line | Thy Word is a lantern unto my feet, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
