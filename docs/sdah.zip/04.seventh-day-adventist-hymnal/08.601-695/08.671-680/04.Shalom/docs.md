---
title: 674. Shalom - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 674. Shalom. 1. Shalom, good friends, shalom, good friends, shalom, shalom. Till we meet again, till we meet again, shalom, shalom.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Shalom, Shalom, good friends, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 674. SHALOM
#### Seventh Day Adventist Hymnal

```txt



1.
Shalom, good friends,
shalom, good friends,
shalom, shalom.
Till we meet again,
till we meet again,
shalom, shalom.



```

- |   -  |
-------------|------------|
Title | Shalom |
Key |  |
Titles | undefined |
First Line | Shalom, good friends, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
