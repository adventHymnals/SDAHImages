---
title: 677. Heavenly Father, to Thee We Pray - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 677. Heavenly Father, to Thee We Pray. 1. Heavenly Father, to Thee we pray, On the holy Sabbath day; Through Thy Word Thy will make known; May each heart become Thy throne, Let Thy living water flow That we Thy boundless love may know. Amen.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Heavenly Father, to Thee We Pray, Heavenly Father, to Thee we pray, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 677. HEAVENLY FATHER, TO THEE WE PRAY
#### Seventh Day Adventist Hymnal

```txt



1.
Heavenly Father, to Thee we pray,
On the holy Sabbath day;
Through Thy Word Thy will make known;
May each heart become Thy throne,
Let Thy living water flow
That we Thy boundless love may know.
Amen.



```

- |   -  |
-------------|------------|
Title | Heavenly Father, to Thee We Pray |
Key |  |
Titles | undefined |
First Line | Heavenly Father, to Thee we pray, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
