---
title: 672. Spirit of the Living God - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 672. Spirit of the Living God. 1. Spirit of the living God, Fall afresh on me! Spirit of the living God, Fall afresh on me! Break me, melt me, mold me, fill me! Spirit of the living God, Fall afresh on me!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Spirit of the Living God, Spirit of the living God, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 672. SPIRIT OF THE LIVING GOD
#### Seventh Day Adventist Hymnal

```txt



1.
Spirit of the living God,
Fall afresh on me!
Spirit of the living God,
Fall afresh on me!
Break me, melt me, mold me, fill me!
Spirit of the living God,
Fall afresh on me!



```

- |   -  |
-------------|------------|
Title | Spirit of the Living God |
Key |  |
Titles | undefined |
First Line | Spirit of the living God, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
