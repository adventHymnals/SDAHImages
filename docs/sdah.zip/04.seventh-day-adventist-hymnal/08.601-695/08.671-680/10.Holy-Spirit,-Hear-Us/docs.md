---
title: 680. Holy Spirit, Hear Us - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 680. Holy Spirit, Hear Us. 1. Holy Spirit, hear us; Help us while we sing; Breath into the music Of the praise we bring.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Holy Spirit, Hear Us, Holy Spirit, hear us; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 680. HOLY SPIRIT, HEAR US
#### Seventh Day Adventist Hymnal

```txt



1.
Holy Spirit, hear us;
Help us while we sing;
Breath into the music
Of the praise we bring.

2.
Holy Spirit, prompt us
When we kneel to pray;
Nearer come, and teach us
What we ought to say.

3.
Holy Spirit, shine Thou
On the Book we read;
Gild it’s holy pages
With the light we need.



```

- |   -  |
-------------|------------|
Title | Holy Spirit, Hear Us |
Key |  |
Titles | undefined |
First Line | Holy Spirit, hear us; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
