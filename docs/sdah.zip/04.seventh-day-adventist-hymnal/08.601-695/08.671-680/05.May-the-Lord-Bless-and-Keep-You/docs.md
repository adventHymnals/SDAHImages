---
title: 675. May the Lord Bless and Keep You - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 675. May the Lord Bless and Keep You. 1. May the Lord bless you and keep you both now and evermore. Amen, Amen.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, May the Lord Bless and Keep You, May the Lord bless you and keep you 
    author: Brian Onang'o
---

#### Advent Hymnals
## 675. MAY THE LORD BLESS AND KEEP YOU
#### Seventh Day Adventist Hymnal

```txt



1.
May the Lord bless you and keep you
both now and evermore.
Amen, Amen.



```

- |   -  |
-------------|------------|
Title | May the Lord Bless and Keep You |
Key |  |
Titles | undefined |
First Line | May the Lord bless you and keep you |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
