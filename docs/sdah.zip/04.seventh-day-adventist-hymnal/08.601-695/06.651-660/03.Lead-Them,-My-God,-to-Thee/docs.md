---
title: 653. Lead Them, My God, to Thee - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 653. Lead Them, My God, to Thee. 1. Lead them, my God, to Thee, Lead them to Thee, These children dear of mine, Thou gavest me; O, by Thy love divine, Lead them, my God, to Thee; Lead them, my God, to Thee, Lead them to Thee.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lead Them, My God, to Thee, Lead them, my God, to Thee, Lead them to Thee, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 653. LEAD THEM, MY GOD, TO THEE
#### Seventh Day Adventist Hymnal

```txt



1.
Lead them, my God, to Thee, Lead them to Thee,
These children dear of mine, Thou gavest me;
O, by Thy love divine, Lead them, my God, to Thee;
Lead them, my God, to Thee, Lead them to Thee.

2.
When earth looks bright and fair, Festive and gay,
Let no delusive snare Lure them astray;
But from temptation’s power, Lead them, my God, to Thee,
Lead them, my God, to Thee, Lead them to Thee.

3.
E’en for such little ones, Christ came a child,
And in this world of sin Lived undefiled.
O, for His sake, I pray, Lead them, my God, to Thee,
Lead them, my God, to Thee, Lead them to Thee.

4.
Yea, though my faith be dim, I would believe
That Thou this precious gift Wilt now receive;
O take their young hearts now, Lead them my God to Thee,
Lead them, my God, to Thee, Lead them to Thee.



```

- |   -  |
-------------|------------|
Title | Lead Them, My God, to Thee |
Key |  |
Titles | undefined |
First Line | Lead them, my God, to Thee, Lead them to Thee, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
