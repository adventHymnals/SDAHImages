---
title: 652. Love at Home - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 652. Love at Home. 1. There is beauty all around, When there’s love at home; There is joy in every sound, When there’s love at home. Peace and plenty here abide, Smiling fair on every side; Time doth softly, sweetly glide, When there’s love at home. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Love at Home, There is beauty all around, When there’s love at home; ,Love at home, love at home;
    author: Brian Onang'o
---

#### Advent Hymnals
## 652. LOVE AT HOME
#### Seventh Day Adventist Hymnal

```txt



1.
There is beauty all around, When there’s love at home;
There is joy in every sound, When there’s love at home.
Peace and plenty here abide, Smiling fair on every side;
Time doth softly, sweetly glide, When there’s love at home.


Refrain:
Love at home, love at home;
Time doth softly, sweetly glide,
When there’s love at home.


2.
Kindly heaven smiles above, When there’s love at home;
All the earth is fill’d with love, When there’s love at home.
Sweeter sings the brooklet by, Brighter beams the azure sky;
O, there’s One who smiles on high When there’s love at home.


Refrain:
Love at home, love at home;
Time doth softly, sweetly glide,
When there’s love at home.

3.
Jesus, make me wholly Thine, Then there’s love at home;
May Thy sacrifice be mine, Then there’s love at home.
Safely from all harm I’ll rest, With no sinful care distress’d,
Thro’ Thy tender mercy blessed, When there’s love at home.

Refrain:
Love at home, love at home;
Time doth softly, sweetly glide,
When there’s love at home.




```

- |   -  |
-------------|------------|
Title | Love at Home |
Key |  |
Titles | Love at home, love at home; |
First Line | There is beauty all around, When there’s love at home; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
