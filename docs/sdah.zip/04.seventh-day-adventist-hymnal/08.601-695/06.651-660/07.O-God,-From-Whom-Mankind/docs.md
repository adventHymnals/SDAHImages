---
title: 657. O God, From Whom Mankind - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 657. O God, From Whom Mankind. 1. O God from whom mankind derives its name; Whose covenant of grace remains the same, Be with these two who now before You wait; Enlarge the love they come to consecrate.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O God, From Whom Mankind, O God from whom mankind derives its name; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 657. O GOD, FROM WHOM MANKIND
#### Seventh Day Adventist Hymnal

```txt



1.
O God from whom mankind derives its name;
Whose covenant of grace remains the same,
Be with these two who now before You wait;
Enlarge the love they come to consecrate.

2.
May through their union other lives be blessed;
Their door be wide to stranger and to guest,
Give them the understanding that is kind,
Grant them the blessing of an open mind.

3.
Preserve their days from inwardness of hear;
To each the gift of truthful speech impart.
Their bond be strong against all strain and strife
Amid the changes of this earthly life.

4.
From stage to stage on life’s unfolding way
Bring to their mind the vows they make this day,
Your Spirit be their Guide in every move,
Their faith in Christ the basis of their love.



```

- |   -  |
-------------|------------|
Title | O God, From Whom Mankind |
Key |  |
Titles | undefined |
First Line | O God from whom mankind derives its name; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
