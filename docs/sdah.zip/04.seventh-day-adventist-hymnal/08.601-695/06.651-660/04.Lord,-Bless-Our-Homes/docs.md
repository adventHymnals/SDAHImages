---
title: 654. Lord, Bless Our Homes - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 654. Lord, Bless Our Homes. 1. Lord, bless our homes with peace and love and laughter, With understanding and with loyalty. May we together follow Christ the Master And know the blessing of His sov’reignty.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord, Bless Our Homes, Lord, bless our homes with peace and love and laughter, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 654. LORD, BLESS OUR HOMES
#### Seventh Day Adventist Hymnal

```txt



1.
Lord, bless our homes with peace and love and laughter,
With understanding and with loyalty.
May we together follow Christ the Master
And know the blessing of His sov’reignty.

2.
May every heart receive His loving spirit
And know the t4ruth that makes life truly free;
Then, in that spirit may we live united,
And find in God our deep security.

3.
Forgive the hurts our selfishness inflicted
On whose we love and those who love us best.
Christ, heal the scars and draw us all together
In Him whose will is peace and joy and rest.

4.
Father, in gratitude for homes and loved one,
We open now our hearts to all mankind.
Grand us Your spirit love for one another
So in Your peace may we our concord find.



```

- |   -  |
-------------|------------|
Title | Lord, Bless Our Homes |
Key |  |
Titles | undefined |
First Line | Lord, bless our homes with peace and love and laughter, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
