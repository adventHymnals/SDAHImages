---
title: 658. Heavenly Father, Hear Our Prayer - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 658. Heavenly Father, Hear Our Prayer. 1. Heav’nly Father, hear our prayer As we bow before You: Bless them in the life they share, Humble we implore You. Be their guide in all endeavors, Be their hope that nothing severs; Constant source of love divine, Let Your love within them shine!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Heavenly Father, Hear Our Prayer, Heav’nly Father, hear our prayer 
    author: Brian Onang'o
---

#### Advent Hymnals
## 658. HEAVENLY FATHER, HEAR OUR PRAYER
#### Seventh Day Adventist Hymnal

```txt



1.
Heav’nly Father, hear our prayer
As we bow before You:
Bless them in the life they share,
Humble we implore You.
Be their guide in all endeavors,
Be their hope that nothing severs;
Constant source of love divine,
Let Your love within them shine!

2.
As they pledge their love this day
Here before Your altar,
May their hearts,, upon You stayed,
Never fail or falter.
Be their comfort in all sorrow;
Be their reason for tomorrow.
Grant them strength to live each hour
Trusting solely in Your pow’r.

3.
Blest Creator, Lord of life,
Hear our glad thanksgiving.
Husband You have joined to wife
For their earthly living.
Justified by Jesus’ merit,
Life eternal they inherit.
When their days on earth have passed,
Take them to Your home at last!



```

- |   -  |
-------------|------------|
Title | Heavenly Father, Hear Our Prayer |
Key |  |
Titles | undefined |
First Line | Heav’nly Father, hear our prayer |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
