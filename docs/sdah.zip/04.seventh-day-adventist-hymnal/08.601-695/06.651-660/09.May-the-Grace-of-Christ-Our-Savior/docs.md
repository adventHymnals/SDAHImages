---
title: 659. May the Grace of Christ Our Savior - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 659. May the Grace of Christ Our Savior. 1. May the grace of Christ our Savior And the Father’s boundless love, With the Holy Spirit’s favor, Rest upon them from above.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, May the Grace of Christ Our Savior, May the grace of Christ our Savior 
    author: Brian Onang'o
---

#### Advent Hymnals
## 659. MAY THE GRACE OF CHRIST OUR SAVIOR
#### Seventh Day Adventist Hymnal

```txt



1.
May the grace of Christ our Savior
And the Father’s boundless love,
With the Holy Spirit’s favor,
Rest upon them from above.

2.
Thus may they abide in union
With each other and the Lord,
And possess, in sweet communion,
Joys which earth cannot afford.



```

- |   -  |
-------------|------------|
Title | May the Grace of Christ Our Savior |
Key |  |
Titles | undefined |
First Line | May the grace of Christ our Savior |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
