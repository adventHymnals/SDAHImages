---
title: 660. Glory Be to the Father - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 660. Glory Be to the Father. 1. Glory be to the Father, and to the Son, and to the Holy Ghost; As it was in the beginning, is now, and ever shall be, world without end. Amen, Amen.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Glory Be to the Father, Glory be to the Father, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 660. GLORY BE TO THE FATHER
#### Seventh Day Adventist Hymnal

```txt



1.
Glory be to the Father,
and to the Son,
and to the Holy Ghost;
As it was in the beginning,
is now, and ever shall be,
world without end.
Amen, Amen.



```

- |   -  |
-------------|------------|
Title | Glory Be to the Father |
Key |  |
Titles | undefined |
First Line | Glory be to the Father, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
