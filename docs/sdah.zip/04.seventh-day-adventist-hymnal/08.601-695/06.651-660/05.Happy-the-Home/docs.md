---
title: 655. Happy the Home - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 655. Happy the Home. 1. Happy the home when God is there, and love fills every breast; when one their wish, and one their prayer, and one their heavenly rest.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Happy the Home, Happy the home when God is there, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 655. HAPPY THE HOME
#### Seventh Day Adventist Hymnal

```txt



1.
Happy the home when God is there,
and love fills every breast;
when one their wish, and one their prayer,
and one their heavenly rest.

2.
Happy the home where Jesus’ name
is sweet to every ear;
where children early speak his fame,
and parents hold him dear.

3.
Happy the home where prayer is heard,
and praise is wont to rise;
where parents love the sacred Word
and all its wisdom prize.

4.
Lord, let us in our homes agree
this blessed peace to gain;
unite our hearts in love to thee,
and love to all will reign.



```

- |   -  |
-------------|------------|
Title | Happy the Home |
Key |  |
Titles | undefined |
First Line | Happy the home when God is there, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
