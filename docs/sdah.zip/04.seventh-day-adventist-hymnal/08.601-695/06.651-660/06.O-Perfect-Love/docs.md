---
title: 656. O Perfect Love - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 656. O Perfect Love. 1. O perfect Love, all human thought transcending, lowly we kneel in prayer before thy throne, that theirs may be the love which knows no ending, whom thou forevermore dost join in one.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Perfect Love, O perfect Love, all human thought transcending, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 656. O PERFECT LOVE
#### Seventh Day Adventist Hymnal

```txt



1.
O perfect Love, all human thought transcending,
lowly we kneel in prayer before thy throne,
that theirs may be the love which knows no ending,
whom thou forevermore dost join in one.

2.
O perfect Life, be thou their full assurance
of tender charity and steadfast faith,
of patient hope and quiet, brave endurance,
with childlike trust that fears nor pain nor death.

3.
Grant them the joy which brightens earthly sorrow;
grant them the peace which calms all earthly strife,
and to life’s day the glorious unknown morrow
that dawns upon eternal love and life.



```

- |   -  |
-------------|------------|
Title | O Perfect Love |
Key |  |
Titles | undefined |
First Line | O perfect Love, all human thought transcending, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
