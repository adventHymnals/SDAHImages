---
title: 608. Faith Is the Victory - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 608. Faith Is the Victory. 1. Encamped along the hills of light, Ye Christian soldiers, rise, And press the battle ere the night Shall veil the glowing skies. Against the foe in vales below, Let all our strength be hurled; Faith is the victory, we know, That overcomes the world. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Faith Is the Victory, Encamped along the hills of light, ,Faith is the victory!
    author: Brian Onang'o
---

#### Advent Hymnals
## 608. FAITH IS THE VICTORY
#### Seventh Day Adventist Hymnal

```txt



1.
Encamped along the hills of light,
Ye Christian soldiers, rise,
And press the battle ere the night
Shall veil the glowing skies.
Against the foe in vales below,
Let all our strength be hurled;
Faith is the victory, we know,
That overcomes the world.


Refrain:
Faith is the victory!
Faith is the victory!
Oh, glorious victory
That overcomes the world.


2.
His banner over us in love,
Our sword the Word of God;
We tread the road the saints above
With shouts of triumph trod.
By faith they, like whirlwind’s breath,
Swept on o’er ev’ry field;
The faith by which they conquered death
Is still our shining shield.


Refrain:
Faith is the victory!
Faith is the victory!
Oh, glorious victory
That overcomes the world.

3.
To him who overcomes the foe
White raiment shall be giv’n;
Before the angels he shall know
His name confessed in heav’n.
Then onward from the hills of light,
Our hearts with love aflame;
We’ll vanquish all the hosts of night,
In Jesus’ conq’ring name.

Refrain:
Faith is the victory!
Faith is the victory!
Oh, glorious victory
That overcomes the world.




```

- |   -  |
-------------|------------|
Title | Faith Is the Victory |
Key |  |
Titles | Faith is the victory! |
First Line | Encamped along the hills of light, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
