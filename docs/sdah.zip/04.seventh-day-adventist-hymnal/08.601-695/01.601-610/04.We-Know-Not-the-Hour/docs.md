---
title: 604. We Know Not the Hour - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 604. We Know Not the Hour. 1. We know not the hour of the Master’s appearing; Yet signs all foretell that the moment is nearing When He shall return ’tis the promise most cheering But we know not the hour. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, We Know Not the Hour, We know not the hour of the Master’s appearing; ,He will come, let us watch and be ready;
    author: Brian Onang'o
---

#### Advent Hymnals
## 604. WE KNOW NOT THE HOUR
#### Seventh Day Adventist Hymnal

```txt



1.
We know not the hour of the Master’s appearing;
Yet signs all foretell that the moment is nearing
When He shall return ’tis the promise most cheering
But we know not the hour.


Refrain:
He will come, let us watch and be ready;
He will come, hallelujah! hallelujah!
He will come in the clouds of His Father’s
bright glory but we know not the hour.


2.
There’s light for the wise who are seeking salvation;
There’s truth in the book of the Lord’s revelation;
Each prophecy points to the great comsummation
But we know not the hour.


Refrain:
He will come, let us watch and be ready;
He will come, hallelujah! hallelujah!
He will come in the clouds of His Father’s
bright glory but we know not the hour.

3.
We’ll watch and we’ll pray, with our lamps trimmed and burning;
We’ll work and we’ll wait till the Master’s returning;
We’ll sing and rejoice, every omen discerning
But we know not the hour.

Refrain:
He will come, let us watch and be ready;
He will come, hallelujah! hallelujah!
He will come in the clouds of His Father’s
bright glory but we know not the hour.




```

- |   -  |
-------------|------------|
Title | We Know Not the Hour |
Key |  |
Titles | He will come, let us watch and be ready; |
First Line | We know not the hour of the Master’s appearing; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
