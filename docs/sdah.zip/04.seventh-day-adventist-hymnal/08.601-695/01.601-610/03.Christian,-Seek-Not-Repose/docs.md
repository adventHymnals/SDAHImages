---
title: 603. Christian, Seek Not Repose - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 603. Christian, Seek Not Repose. 1. Christian, seek not yet repose, Cast thy dreams of ease away; Thou aret in teh midst of foes; Watch and pray!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Christian, Seek Not Repose, Christian, seek not yet repose, Cast thy dreams of ease away; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 603. CHRISTIAN, SEEK NOT REPOSE
#### Seventh Day Adventist Hymnal

```txt



1.
Christian, seek not yet repose, Cast thy dreams of ease away;
Thou aret in teh midst of foes; Watch and pray!

2.
Gird thy heavenly armor on, Wear it ever, night and day;
Ambushed lies the evil one; Watch and pray!

3.
Hear the victors who o’ercame; Still they mark each warrior’s way;
All with one sweet voice exclaim: “Watch and pray!”

4.
Hear, above all, hear thy Lord, Him thou lovest to obey;
Hide within thy heart His word; “Watch and pray!”

5.
Watch, as if on that alone Hung the issue of teh day;
Pray that help may be send down; Watch and pray!



```

- |   -  |
-------------|------------|
Title | Christian, Seek Not Repose |
Key |  |
Titles | undefined |
First Line | Christian, seek not yet repose, Cast thy dreams of ease away; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
