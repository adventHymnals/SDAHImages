---
title: 609. Am I a Soldier of the Cross? - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 609. Am I a Soldier of the Cross?. 1. Am I a soldier of the cross, a follower of the Lamb, and shall I fear to own his cause, or blush to speak his name?
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Am I a Soldier of the Cross?, Am I a soldier of the cross, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 609. AM I A SOLDIER OF THE CROSS?
#### Seventh Day Adventist Hymnal

```txt



1.
Am I a soldier of the cross,
a follower of the Lamb,
and shall I fear to own his cause,
or blush to speak his name?

2.
Must I be carried to the skies
on flowery beds of ease,
while others fought to win the prize,
and sailed through bloody seas?

3.
Are there no foes for me to face?
Must I not stem the flood?
Is this vile world a friend to grace,
to help me on to God?

4.
Sure I must fight, if I would reign;
increase my courage, Lord
I’ll bear the toil, endure the pain,
supported by thy word

5.
Thy saints in all this glorious war
shall conquer though they die;
they see the triumph from afar,
by faith they bring it nigh

6.
When that illustrious day shall rise,
and all thy armies shine
in robes of victory through the skies,
the glory shall be thine



```

- |   -  |
-------------|------------|
Title | Am I a Soldier of the Cross? |
Key |  |
Titles | undefined |
First Line | Am I a soldier of the cross, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
