---
title: 605. My Soul, Be on Thy Guard - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 605. My Soul, Be on Thy Guard. 1. My soul, be on they guard! Ten thousand foes arise; The hosts of sin are pressing hard To draw thee from the skies.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, My Soul, Be on Thy Guard, My soul, be on they guard! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 605. MY SOUL, BE ON THY GUARD
#### Seventh Day Adventist Hymnal

```txt



1.
My soul, be on they guard!
Ten thousand foes arise;
The hosts of sin are pressing hard
To draw thee from the skies.

2.
O watch, and fight, and pray!
The battle ne’er give o’er;
Renew it boldly every day,
And help divine implore.

3.
Ne’er think the victory won,
Nor lay thine armor down;
Thy arduous task will not be done
Till thou obtain the crown.



```

- |   -  |
-------------|------------|
Title | My Soul, Be on Thy Guard |
Key |  |
Titles | undefined |
First Line | My soul, be on they guard! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
