---
title: 601. Watchmen, on the Walls of Zion - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 601. Watchmen, on the Walls of Zion. 1. Watchmen, on the walls of Zion, What O tell us, of the night? Is the daystar now arising? Will the morn soon greet our sight? O’er your vision Shine there now some rays of light? O’er your vision Shine there now some rays of light?
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Watchmen, on the Walls of Zion, Watchmen, on the walls of Zion, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 601. WATCHMEN, ON THE WALLS OF ZION
#### Seventh Day Adventist Hymnal

```txt



1.
Watchmen, on the walls of Zion,
What O tell us, of the night?
Is the daystar now arising?
Will the morn soon greet our sight?
O’er your vision Shine there now
some rays of light?
O’er your vision Shine there now
some rays of light?

2.
Tell, O tell us, are the landmarks
On our voyage all passed by?
Are we nearing now the haven?
Can we e’en the land descry?
Do we truly See the heavenly kingdom nigh?
Do we truly See the heavenly kingdom nigh?

3.
Light is beaming, day is coming!
Let us sound aloud the cry;
We behold the daystar rising
Pure and bright in yonder sky!
Saints, be joyful; Your redemption draweth nigh;
Saints, be joyful; Your redemption draweth nigh.

4.
We have found the chart and compass,
And are sure the land is near;
Onward, onward we are hasting,
Soon the haven will appear;
Let your voices Sound aloud your holy cheer;
Let your voices Sound aloud your holy cheer.



```

- |   -  |
-------------|------------|
Title | Watchmen, on the Walls of Zion |
Key |  |
Titles | undefined |
First Line | Watchmen, on the walls of Zion, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
