---
title: 607. God of Grace and God of Glory - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 607. God of Grace and God of Glory. 1. God of grace and God of glory, On Thy people pour Thy power; Now fulfill Thy church’s story, Bring her bud to glorious flower. Grant us wisdom, grant us courage, For the facing of this hour.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God of Grace and God of Glory, God of grace and God of glory, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 607. GOD OF GRACE AND GOD OF GLORY
#### Seventh Day Adventist Hymnal

```txt



1.
God of grace and God of glory,
On Thy people pour Thy power;
Now fulfill Thy church’s story,
Bring her bud to glorious flower.
Grant us wisdom, grant us courage,
For the facing of this hour.

2.
Lo, the hosts of evil round us
Scorn Thy Christ, assail His ways;
From the fears that long have bound us
Free our hearts to faith and praise.
Grant us wisdom, grant us courage,
For the facing of this hour.

3.
Cure Thy children’s warring madness,
Bend our pride to Thy control;
Shame our wanton selfish gladness
Rich in goods and poor in soul.
Grant us wisdom, grant us courage,
Lest we miss Thy kingdom’s goal.

4.
Set our feet on lofty places,
Gird our lives that they may be
Armored with all Christ-like graces
In the fight to set all free.
Grant us wisdom, grant us courage,
That we fail not man nor Thee.



```

- |   -  |
-------------|------------|
Title | God of Grace and God of Glory |
Key |  |
Titles | undefined |
First Line | God of grace and God of glory, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
