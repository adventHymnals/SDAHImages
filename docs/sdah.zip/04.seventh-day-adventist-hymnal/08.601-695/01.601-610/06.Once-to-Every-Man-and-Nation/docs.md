---
title: 606. Once to Every Man and Nation - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 606. Once to Every Man and Nation. 1. Once to every man and nation, comes the moment to decide, In the strife of truth with falsehood, for the good or evil side; Some great cause, some great decision, offering each the bloom or blight, And the choice goes by forever, ’twixt that darkness and that light.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Once to Every Man and Nation, Once to every man and nation, comes the moment to decide, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 606. ONCE TO EVERY MAN AND NATION
#### Seventh Day Adventist Hymnal

```txt



1.
Once to every man and nation, comes the moment to decide,
In the strife of truth with falsehood, for the good or evil side;
Some great cause, some great decision, offering each the bloom or blight,
And the choice goes by forever, ’twixt that darkness and that light.

2.
Then to side with truth is noble, when we share her wretched crust,
Ere her cause bring fame and profit, and ’tis prosperous to be just;
Then it is the brave man chooses while the coward stands aside,
Till the multitude make virtue of the faith they had denied.

3.
By the light of burning martyrs, Christ, Thy bleeding feet we track,
Toiling up new Calv’ries ever with the cross that turns not back;
New occasions teach new duties, time makes ancient good uncouth,
They must upward still and onward, who would keep abreast of truth.

4.
Though the cause of evil prosper, yet the truth alone is strong;
Though her portion be the scaffold, and upon the throne be wrong;
Yet that scaffold sways the future, and behind the dim unknown,
Standeth God within the shadow, keeping watch above His own.



```

- |   -  |
-------------|------------|
Title | Once to Every Man and Nation |
Key |  |
Titles | undefined |
First Line | Once to every man and nation, comes the moment to decide, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
