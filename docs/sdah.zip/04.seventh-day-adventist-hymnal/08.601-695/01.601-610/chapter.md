---
title: Seventh Day Adventist Hymnal - 601-610
metadata:
    description: |
      Seventh Day Adventist Hymnal - 601-610
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 601-610
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 601-610

# Index of Titles
# | Title                        
-- |-------------
601|[Watchmen, on the Walls of Zion](/seventh-day-adventist-hymnal/601-700/601-610/Watchmen,-on-the-Walls-of-Zion)
602|[O Brother, Be Faithful](/seventh-day-adventist-hymnal/601-700/601-610/O-Brother,-Be-Faithful)
603|[Christian, Seek Not Repose](/seventh-day-adventist-hymnal/601-700/601-610/Christian,-Seek-Not-Repose)
604|[We Know Not the Hour](/seventh-day-adventist-hymnal/601-700/601-610/We-Know-Not-the-Hour)
605|[My Soul, Be on Thy Guard](/seventh-day-adventist-hymnal/601-700/601-610/My-Soul,-Be-on-Thy-Guard)
606|[Once to Every Man and Nation](/seventh-day-adventist-hymnal/601-700/601-610/Once-to-Every-Man-and-Nation)
607|[God of Grace and God of Glory](/seventh-day-adventist-hymnal/601-700/601-610/God-of-Grace-and-God-of-Glory)
608|[Faith Is the Victory](/seventh-day-adventist-hymnal/601-700/601-610/Faith-Is-the-Victory)
609|[Am I a Soldier of the Cross?](/seventh-day-adventist-hymnal/601-700/601-610/Am-I-a-Soldier-of-the-Cross?)
610|[Stand Like the Brave](/seventh-day-adventist-hymnal/601-700/601-610/Stand-Like-the-Brave)