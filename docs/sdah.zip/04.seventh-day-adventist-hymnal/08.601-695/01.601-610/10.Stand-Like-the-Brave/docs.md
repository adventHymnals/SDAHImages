---
title: 610. Stand Like the Brave - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 610. Stand Like the Brave. 1. O Christian, awake! ’tis the Master’s command; With helmet and shield, and a sword in thy hand, To meet the bold tempter, go, fearlessly go, Then stand like the brave, with thy face to the foe. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Stand Like the Brave, O Christian, awake! ’tis the Master’s command; ,Stand like the brave, stand like the brave,
    author: Brian Onang'o
---

#### Advent Hymnals
## 610. STAND LIKE THE BRAVE
#### Seventh Day Adventist Hymnal

```txt



1.
O Christian, awake! ’tis the Master’s command;
With helmet and shield, and a sword in thy hand,
To meet the bold tempter, go, fearlessly go,
Then stand like the brave, with thy face to the foe.


Refrain:
Stand like the brave, stand like the brave,
Stand like the brave, with thy face to the foe.


2.
The cause of thy Master with vigor defend;
Be watchful, be zealous, and fight to the end;
Wherever He leads thee, go, valiantly go,
Then stand like the brave, with thy face to the foe.


Refrain:
Stand like the brave, stand like the brave,
Stand like the brave, with thy face to the foe.

3.
Press on, never doubting, thy Captain is near,
With grace to supply, and with comfort to cheer;
His love, like a stream in the desert will flow;
Then stand like the brave, with thy face to the foe.

Refrain:
Stand like the brave, stand like the brave,
Stand like the brave, with thy face to the foe.




```

- |   -  |
-------------|------------|
Title | Stand Like the Brave |
Key |  |
Titles | Stand like the brave, stand like the brave, |
First Line | O Christian, awake! ’tis the Master’s command; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
