---
title: 692. The Lord Is in His Holy Temple - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 692. The Lord Is in His Holy Temple. 1. The Lord is in His holy temple, The Lord is in His holy temple, Let all the earth keep silence, Let all the earth keep silence, before Him, Keep silence, keep silence, before Him. Amen.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The Lord Is in His Holy Temple, The Lord is in His holy temple, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 692. THE LORD IS IN HIS HOLY TEMPLE
#### Seventh Day Adventist Hymnal

```txt

1.
The Lord is in His holy temple,
The Lord is in His holy temple,
Let all the earth keep silence,
Let all the earth keep silence, before Him,
Keep silence, keep silence, before Him.
Amen.

```

- |   -  |
-------------|------------|
Title | The Lord Is in His Holy Temple |
Key |  |
Titles | undefined |
First Line | The Lord is in His holy temple, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
