---
title: 693. Almighty Father - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 693. Almighty Father. 1. Almighty Father, hear our prayer, and bless all souls that wait before Thee. Amen.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Almighty Father, Almighty Father, hear our prayer, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 693. ALMIGHTY FATHER
#### Seventh Day Adventist Hymnal

```txt



1.
Almighty Father, hear our prayer,
and bless all souls that wait before Thee.
Amen.



```

- |   -  |
-------------|------------|
Title | Almighty Father |
Key |  |
Titles | undefined |
First Line | Almighty Father, hear our prayer, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
