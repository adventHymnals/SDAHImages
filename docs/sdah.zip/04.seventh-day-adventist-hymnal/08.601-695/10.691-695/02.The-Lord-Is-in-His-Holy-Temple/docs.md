---
title: 692. The Lord Is in His Holy Temple
metadata:
    description: 
    keywords: Seventh Day Adventist Hymnal, The Lord Is in His Holy Temple, , 
    author: Brian Onang'o
---


## 692. THE LORD IS IN HIS HOLY TEMPLE

```txt
1.
The Lord is in His holy temple,
The Lord is in His holy temple,
Let all the earth keep silence,
Let all the earth keep silence, before Him,
Keep silence, keep silence, before Him.
Amen.
```

- |   -  |
-------------|------------|
Title | The Lord Is in His Holy Temple |
Key |  |
Titles |  |
First Line |  |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas | 1 |
Chorus | No |
Chorus Type | - |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
