---
title: 691. Lead Me, Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 691. Lead Me, Lord. 1. Lead me, Lord, lead me in thy righteousness; make thy way plain before my face. For it is thou, Lord, thou, Lord only, that makest me dwell in safety.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lead Me, Lord, Lead me, Lord, lead me in thy righteousness; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 691. LEAD ME, LORD
#### Seventh Day Adventist Hymnal

```txt



1.
Lead me, Lord, lead me in thy righteousness;
make thy way plain before my face.
For it is thou, Lord, thou, Lord only,
that makest me dwell in safety.



```

- |   -  |
-------------|------------|
Title | Lead Me, Lord |
Key |  |
Titles | undefined |
First Line | Lead me, Lord, lead me in thy righteousness; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
