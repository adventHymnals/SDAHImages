---
title: 682. As You Have Promised, Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 682. As You Have Promised, Lord. 1. As You have promised, Lord, today, You are letting Your servant go away in peace. May eyes have seen You in broad daylight before all nations, planning salvation. Light of revelation for the nations, and glory of Your people Israel.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, As You Have Promised, Lord, As You have promised, Lord, today, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 682. AS YOU HAVE PROMISED, LORD
#### Seventh Day Adventist Hymnal

```txt



1.
As You have promised, Lord, today,
You are letting Your servant go away in peace.
May eyes have seen You in broad daylight
before all nations, planning salvation.
Light of revelation for the nations,
and glory of Your people Israel.



```

- |   -  |
-------------|------------|
Title | As You Have Promised, Lord |
Key |  |
Titles | undefined |
First Line | As You have promised, Lord, today, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
