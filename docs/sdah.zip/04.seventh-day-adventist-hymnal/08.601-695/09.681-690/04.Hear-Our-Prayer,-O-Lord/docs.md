---
title: 684. Hear Our Prayer, O Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 684. Hear Our Prayer, O Lord. 1. Hear Our Prayer, O Lord, Hear our prayer, O Lord; Incline Thine ear to us, And grant us Thy peace. Amen.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Hear Our Prayer, O Lord, Hear Our Prayer, O Lord, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 684. HEAR OUR PRAYER, O LORD
#### Seventh Day Adventist Hymnal

```txt



1.
Hear Our Prayer, O Lord,
Hear our prayer, O Lord;
Incline Thine ear to us,
And grant us Thy peace.
Amen.



```

- |   -  |
-------------|------------|
Title | Hear Our Prayer, O Lord |
Key |  |
Titles | undefined |
First Line | Hear Our Prayer, O Lord, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
