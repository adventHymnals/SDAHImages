---
title: 686. Bless Thou the Gifts - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 686. Bless Thou the Gifts. 1. Bless thou the gifts our hands have brought; bless thou the work our hearts have planned. Ours is the faith, the will, the thought; the rest, O God, is in thy hand. Amen.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Bless Thou the Gifts, Bless thou the gifts our hands have brought; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 686. BLESS THOU THE GIFTS
#### Seventh Day Adventist Hymnal

```txt



1.
Bless thou the gifts our hands have brought;
bless thou the work our hearts have planned.
Ours is the faith, the will, the thought;
the rest, O God, is in thy hand.
Amen.



```

- |   -  |
-------------|------------|
Title | Bless Thou the Gifts |
Key |  |
Titles | undefined |
First Line | Bless thou the gifts our hands have brought; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
