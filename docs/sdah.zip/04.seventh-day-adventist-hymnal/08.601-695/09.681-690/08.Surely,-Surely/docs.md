---
title: 688. Surely, Surely - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 688. Surely, Surely. 1. Surely, surely the Lord has been here, Surely angels still linger near; I hear music soft on my ear, I feel His Spirit, I have no fear.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Surely, Surely, Surely, surely the Lord has been here, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 688. SURELY, SURELY
#### Seventh Day Adventist Hymnal

```txt



1.
Surely, surely the Lord has been here,
Surely angels still linger near;
I hear music soft on my ear,
I feel His Spirit,
I have no fear.



```

- |   -  |
-------------|------------|
Title | Surely, Surely |
Key |  |
Titles | undefined |
First Line | Surely, surely the Lord has been here, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
