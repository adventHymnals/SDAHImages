---
title: 689. Day by Day, Dear Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 689. Day by Day, Dear Lord. 1. Day by day, Dear Lord, of Thee three things I pray: To see Thee more clearly, Love Thee more dearly, Follow Thee more nearly, Day by day.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Day by Day, Dear Lord, Day by day, Dear Lord, of Thee three things I pray; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 689. DAY BY DAY, DEAR LORD
#### Seventh Day Adventist Hymnal

```txt



1.
Day by day, Dear Lord, of Thee three things I pray:
To see Thee more clearly, Love Thee more dearly,
Follow Thee more nearly, Day by day.



```

- |   -  |
-------------|------------|
Title | Day by Day, Dear Lord |
Key |  |
Titles | undefined |
First Line | Day by day, Dear Lord, of Thee three things I pray: |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
