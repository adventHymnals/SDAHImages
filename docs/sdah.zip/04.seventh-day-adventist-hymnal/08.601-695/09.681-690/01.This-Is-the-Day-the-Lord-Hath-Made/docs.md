---
title: 681. This Is the Day the Lord Hath Made - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 681. This Is the Day the Lord Hath Made. 1. This is the day the Lord hath made; he calls the hours his own. Let heaven rejoice, let earth be glad, and praise surround the throne.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, This Is the Day the Lord Hath Made, This is the day the Lord hath made; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 681. THIS IS THE DAY THE LORD HATH MADE
#### Seventh Day Adventist Hymnal

```txt



1.
This is the day the Lord hath made;
he calls the hours his own.
Let heaven rejoice, let earth be glad,
and praise surround the throne.



```

- |   -  |
-------------|------------|
Title | This Is the Day the Lord Hath Made |
Key |  |
Titles | undefined |
First Line | This is the day the Lord hath made; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
