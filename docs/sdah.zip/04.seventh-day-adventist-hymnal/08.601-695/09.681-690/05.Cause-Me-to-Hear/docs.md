---
title: 685. Cause Me to Hear - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 685. Cause Me to Hear. 1. Cause me to hear Thy loving kindness in the morning, for in Thee do I trust. Cause me to know they way where-in I shall walk for I lift up my soul to Thee. Amen
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Cause Me to Hear, Cause me to hear Thy loving kindness in the morning, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 685. CAUSE ME TO HEAR
#### Seventh Day Adventist Hymnal

```txt



1.
Cause me to hear Thy loving kindness in the morning,
for in Thee do I trust.
Cause me to know they way where-in I shall walk
for I lift up my soul to Thee.
Amen



```

- |   -  |
-------------|------------|
Title | Cause Me to Hear |
Key |  |
Titles | undefined |
First Line | Cause me to hear Thy loving kindness in the morning, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
