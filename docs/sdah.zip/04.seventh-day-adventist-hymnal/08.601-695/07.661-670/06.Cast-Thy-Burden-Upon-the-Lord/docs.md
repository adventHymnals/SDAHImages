---
title: 666. Cast Thy Burden Upon the Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 666. Cast Thy Burden Upon the Lord. 1. Cast thy burden upon the Lord, And He shall sustain thee; He never will suffer the righteous to fall; He is at thy right hand. Thy mercy, Lord, is great, and far above the heavens; Let none be made ashamed, that wait upon Thee.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Cast Thy Burden Upon the Lord, Cast thy burden upon the Lord, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 666. CAST THY BURDEN UPON THE LORD
#### Seventh Day Adventist Hymnal

```txt



1.
Cast thy burden upon the Lord,
And He shall sustain thee;
He never will suffer the righteous to fall;
He is at thy right hand.
Thy mercy, Lord, is great, and far above the heavens;
Let none be made ashamed, that wait upon Thee.



```

- |   -  |
-------------|------------|
Title | Cast Thy Burden Upon the Lord |
Key |  |
Titles | undefined |
First Line | Cast thy burden upon the Lord, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
