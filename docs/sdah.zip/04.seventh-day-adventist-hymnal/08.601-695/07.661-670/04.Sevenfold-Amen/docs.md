---
title: 664. Sevenfold Amen - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 664. Sevenfold Amen. 1. A-men, A-men, A—men, A—–men, A—–men, A—–men, A-men.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Sevenfold Amen, A-men, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 664. SEVENFOLD AMEN
#### Seventh Day Adventist Hymnal

```txt



1.
A-men,
A-men,
A—men,
A—–men,
A—–men,
A—–men,
A-men.



```

- |   -  |
-------------|------------|
Title | Sevenfold Amen |
Key |  |
Titles | undefined |
First Line | A-men, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
