---
title: 663. Amens - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 663. Amens. 1. A-men, A—men.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Amens, A-men, A—men. 
    author: Brian Onang'o
---

#### Advent Hymnals
## 663. AMENS
#### Seventh Day Adventist Hymnal

```txt



1.
A-men, A—men.

2.
A—–men.

3.
A—men.

4.
A—men, (A-men.)

5.
A—–men.

6.
A-men, A-men, A—men.



```

- |   -  |
-------------|------------|
Title | Amens |
Key |  |
Titles | undefined |
First Line | A-men, A—men. |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
