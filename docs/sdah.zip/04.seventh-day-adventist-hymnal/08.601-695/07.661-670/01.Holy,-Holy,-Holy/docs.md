---
title: 661. Holy, Holy, Holy
metadata:
    description: 
    keywords: Seventh Day Adventist Hymnal, Holy, Holy, Holy, , 
    author: Brian Onang'o
---


## 661. HOLY, HOLY, HOLY

```txt
1.
Holy, holy, holy, Holy is the Lord!
Holy, holy, holy, Holy is our God!
He who always liveth, Evermore the same
Heav’n and earth He ruleth, Come and praise His name!

2.
Holy, holy, holy, Holy is the Lord!
Holy, holy, holy, Holy is our God!
Glorious adn beloved Is the One adored!
Holy, holy, holy, Holy is the Lord.
```

- |   -  |
-------------|------------|
Title | Holy, Holy, Holy |
Key |  |
Titles |  |
First Line |  |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas | 2 |
Chorus | No |
Chorus Type | - |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
