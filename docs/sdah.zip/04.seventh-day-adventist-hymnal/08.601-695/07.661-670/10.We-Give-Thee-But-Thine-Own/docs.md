---
title: 670. We Give Thee But Thine Own - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 670. We Give Thee But Thine Own. 1. We give Thee but Thine own, What-e’er the gift may be; All that we have is Thine alone, A trust, O Lord, from Thee.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, We Give Thee But Thine Own, We give Thee but Thine own, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 670. WE GIVE THEE BUT THINE OWN
#### Seventh Day Adventist Hymnal

```txt



1.
We give Thee but Thine own,
What-e’er the gift may be;
All that we have is Thine alone,
A trust, O Lord, from Thee.



```

- |   -  |
-------------|------------|
Title | We Give Thee But Thine Own |
Key |  |
Titles | undefined |
First Line | We give Thee but Thine own, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
