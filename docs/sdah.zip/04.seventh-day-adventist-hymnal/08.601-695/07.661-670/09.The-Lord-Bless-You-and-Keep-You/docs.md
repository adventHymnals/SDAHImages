---
title: 669. The Lord Bless You and Keep You - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 669. The Lord Bless You and Keep You. 1. The Lord bless you and keep you, the Lord life His countenance upon you, and give you peace; the Lord make His face to shine upon you, and be gracious unto you, be gracious, the Lord be gracious unto you. Amen.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The Lord Bless You and Keep You, The Lord bless you and keep you, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 669. THE LORD BLESS YOU AND KEEP YOU
#### Seventh Day Adventist Hymnal

```txt



1.
The Lord bless you and keep you,
the Lord life His countenance upon you,
and give you peace;
the Lord make His face to shine upon you,
and be gracious unto you,
be gracious,
the Lord be gracious unto you.
Amen.



```

- |   -  |
-------------|------------|
Title | The Lord Bless You and Keep You |
Key |  |
Titles | undefined |
First Line | The Lord bless you and keep you, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
