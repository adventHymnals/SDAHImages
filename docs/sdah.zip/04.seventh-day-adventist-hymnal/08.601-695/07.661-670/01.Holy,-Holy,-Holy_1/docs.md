---
title: 661. Holy, Holy, Holy - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 661. Holy, Holy, Holy. 1. Holy, holy, holy, Holy is the Lord! Holy, holy, holy, Holy is our God! He who always liveth, Evermore the same Heav’n and earth He ruleth, Come and praise His name!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Holy, Holy, Holy, Holy, holy, holy, Holy is the Lord! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 661. HOLY, HOLY, HOLY
#### Seventh Day Adventist Hymnal

```txt

1.
Holy, holy, holy, Holy is the Lord!
Holy, holy, holy, Holy is our God!
He who always liveth, Evermore the same
Heav’n and earth He ruleth, Come and praise His name!

2.
Holy, holy, holy, Holy is the Lord!
Holy, holy, holy, Holy is our God!
Glorious adn beloved Is the One adored!
Holy, holy, holy, Holy is the Lord.

```

- |   -  |
-------------|------------|
Title | Holy, Holy, Holy |
Key |  |
Titles | undefined |
First Line | Holy, holy, holy, Holy is the Lord! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
