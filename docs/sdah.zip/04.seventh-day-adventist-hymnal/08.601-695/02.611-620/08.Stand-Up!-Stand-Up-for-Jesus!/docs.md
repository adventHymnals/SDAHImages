---
title: 618. Stand Up! Stand Up for Jesus! - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 618. Stand Up! Stand Up for Jesus!. 1. Stand up, stand up for Jesus! ye soldiers of the cross; Lift high His royal banner, it must not suffer loss: From vict’ry unto vict’ry, His army shall He lead, Till every foe is vanquished, and Christ is Lord indeed.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Stand Up! Stand Up for Jesus!, Stand up, stand up for Jesus! ye soldiers of the cross; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 618. STAND UP! STAND UP FOR JESUS!
#### Seventh Day Adventist Hymnal

```txt



1.
Stand up, stand up for Jesus! ye soldiers of the cross;
Lift high His royal banner, it must not suffer loss:
From vict’ry unto vict’ry, His army shall He lead,
Till every foe is vanquished, and Christ is Lord indeed.

2.
Stand up, stand up for Jesus! The trumpet call obey:
Forth to the mighty conflict, in this His glorious day;
Ye that are men now serve Him against unnumbered foes;
Let courage rise with danger, and strength to strength oppose.

3.
Stand up, stand up for Jesus! Stand in His strength alone,
The arm of flesh will fail you, ye dare not trust your own;
Put on the gospel armor, and watching unto prayer,
Where calls the voice of duty, be never wanting there.

4.
Stand up, stand up for Jesus! the strife will not be long;
This day the noise of battle, the next the victor’s song;
To him that overcometh a crown of life shall be;
He with the King of glory shall reign eternally.



```

- |   -  |
-------------|------------|
Title | Stand Up! Stand Up for Jesus! |
Key |  |
Titles | undefined |
First Line | Stand up, stand up for Jesus! ye soldiers of the cross; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
