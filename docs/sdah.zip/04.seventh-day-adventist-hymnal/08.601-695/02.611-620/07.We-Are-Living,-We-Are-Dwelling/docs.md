---
title: 617. We Are Living, We Are Dwelling - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 617. We Are Living, We Are Dwelling. 1. We are living, we are dwelling, In a grand and awful time, In an age on ages telling– To be living is sublime. Hark! the waking up of nations, Gog and Magog to the fray; Hark! what soundeth? Is creation Groaning for her latter day?
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, We Are Living, We Are Dwelling, We are living, we are dwelling, In a grand and awful time, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 617. WE ARE LIVING, WE ARE DWELLING
#### Seventh Day Adventist Hymnal

```txt



1.
We are living, we are dwelling, In a grand and awful time,
In an age on ages telling– To be living is sublime.
Hark! the waking up of nations, Gog and Magog to the fray;
Hark! what soundeth? Is creation Groaning for her latter day?

2.
Christian, rouse and arm for conflict, Nerve thee for the battlefield;
Bear the helmet of salvation, And the mighty gospel shield;
Let the breastplate, peace, be on thee, Take the Spirit’s sword in hand;
Boldly, fearlessly, go forth then, In Jehovah’s strength to stand.

3.
And the prince of evil spirits, Great deceiver of the world!
He who at the blessed Jesus Once his deadly weapons hurled,
Cometh with unwonted power, Knowing that his reign will cease
When the kingdom shall be given To the mighty Prince of Peace.

4.
Christians, rouse! fight in this warfare, Cease not till the victory’s won;
Till your Captain loud proclaimeth, “Servant of the Lord, well done!”
He, alone, who thus is faithful, Who abideth to the end,
Hath the promise, in the kingdom An eternity to spend.



```

- |   -  |
-------------|------------|
Title | We Are Living, We Are Dwelling |
Key |  |
Titles | undefined |
First Line | We are living, we are dwelling, In a grand and awful time, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
