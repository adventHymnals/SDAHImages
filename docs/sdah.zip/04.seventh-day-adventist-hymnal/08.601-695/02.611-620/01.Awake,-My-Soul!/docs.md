---
title: 611. Awake, My Soul! - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 611. Awake, My Soul!. 1. Awake, my soul! stretch every nerve, And press with vigor on; A heavenly race demands thy zeal, And an immortal crown.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Awake, My Soul!, Awake, my soul! stretch every nerve, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 611. AWAKE, MY SOUL!
#### Seventh Day Adventist Hymnal

```txt



1.
Awake, my soul! stretch every nerve,
And press with vigor on;
A heavenly race demands thy zeal,
And an immortal crown.

2.
’Tis God’s all animating voice
That calls thee from on high;
’Tis He whose hand presents the prize
To thine aspiring eye.

3.
A cloud of witnesses around
Hold thee in full survey;
Forget the steps already trod,
And onward urge thy way.

4.
Blest Savior, introduced by Thee,
Our race have we begun;
And, crowned with victory, at Thy feet
We’ll lay our trophies down.



```

- |   -  |
-------------|------------|
Title | Awake, My Soul! |
Key |  |
Titles | undefined |
First Line | Awake, my soul! stretch every nerve, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
