---
title: 612. Onward, Christian Soldiers! - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 612. Onward, Christian Soldiers!. 1. Onward, Christian soldiers, marching as to war, with the cross of Jesus going on before. Christ, the royal Master, leads against the foe; forward into battle see his banners go! 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Onward, Christian Soldiers!, Onward, Christian soldiers, marching as to war, ,Onward, Christian soldiers, marching as to war,
    author: Brian Onang'o
---

#### Advent Hymnals
## 612. ONWARD, CHRISTIAN SOLDIERS!
#### Seventh Day Adventist Hymnal

```txt



1.
Onward, Christian soldiers, marching as to war,
with the cross of Jesus going on before.
Christ, the royal Master, leads against the foe;
forward into battle see his banners go!


Refrain:
Onward, Christian soldiers, marching as to war,
with the cross of Jesus going on before.


2.
Like a mighty army moves the church of God;
brothers, we are treading where the saints have trod.
We are not divided, all one body we,
one in hope and doctrine, one in charity.


Refrain:
Onward, Christian soldiers, marching as to war,
with the cross of Jesus going on before.

3.
Crowns and thrones my perish, kingdoms rise and wane,
but the church of Jesus constant will remain.
Gates of hell can never ‘gainst that church prevail;
we have Christ’s own promise, and that cannot fail.


Refrain:
Onward, Christian soldiers, marching as to war,
with the cross of Jesus going on before.

4.
Onward then, ye people, join our happy throng,
blend with ours your voices in the triumph song.
Glory, laud, and honor unto Christ the King,
this through countless ages men and angels sing.

Refrain:
Onward, Christian soldiers, marching as to war,
with the cross of Jesus going on before.




```

- |   -  |
-------------|------------|
Title | Onward, Christian Soldiers! |
Key |  |
Titles | Onward, Christian soldiers, marching as to war, |
First Line | Onward, Christian soldiers, marching as to war, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
