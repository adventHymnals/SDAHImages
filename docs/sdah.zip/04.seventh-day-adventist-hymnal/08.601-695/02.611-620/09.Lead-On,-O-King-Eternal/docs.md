---
title: 619. Lead On, O King Eternal - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 619. Lead On, O King Eternal. 1. Lead on, O King eternal, the day of march has come; henceforth in fields of conquest thy tents shall be our home. Through days of preparation thy grace has made us strong; and now, O King eternal, we lift our battle song.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lead On, O King Eternal, Lead on, O King eternal, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 619. LEAD ON, O KING ETERNAL
#### Seventh Day Adventist Hymnal

```txt



1.
Lead on, O King eternal,
the day of march has come;
henceforth in fields of conquest
thy tents shall be our home.
Through days of preparation
thy grace has made us strong;
and now, O King eternal,
we lift our battle song.

2.
Lead on, O King eternal,
till sin’s fierce war shall cease,
and holiness shall whisper
the sweet amen of peace.
For not with swords loud clashing,
nor roll of stirring drums;
with deeds of love and mercy
the heavenly kingdom comes.

3.
Lead on, O King eternal,
we follow, not with fears,
for gladness breaks like morning
where’er thy face appears.
Thy cross is lifted o’er us,
we journey in its light;
the crown awaits the conquest;
lead on, O God of might.



```

- |   -  |
-------------|------------|
Title | Lead On, O King Eternal |
Key |  |
Titles | undefined |
First Line | Lead on, O King eternal, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
