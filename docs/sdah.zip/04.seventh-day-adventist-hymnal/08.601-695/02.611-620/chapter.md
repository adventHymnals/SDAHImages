---
title: Seventh Day Adventist Hymnal - 611-620
metadata:
    description: |
      Seventh Day Adventist Hymnal - 611-620
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 611-620
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 611-620

# Index of Titles
# | Title                        
-- |-------------
611|[Awake, My Soul!](/seventh-day-adventist-hymnal/601-700/611-620/Awake,-My-Soul!)
612|[Onward, Christian Soldiers!](/seventh-day-adventist-hymnal/601-700/611-620/Onward,-Christian-Soldiers!)
613|[Fight the Good Fight](/seventh-day-adventist-hymnal/601-700/611-620/Fight-the-Good-Fight)
614|[Sound the Battle Cry](/seventh-day-adventist-hymnal/601-700/611-620/Sound-the-Battle-Cry)
615|[Rise Up, O Church of God](/seventh-day-adventist-hymnal/601-700/611-620/Rise-Up,-O-Church-of-God)
616|[Soldiers of Christ, Arise](/seventh-day-adventist-hymnal/601-700/611-620/Soldiers-of-Christ,-Arise)
617|[We Are Living, We Are Dwelling](/seventh-day-adventist-hymnal/601-700/611-620/We-Are-Living,-We-Are-Dwelling)
618|[Stand Up! Stand Up for Jesus!](/seventh-day-adventist-hymnal/601-700/611-620/Stand-Up!-Stand-Up-for-Jesus!)
619|[Lead On, O King Eternal](/seventh-day-adventist-hymnal/601-700/611-620/Lead-On,-O-King-Eternal)
620|[On Jordan\`s Stormy Banks](/seventh-day-adventist-hymnal/601-700/611-620/On-Jordan`s-Stormy-Banks)