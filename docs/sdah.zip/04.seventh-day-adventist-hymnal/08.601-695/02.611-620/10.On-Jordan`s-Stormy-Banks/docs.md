---
title: 620. On Jordan`s Stormy Banks - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 620. On Jordan`s Stormy Banks. 1. On Jordan’s stormy banks I stand, And cast a wishful eye To Canaan’s fair and happy land, Where my possessions lie. I am bound for the promised land, I am bound for the promised land; O who will come and go with me? I am bound for the promised land.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, On Jordan`s Stormy Banks, On Jordan’s stormy banks I stand, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 620. ON JORDAN`S STORMY BANKS
#### Seventh Day Adventist Hymnal

```txt



1.
On Jordan’s stormy banks I stand,
And cast a wishful eye
To Canaan’s fair and happy land,
Where my possessions lie.
I am bound for the promised land,
I am bound for the promised land;
O who will come and go with me?
I am bound for the promised land.

2.
O’er all those wide extended plain
Shines one eternal day;
There, Christ, the Sun, for ever reigns,
And scatters night away.
I am bound for the promised land,
I am bound for the promised land;
O who will come and go with me?
I am bound for the promised land.

3.
When shall I reach that happy place,
And be forever blest?
When shall I see my Father’s face,
And in His kingdom rest?
I am bound for the promised land,
I am bound for the promised land;
O who will come and go with me?
I am bound for the promised land.

4.
Filled with delight, my raptured soul
Would here no longer stay;
Though Jordan’s waves around me roll,
Fearless I’d launch away.
I am bound for the promised land,
I am bound for the promised land;
O who will come and go with me?
I am bound for the promised land.



```

- |   -  |
-------------|------------|
Title | On Jordan`s Stormy Banks |
Key |  |
Titles | undefined |
First Line | On Jordan’s stormy banks I stand, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
