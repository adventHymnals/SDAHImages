---
title: 614. Sound the Battle Cry - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 614. Sound the Battle Cry. 1. Sound the battle cry, See! the foe is nigh; Raise the standard high For the Lord; Gird your armor on, Stand firm, every one, Rest your cause upon His holy word. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Sound the Battle Cry, Sound the battle cry, ,Rouse, then soldiers!
    author: Brian Onang'o
---

#### Advent Hymnals
## 614. SOUND THE BATTLE CRY
#### Seventh Day Adventist Hymnal

```txt



1.
Sound the battle cry,
See! the foe is nigh;
Raise the standard high
For the Lord;
Gird your armor on,
Stand firm, every one,
Rest your cause upon His holy word.


Refrain:
Rouse, then soldiers!
rally round the banner!
Ready, steady, pass the word along;
Onward, forward, shout aloud hosanna!
Christ is Captain of the mighty throng.


2.
Strong to meet the foe,
Marching on we go,
While our cause we know
Must prevail;
Shield and banner bright,
Gleaming in the light,
Battling for the right,
We ne’er can fail.


Refrain:
Rouse, then soldiers!
rally round the banner!
Ready, steady, pass the word along;
Onward, forward, shout aloud hosanna!
Christ is Captain of the mighty throng.

3.
O Thou God of all,
Hear us when we call,
Help us, one and all,
By Thy grace;
When the battle’s done,
And the victory won,
May we wear the crown
Before Thy face.

Refrain:
Rouse, then soldiers!
rally round the banner!
Ready, steady, pass the word along;
Onward, forward, shout aloud hosanna!
Christ is Captain of the mighty throng.




```

- |   -  |
-------------|------------|
Title | Sound the Battle Cry |
Key |  |
Titles | Rouse, then soldiers! |
First Line | Sound the battle cry, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
