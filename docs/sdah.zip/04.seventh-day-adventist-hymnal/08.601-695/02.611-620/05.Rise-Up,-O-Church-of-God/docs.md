---
title: 615. Rise Up, O Church of God - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 615. Rise Up, O Church of God. 1. Rise up, O men of God! His kingdom tarries long. Bring in the day of brotherhood and end the night of wrong.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Rise Up, O Church of God, Rise up, O men of God! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 615. RISE UP, O CHURCH OF GOD
#### Seventh Day Adventist Hymnal

```txt



1.
Rise up, O men of God!
His kingdom tarries long.
Bring in the day of brotherhood
and end the night of wrong.

2.
Let women all rise up!
Have done with lesser things.
Give heart and mind and soul and strength
to serve the King of kings.

3.
Rise up, courageous youth!
The church for you doth wait,
her strength unequal to her task;
rise up, and make her great!

4.
Lift high the cross of Christ!
Tread where his feet have trod.
Disciples of the Son of Man,
rise up, O church of God!



```

- |   -  |
-------------|------------|
Title | Rise Up, O Church of God |
Key |  |
Titles | undefined |
First Line | Rise up, O men of God! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
