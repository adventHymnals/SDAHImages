---
title: 613. Fight the Good Fight - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 613. Fight the Good Fight. 1. Fight the good fight with all thy might; Christ is thy strength, and Christ thy right; Lay hold on life and it shall be Thy joy and crown eternally.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Fight the Good Fight, Fight the good fight with all thy might; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 613. FIGHT THE GOOD FIGHT
#### Seventh Day Adventist Hymnal

```txt



1.
Fight the good fight with all thy might;
Christ is thy strength, and Christ thy right;
Lay hold on life and it shall be
Thy joy and crown eternally.

2.
Run the straight race through God’s good grace;
Lift up thine eyes, and seek His face.
Life with its path before us lies;
Christ is the way, and Christ the prize.

3.
Cast care aside, lean on thy guide,
His boundless mercy will provide;
Trust, and the trusting soul shall prove
Christ is its life, and Christ its love.

4.
Faint not, nor fear, His arms are near;
He changeth not, and thou art dear.
Only believe, and thou shalt see
That Christ is all in all to thee.



```

- |   -  |
-------------|------------|
Title | Fight the Good Fight |
Key |  |
Titles | undefined |
First Line | Fight the good fight with all thy might; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
