---
title: 616. Soldiers of Christ, Arise - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 616. Soldiers of Christ, Arise. 1. Soldiers of Christ,arise, And put your armor on, Strong in the strength which God supplies Through His eternal Son Strong in the Lord of hosts, And in His mighty power, Who in the strength of Jesus trusts Is more than conqueror.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Soldiers of Christ, Arise, Soldiers of Christ,arise, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 616. SOLDIERS OF CHRIST, ARISE
#### Seventh Day Adventist Hymnal

```txt



1.
Soldiers of Christ,arise,
And put your armor on,
Strong in the strength which God supplies
Through His eternal Son
Strong in the Lord of hosts,
And in His mighty power,
Who in the strength of Jesus trusts
Is more than conqueror.

2.
Stand then in His great might,
With all His strength endued,
But take, to arm you for the fight,
The panoply of God;
That, having all things done,
And all your conflicts passed,
Ye may o’ercome through Christ alone,
And stand entire at last.

3.
From strength to strength go on,
Wrestle and fight and pray,
Tread all the powers of darkness down
And win the well-fought day.
Still let the Spirit cry
In all His soldiers, “Come!”
Till Christ the Lord who reigns on high
Shall take the conquerors home.



```

- |   -  |
-------------|------------|
Title | Soldiers of Christ, Arise |
Key |  |
Titles | undefined |
First Line | Soldiers of Christ,arise, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
