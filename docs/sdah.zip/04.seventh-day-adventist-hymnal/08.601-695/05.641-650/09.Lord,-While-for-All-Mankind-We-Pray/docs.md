---
title: 649. Lord, While for All Mankind We Pray - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 649. Lord, While for All Mankind We Pray. 1. Lord, while for all mankind we pray Of every clime and coast, O hear us for our native land, The land we love the most!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord, While for All Mankind We Pray, Lord, while for all mankind we pray 
    author: Brian Onang'o
---

#### Advent Hymnals
## 649. LORD, WHILE FOR ALL MANKIND WE PRAY
#### Seventh Day Adventist Hymnal

```txt



1.
Lord, while for all mankind we pray
Of every clime and coast,
O hear us for our native land,
The land we love the most!

2.
O guard our shores from every foe,
With peace our borders bless;
With prosperous times our cities crown,
Our fields with plenteousness!

3.
Unite us in the sacred love
Of knowledge, truth, and Thee;
And let our hills and valleys shout
The songs of liberty.

4.
Lord of the nations, thus to Thee
Our country we commend;
Be Thou her Refuge and her trust,
Her everlasting friend.



```

- |   -  |
-------------|------------|
Title | Lord, While for All Mankind We Pray |
Key |  |
Titles | undefined |
First Line | Lord, while for all mankind we pray |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
