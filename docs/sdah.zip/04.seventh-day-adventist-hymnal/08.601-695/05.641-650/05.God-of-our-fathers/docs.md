---
title: 645. God of our fathers - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 645. God of our fathers. 1. God of our fathers, Whose almighty hand Leads forth in beauty all the starry band Of shining worlds in splendor through the skies Our grateful songs before Thy throne arise.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God of our fathers, God of our fathers, Whose almighty hand 
    author: Brian Onang'o
---

#### Advent Hymnals
## 645. GOD OF OUR FATHERS
#### Seventh Day Adventist Hymnal

```txt



1.
God of our fathers, Whose almighty hand
Leads forth in beauty all the starry band
Of shining worlds in splendor through the skies
Our grateful songs before Thy throne arise.

2.
Thy love divine hath led us in the past,
In this free land by Thee our lot is cast,
Be Thou our Ruler, Guardian, Guide and Stay,
Thy Word our law, Thy paths our chosen way.

3.
From war’s alarms, from deadly pestilence,
Be Thy strong arm our ever sure defense;
Thy true religion in our hearts increase,
Thy bounteous goodness nourish us in peace.

4.
Refresh Thy people on their toilsome way,
Lead us from night to never ending day;
Fill all our lives with love and grace divine,
And glory, laud, and praise be ever Thine.



```

- |   -  |
-------------|------------|
Title | God of our fathers |
Key |  |
Titles | undefined |
First Line | God of our fathers, Whose almighty hand |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
