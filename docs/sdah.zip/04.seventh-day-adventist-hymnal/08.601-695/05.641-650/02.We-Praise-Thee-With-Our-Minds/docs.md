---
title: 642. We Praise Thee With Our Minds - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 642. We Praise Thee With Our Minds. 1. We praise Thee with our minds, O LordKept sharp think Thy thought;Come, Holy Ghost with grace outpoured, To teach what Christ hath taught. In all our learning may we seekThat wisdom from above Which comes to all: the brave, the meekWho ask in faith and love.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, We Praise Thee With Our Minds, We praise Thee with our minds, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 642. WE PRAISE THEE WITH OUR MINDS
#### Seventh Day Adventist Hymnal

```txt



1.
We praise Thee with our minds,
O LordKept sharp think Thy thought;Come,
Holy Ghost with grace outpoured,
To teach what Christ hath taught.
In all our learning may we seekThat wisdom from above
Which comes to all: the brave,
the meekWho ask in faith and love.

2.
We praise Thee thro’ our bodies,
Lord,Kept strong to do Thy will;
Thy Spirit’s temples, which afford
A means to praise Thee still.
We give ourselves, a sacrifice,
To live as unto Thee;
For Thou alone hast paid the priceTo bring salvation free.

3.
We praise Thee in our hearts,
O king,Kept pure to know Thy ways;
And raise to Thee a hymn to sing
Eternally Thy praise.
Altho adoring hearts will bow
As age on ages roll;
We praise Thee in our beings now,
Mind, body, heart, and soul.



```

- |   -  |
-------------|------------|
Title | We Praise Thee With Our Minds |
Key |  |
Titles | undefined |
First Line | We praise Thee with our minds, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
