---
title: 643. Father, Who on Us Do Shower - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 643. Father, Who on Us Do Shower. 1. Father, who on us do shower Gifts of plenty form Your dower, To Your people give the power All Your gifts to use aright.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Father, Who on Us Do Shower, Father, who on us do shower 
    author: Brian Onang'o
---

#### Advent Hymnals
## 643. FATHER, WHO ON US DO SHOWER
#### Seventh Day Adventist Hymnal

```txt



1.
Father, who on us do shower
Gifts of plenty form Your dower,
To Your people give the power
All Your gifts to use aright.

2.
Give pure happiness in leisure
Temperance in every pleasure,
Wholesome use of earthly treasure
Bodies clean and spirits bright.

3.
Lift from this and every nation
All that brings us degradation;
Quell the forces of temptation;
Put Your enemies to flight.

4.
Father, You who sought and found us,
Son of God, whose love has bound us,
Holy Spirit, in us, round us,
Hear us, Godhead infinite.



```

- |   -  |
-------------|------------|
Title | Father, Who on Us Do Shower |
Key |  |
Titles | undefined |
First Line | Father, who on us do shower |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
