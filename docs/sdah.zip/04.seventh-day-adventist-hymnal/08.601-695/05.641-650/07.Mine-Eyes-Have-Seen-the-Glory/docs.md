---
title: 647. Mine Eyes Have Seen the Glory - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 647. Mine Eyes Have Seen the Glory. 1. Mine eyes have seen the glory of the coming of the Lord; He is trampling out the vintage where the grapes of wrath are stored; He has loosed the fateful lightning of His terrible swift sword; His truth is marching on. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Mine Eyes Have Seen the Glory, Mine eyes have seen the glory of the coming of the Lord; ,Glory! Glory! Hallelujah! Glory! Glory! Hallelujah!
    author: Brian Onang'o
---

#### Advent Hymnals
## 647. MINE EYES HAVE SEEN THE GLORY
#### Seventh Day Adventist Hymnal

```txt



1.
Mine eyes have seen the glory of the coming of the Lord;
He is trampling out the vintage where the grapes of wrath are stored;
He has loosed the fateful lightning of His terrible swift sword;
His truth is marching on.


Refrain:
Glory! Glory! Hallelujah! Glory! Glory! Hallelujah!
Glory! Glory! Hallelujah! His truth is marching on.


2.
He has sounded forth the trumpet that shall never call retreat;
He is sifting out the hearts of men before His judgment seat;
O be swift, my soul, to answer Him! be jubilant, my feet!
Our God is marching on.


Refrain:
Glory! Glory! Hallelujah! Glory! Glory! Hallelujah!
Glory! Glory! Hallelujah! His truth is marching on.

3.
In the beauty of the lilies Christ was born across the sea,
With a glory in His bosom that transfigures you and me;
As He died to make men holy, let us live to make men free!
While God is marching on.

Refrain:
Glory! Glory! Hallelujah! Glory! Glory! Hallelujah!
Glory! Glory! Hallelujah! His truth is marching on.




```

- |   -  |
-------------|------------|
Title | Mine Eyes Have Seen the Glory |
Key |  |
Titles | Glory! Glory! Hallelujah! Glory! Glory! Hallelujah! |
First Line | Mine eyes have seen the glory of the coming of the Lord; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
