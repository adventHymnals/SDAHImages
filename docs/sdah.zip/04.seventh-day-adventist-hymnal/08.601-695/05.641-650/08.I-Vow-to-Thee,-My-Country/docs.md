---
title: 648. I Vow to Thee, My Country - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 648. I Vow to Thee, My Country. 1. I vow to thee, my country, all earthly things above, Entire and whole and perfect, the service of my love: The love that asks the reason, the love that stands the test, That lays upon the altar the dearest and the best; The love that never falters, the love that pays the price, The love that makes undaunted the final sacrifice.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Vow to Thee, My Country, I vow to thee, my country, all earthly things above, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 648. I VOW TO THEE, MY COUNTRY
#### Seventh Day Adventist Hymnal

```txt



1.
I vow to thee, my country, all earthly things above,
Entire and whole and perfect, the service of my love:
The love that asks the reason, the love that stands the test,
That lays upon the altar the dearest and the best;
The love that never falters, the love that pays the price,
The love that makes undaunted the final sacrifice.

2.
And there’s another country, I’ve heard of long ago,
Most dear to them that love her, most great to them that know;
We may not count her armies, we may not see her King;
Her fortress is a faithful heart, her pride is suffering;
And one by one and fervently we pray for her increase,
And her ways are ways of gentleness, and all her paths are peace.



```

- |   -  |
-------------|------------|
Title | I Vow to Thee, My Country |
Key |  |
Titles | undefined |
First Line | I vow to thee, my country, all earthly things above, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
