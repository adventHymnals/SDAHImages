---
title: 641. God in His Love for Us - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 641. God in His Love for Us. 1. God in His love for us lent us this planet, Gave it a purpose in time and in space: Small as a spark from the fire of creation, Cradle of life and the home of our race.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God in His Love for Us, God in His love for us lent us this planet, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 641. GOD IN HIS LOVE FOR US
#### Seventh Day Adventist Hymnal

```txt



1.
God in His love for us lent us this planet,
Gave it a purpose in time and in space:
Small as a spark from the fire of creation,
Cradle of life and the home of our race.

2.
Thanks be to God for its bounty and beauty,
Life that sustains us in body and mind:
Plenty for all, if we learn how to share it,
Riches undreamed of to fathom and find.

3.
Long have our human wars ruined its harvest;
Long has earth bowed to the terror of forced;
Long have we wasted what others have need of,
Poisoned the fountain of life at its source.

4.
Earth is the Lord’s: it is ours to enjoy it,
Ours, as His stewards, to farm and defend.
From its pollution, misuse, and destruction,
Good Lord, deliver us, world without end!



```

- |   -  |
-------------|------------|
Title | God in His Love for Us |
Key |  |
Titles | undefined |
First Line | God in His love for us lent us this planet, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
