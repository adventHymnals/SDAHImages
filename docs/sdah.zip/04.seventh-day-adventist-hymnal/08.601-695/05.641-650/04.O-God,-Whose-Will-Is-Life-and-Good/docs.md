---
title: 644. O God, Whose Will Is Life and Good - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 644. O God, Whose Will Is Life and Good. 1. O God, whose will is life and good For all of mortal breath: Unite in bonds of servanthood All those who strive with death.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O God, Whose Will Is Life and Good, O God, whose will is life and good 
    author: Brian Onang'o
---

#### Advent Hymnals
## 644. O GOD, WHOSE WILL IS LIFE AND GOOD
#### Seventh Day Adventist Hymnal

```txt



1.
O God, whose will is life and good
For all of mortal breath:
Unite in bonds of servanthood
All those who strive with death.

2.
Make strong their hands and hearts and wills
To drive disease afar,
To strive against the body’s ills
And wage Your healing war.

3.
By healing of the sick and blind,
Christ’s mercy they proclaim,
Make known the great physician’s mind,
Affirm the Savior’s name.

4.
Before them set Your gracious will,
That they, with heart and soul,
To You may consecrate their skill
And make the sufferer whole.



```

- |   -  |
-------------|------------|
Title | O God, Whose Will Is Life and Good |
Key |  |
Titles | undefined |
First Line | O God, whose will is life and good |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
