---
title: 650. Our Father, by Whose Name - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 650. Our Father, by Whose Name. 1. Our Father, by whose name, All fatherhood is known, Who dost in love proclaimEach family Thine own, Bless Thou all parents, guarding well, With constant love as sentinel, The homes in which Thy people dwell.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Our Father, by Whose Name, Our Father, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 650. OUR FATHER, BY WHOSE NAME
#### Seventh Day Adventist Hymnal

```txt



1.
Our Father,
by whose name,
All fatherhood is known,
Who dost in love proclaimEach family Thine own,
Bless Thou all parents,
guarding well,
With constant love as sentinel,
The homes in which Thy people dwell.

2.
O Christ,
Thyself a childWithin an earthly home,
With heart still undefiled,
Thou didst to manhood come;
Our children bless, in every place,
That they may all behold Thy face,
And knowing Thee may grow in grace.

3.
O Spirit,
who dost bindOur hearts in unity,
Who teaches us to findThe love from self set free,
In all our hearts such love increase,
That every home, by this release,
May be dwelling place of peace.



```

- |   -  |
-------------|------------|
Title | Our Father, by Whose Name |
Key |  |
Titles | undefined |
First Line | Our Father, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
