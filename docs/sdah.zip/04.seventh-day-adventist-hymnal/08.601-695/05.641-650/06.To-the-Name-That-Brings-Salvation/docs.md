---
title: 646. To the Name That Brings Salvation - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 646. To the Name That Brings Salvation. 1. To the name that brings salvation Let the nations bow the head; Let them kneel in adoration When this name of names is said; Let them pray for restoration Of all things in Christ the head.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, To the Name That Brings Salvation, To the name that brings salvation 
    author: Brian Onang'o
---

#### Advent Hymnals
## 646. TO THE NAME THAT BRINGS SALVATION
#### Seventh Day Adventist Hymnal

```txt



1.
To the name that brings salvation
Let the nations bow the head;
Let them kneel in adoration
When this name of names is said;
Let them pray for restoration
Of all things in Christ the head.

2.
He through every generation
Rules in endless majesty;
May the kings of every nation
Now foreswear their enmity,
And with humble veneration
In the love of God agree.

3.
Lord, we pray for upright rulers:
Guard them surely in their need
From the vanity of power
And the emptiness of greed;
Let them see the truth of lowness,
And on justice let them feed.



```

- |   -  |
-------------|------------|
Title | To the Name That Brings Salvation |
Key |  |
Titles | undefined |
First Line | To the name that brings salvation |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
