---
title: 629. O Happy Band of Pilgrims - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 629. O Happy Band of Pilgrims. 1. O happy band of pilgrims, If onward ye will tread With Jesus as your fellow, To Jesus as your Head!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Happy Band of Pilgrims, O happy band of pilgrims, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 629. O HAPPY BAND OF PILGRIMS
#### Seventh Day Adventist Hymnal

```txt



1.
O happy band of pilgrims,
If onward ye will tread
With Jesus as your fellow,
To Jesus as your Head!

2.
O happy if ye labor
As Jesus did for men;
O happy if ye hunger
As Jesus hungered then!

3.
The trials that beset you,
The sorrows ye endure,
The manifold temptations
That death alone can cure,

4.
What are they but His jewels
Of right celestial worth?
What are they but the ladder
Set up to heaven on earth?

5.
O happy band of pilgrims,
Look upward to the skies,
Where such a light affliction
Shall win you such a prize!



```

- |   -  |
-------------|------------|
Title | O Happy Band of Pilgrims |
Key |  |
Titles | undefined |
First Line | O happy band of pilgrims, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
