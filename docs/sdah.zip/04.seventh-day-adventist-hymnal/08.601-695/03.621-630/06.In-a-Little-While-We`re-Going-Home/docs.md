---
title: 626. In a Little While We`re Going Home - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 626. In a Little While We`re Going Home. 1. Let us sing a song that will cheer us by the way, In a little while we’re going home. For the night will end in the everlasting day, In a little while we’re going home. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, In a Little While We`re Going Home, Let us sing a song that will cheer us by the way, ,In a little while, In a little while,
    author: Brian Onang'o
---

#### Advent Hymnals
## 626. IN A LITTLE WHILE WE`RE GOING HOME
#### Seventh Day Adventist Hymnal

```txt



1.
Let us sing a song that will cheer us by the way,
In a little while we’re going home.
For the night will end in the everlasting day,
In a little while we’re going home.


Refrain:
In a little while, In a little while,
We shall cross the billow’s foam;
We shall meet at last, When the stormy winds are past,
In a little while we’re going home.


2.
We will do the work that our hands may find to do,
In a little while we’re going home.
And the grace of God will our daily strength renew,
In a little while we’re going home.


Refrain:
In a little while, In a little while,
We shall cross the billow’s foam;
We shall meet at last, When the stormy winds are past,
In a little while we’re going home.

3.
We will smooth the path for some weary, wayworn feet,
In a little while we’re going home.
And may loving hearts spread around an influence sweet!
In a little while we’re going home.


Refrain:
In a little while, In a little while,
We shall cross the billow’s foam;
We shall meet at last, When the stormy winds are past,
In a little while we’re going home.

4.
There’s a rest beyond, there’s relief from every care,
In a little while we’re going home;
And no tears shall fall in that city bright and fair,
In a little while we’re going home.

Refrain:
In a little while, In a little while,
We shall cross the billow’s foam;
We shall meet at last, When the stormy winds are past,
In a little while we’re going home.




```

- |   -  |
-------------|------------|
Title | In a Little While We`re Going Home |
Key |  |
Titles | In a little while, In a little while, |
First Line | Let us sing a song that will cheer us by the way, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
