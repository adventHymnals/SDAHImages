---
title: Seventh Day Adventist Hymnal - 621-630
metadata:
    description: |
      Seventh Day Adventist Hymnal - 621-630
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 621-630
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 621-630

# Index of Titles
# | Title                        
-- |-------------
621|[Gracious Father, Guard Thy Children](/seventh-day-adventist-hymnal/601-700/621-630/Gracious-Father,-Guard-Thy-Children)
622|[Come, Come, Ye Saints](/seventh-day-adventist-hymnal/601-700/621-630/Come,-Come,-Ye-Saints)
623|[I Will Follow Thee](/seventh-day-adventist-hymnal/601-700/621-630/I-Will-Follow-Thee)
624|[I Want Jesus to Walk With Me](/seventh-day-adventist-hymnal/601-700/621-630/I-Want-Jesus-to-Walk-With-Me)
625|[Higher Ground](/seventh-day-adventist-hymnal/601-700/621-630/Higher-Ground)
626|[In a Little While We\`re Going Home](/seventh-day-adventist-hymnal/601-700/621-630/In-a-Little-While-We`re-Going-Home)
627|[Jacob\`s Ladder](/seventh-day-adventist-hymnal/601-700/621-630/Jacob`s-Ladder)
628|[As Jacob With Travel Was Weary](/seventh-day-adventist-hymnal/601-700/621-630/As-Jacob-With-Travel-Was-Weary)
629|[O Happy Band of Pilgrims](/seventh-day-adventist-hymnal/601-700/621-630/O-Happy-Band-of-Pilgrims)
630|[Rise, My Soul, and Stretch Thy Wings](/seventh-day-adventist-hymnal/601-700/621-630/Rise,-My-Soul,-and-Stretch-Thy-Wings)