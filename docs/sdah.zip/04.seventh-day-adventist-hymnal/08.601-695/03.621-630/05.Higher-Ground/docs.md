---
title: 625. Higher Ground - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 625. Higher Ground. 1. I’m pressing on the upward way, New heights I’m gaining every day; Still praying as I’m onward bound, “Lord, plant my feet on higher ground.” 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Higher Ground, I’m pressing on the upward way, ,Lord, lift me up and let me stand,
    author: Brian Onang'o
---

#### Advent Hymnals
## 625. HIGHER GROUND
#### Seventh Day Adventist Hymnal

```txt



1.
I’m pressing on the upward way,
New heights I’m gaining every day;
Still praying as I’m onward bound,
“Lord, plant my feet on higher ground.”


Refrain:
Lord, lift me up and let me stand,
By faith, on Heaven’s table land,
A higher plane than I have found;
Lord, plant my feet on higher ground.


2.
My heart has no desire to stay
Where doubts arise and fears dismay;
Though some may dwell where those abound,
My prayer, my aim, is higher ground.


Refrain:
Lord, lift me up and let me stand,
By faith, on Heaven’s table land,
A higher plane than I have found;
Lord, plant my feet on higher ground.

3.
I want to live above the world,
Though Satan’s darts at me are hurled;
For faith has caught the joyful sound,
The song of saints on higher ground.


Refrain:
Lord, lift me up and let me stand,
By faith, on Heaven’s table land,
A higher plane than I have found;
Lord, plant my feet on higher ground.

4.
I want to scale the utmost height
And catch a gleam of glory bright;
But still I’ll pray till Heav’n I’ve found,
“Lord, plant my feet on higher ground.”

Refrain:
Lord, lift me up and let me stand,
By faith, on Heaven’s table land,
A higher plane than I have found;
Lord, plant my feet on higher ground.




```

- |   -  |
-------------|------------|
Title | Higher Ground |
Key |  |
Titles | Lord, lift me up and let me stand, |
First Line | I’m pressing on the upward way, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
