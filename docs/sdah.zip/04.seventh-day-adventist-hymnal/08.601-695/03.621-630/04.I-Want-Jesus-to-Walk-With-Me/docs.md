---
title: 624. I Want Jesus to Walk With Me - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 624. I Want Jesus to Walk With Me. 1. I want Jesus to walk with me. (walk with me) I want Jesus to walk with me. (walk with me) All along my pilgrim journey, I want Jesus to walk with me. (walk with me)
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Want Jesus to Walk With Me, I want Jesus to walk with me. 
    author: Brian Onang'o
---

#### Advent Hymnals
## 624. I WANT JESUS TO WALK WITH ME
#### Seventh Day Adventist Hymnal

```txt



1.
I want Jesus to walk with me.
(walk with me)
I want Jesus to walk with me.
(walk with me)
All along my pilgrim journey,
I want Jesus to walk with me.
(walk with me)

2.
In my trials, Lord walk with me.
(walk with me)
In my trials, Lord walk with me.
(walk with me)
When the shades of life are falling,
I want Jesus to walk with me.
(walk with me)

3.
In my sorrows, Lord walk with me.
(walk with me)
In my sorrows, Lord walk with me.
(walk with me)
When my heart within is aching,
I want Jesus to walk with me.
(walk with me)



```

- |   -  |
-------------|------------|
Title | I Want Jesus to Walk With Me |
Key |  |
Titles | undefined |
First Line | I want Jesus to walk with me. |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
