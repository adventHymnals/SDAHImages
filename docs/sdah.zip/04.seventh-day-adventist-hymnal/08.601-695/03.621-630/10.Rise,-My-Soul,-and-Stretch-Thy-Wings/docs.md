---
title: 630. Rise, My Soul, and Stretch Thy Wings - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 630. Rise, My Soul, and Stretch Thy Wings. 1. Rise, my soul, and stretch thy wings, thy better portion trace; Rise from transitory things toward heaven, thy native place; Sun, and moon, and stars decay; time shall soon this earth remove; Rise, my soul, and haste away to seats prepared above.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Rise, My Soul, and Stretch Thy Wings, Rise, my soul, and stretch thy wings, thy better portion trace; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 630. RISE, MY SOUL, AND STRETCH THY WINGS
#### Seventh Day Adventist Hymnal

```txt



1.
Rise, my soul, and stretch thy wings, thy better portion trace;
Rise from transitory things toward heaven, thy native place;
Sun, and moon, and stars decay; time shall soon this earth remove;
Rise, my soul, and haste away to seats prepared above.

2.
Rivers to the ocean run, nor stay in all their course;
Fire ascending seeks the sun; both speed them to their source;
So a soul that’s born of God, longs to view His glorious face,
Forward tends to His abode to rest in His embrace.

3.
Cease, ye pilgrims, cease to mourn; press onward to the prize;
Soon our Savior will return, triumphant in the skies;
Yet a season, and you know happy entrance will be given,
All our sorrows left below, and earth exhcanged for heaven.



```

- |   -  |
-------------|------------|
Title | Rise, My Soul, and Stretch Thy Wings |
Key |  |
Titles | undefined |
First Line | Rise, my soul, and stretch thy wings, thy better portion trace; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
