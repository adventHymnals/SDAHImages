---
title: 621. Gracious Father, Guard Thy Children - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 621. Gracious Father, Guard Thy Children. 1. Gracious Father, guard Thy children From the foe’s destructive power; Save, O save them, Lord, from falling In this dark and trying hour. Thou wilt surely prove Thy people, All our graces must be tried; But Thy word illumes our pathway, And in God we still confide.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Gracious Father, Guard Thy Children, Gracious Father, guard Thy children 
    author: Brian Onang'o
---

#### Advent Hymnals
## 621. GRACIOUS FATHER, GUARD THY CHILDREN
#### Seventh Day Adventist Hymnal

```txt



1.
Gracious Father, guard Thy children
From the foe’s destructive power;
Save, O save them, Lord, from falling
In this dark and trying hour.
Thou wilt surely prove Thy people,
All our graces must be tried;
But Thy word illumes our pathway,
And in God we still confide.

2.
We are in the time of waiting;
Soon we shall behold our Lord,
Wafted far away from sorrow,
To receive our rich reward.
Keep us, Lord, till Thine appearing,
Pure, unspotted from the world;
Let Thy Holy Spirit cheer us
Till Thy banner is unfurled.

3.
With what joyful exultation
Shall the saints Thy banner see,
When the Lord for whom we’ve waited
Shall proclaim the jubilee!
Freedom from this world’s pollutions;
Freedom from all sin and pain;
Freedom from the wiles of Satan,
And from death’s destructive reign.



```

- |   -  |
-------------|------------|
Title | Gracious Father, Guard Thy Children |
Key |  |
Titles | undefined |
First Line | Gracious Father, guard Thy children |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
