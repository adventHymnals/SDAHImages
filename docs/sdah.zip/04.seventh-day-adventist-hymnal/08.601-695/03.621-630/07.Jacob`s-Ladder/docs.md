---
title: 627. Jacob`s Ladder - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 627. Jacob`s Ladder. 1. We are climbing Jacob’s ladder, We are climbing Jacob’s ladder, We are climbing Jacob’s ladder, Soldiers of the cross.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Jacob`s Ladder, We are climbing Jacob’s ladder, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 627. JACOB`S LADDER
#### Seventh Day Adventist Hymnal

```txt



1.
We are climbing Jacob’s ladder,
We are climbing Jacob’s ladder,
We are climbing Jacob’s ladder,
Soldiers of the cross.

2.
Every round goes higher, higher,
Every round goes higher, higher,
Every round goes higher, higher,
Soldiers of the cross.

3.
Sinner, do you love my Jesus?
Sinner, do you love my Jesus?
Sinner, do you love my Jesus?
Soldiers of the cross.

4.
If you love him, why not serve him?
If you love him, why not serve him?
If you love him, why not serve him?
Soldiers of the cross.



```

- |   -  |
-------------|------------|
Title | Jacob`s Ladder |
Key |  |
Titles | undefined |
First Line | We are climbing Jacob’s ladder, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
