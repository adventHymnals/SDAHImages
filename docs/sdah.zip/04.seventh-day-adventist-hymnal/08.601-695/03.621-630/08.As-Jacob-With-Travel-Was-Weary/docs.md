---
title: 628. As Jacob With Travel Was Weary - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 628. As Jacob With Travel Was Weary. 1. As Jacob with travel was weary one day, At night on a stone for a pillow he lay; He saw in a vision a ladder so high That its foot was on earth and its top in the sky. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, As Jacob With Travel Was Weary, As Jacob with travel was weary one day, ,Alleluia to Jesus who died on the tree,
    author: Brian Onang'o
---

#### Advent Hymnals
## 628. AS JACOB WITH TRAVEL WAS WEARY
#### Seventh Day Adventist Hymnal

```txt



1.
As Jacob with travel was weary one day,
At night on a stone for a pillow he lay;
He saw in a vision a ladder so high
That its foot was on earth and its top in the sky.


Refrain:
Alleluia to Jesus who died on the tree,
And has raised up a ladder of mercy for me,
And has raised up a ladder of mercy for me.


2.
Come let us ascend! All may climb it who will;
For the angels of Jacob are guarding it still:
And remember each step that by faith we passo’er,
Some prophet or martyr has trod it before.


Refrain:
Alleluia to Jesus who died on the tree,
And has raised up a ladder of mercy for me,
And has raised up a ladder of mercy for me.

3.
And when we arrive at the haven of rest
We shall hear the glad words, “Come up hither, ye blest,
Here are regions of light, here are mansions of bliss.”
O who would not climb such a ladder as this?

Refrain:
Alleluia to Jesus who died on the tree,
And has raised up a ladder of mercy for me,
And has raised up a ladder of mercy for me.




```

- |   -  |
-------------|------------|
Title | As Jacob With Travel Was Weary |
Key |  |
Titles | Alleluia to Jesus who died on the tree, |
First Line | As Jacob with travel was weary one day, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
