---
title: 623. I Will Follow Thee - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 623. I Will Follow Thee. 1. I will follow Thee, my Savior, Wheresoe’er my lot may be. Where thou goest I will follow; Yes, my Lord, I’ll follow Thee. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Will Follow Thee, I will follow Thee, my Savior, ,I will follow Thee, my Saviour,
    author: Brian Onang'o
---

#### Advent Hymnals
## 623. I WILL FOLLOW THEE
#### Seventh Day Adventist Hymnal

```txt



1.
I will follow Thee, my Savior,
Wheresoe’er my lot may be.
Where thou goest I will follow;
Yes, my Lord, I’ll follow Thee.


Refrain:
I will follow Thee, my Saviour,
Thou didst shed Thy blood for me;
And though all men should forsake Thee;
By Thy grace I’ll follow Thee.


2.
Though the road be rough and thorny,
Trackless as the foaming sea,
Thou hast trod this way before me,
And I’ll gladly follow Thee.


Refrain:
I will follow Thee, my Saviour,
Thou didst shed Thy blood for me;
And though all men should forsake Thee;
By Thy grace I’ll follow Thee.

3.
Though I meet with tribulations,
Sorely tempted though I be;
I remember Thou wast tempted,
And rejoice to follow Thee.


Refrain:
I will follow Thee, my Saviour,
Thou didst shed Thy blood for me;
And though all men should forsake Thee;
By Thy grace I’ll follow Thee.

4.
Though Thou leadest me through affliction,
Poor, forsaken though I be;
Thou wast destitute, afflicted,
And I only follow Thee.


Refrain:
I will follow Thee, my Saviour,
Thou didst shed Thy blood for me;
And though all men should forsake Thee;
By Thy grace I’ll follow Thee.

5.
Though to Jordan’s rolling billows,
Cold and deep, Thou leadest me,
Thou hast crossed the waves before me,
And I still will follow Thee.

Refrain:
I will follow Thee, my Saviour,
Thou didst shed Thy blood for me;
And though all men should forsake Thee;
By Thy grace I’ll follow Thee.




```

- |   -  |
-------------|------------|
Title | I Will Follow Thee |
Key |  |
Titles | I will follow Thee, my Saviour, |
First Line | I will follow Thee, my Savior, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
