---
title: 92. This Is My Father`s World - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 92. This Is My Father`s World. 1. This is my Father’s world, and to my listening ears all nature sings, and round me rings the music of the spheres. This is my Father’s world: I rest me in the thought of rocks and trees, of skies and seas; his hand the wonders wrought.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, This Is My Father`s World, This is my Father’s world, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 92. THIS IS MY FATHER`S WORLD
#### Seventh Day Adventist Hymnal

```txt



1.
This is my Father’s world,
and to my listening ears
all nature sings, and round me rings
the music of the spheres.
This is my Father’s world:
I rest me in the thought
of rocks and trees, of skies and seas;
his hand the wonders wrought.

2.
This is my Father’s world,
the birds their carols raise,
the morning light, the lily white,
declare their maker’s praise.
This is my Father’s world:
he shines in all that’s fair;
in the rustling grass I hear him pass;
he speaks to me everywhere.

3.
This is my Father’s world.
O let me ne’er forget
that though the wrong seems oft so strong,
God is the ruler yet.
This is my Father’s world:
why should my heart be sad?
The Lord is King; let the heavens ring!
God reigns; let the earth be glad!



```

- |   -  |
-------------|------------|
Title | This Is My Father`s World |
Key |  |
Titles | undefined |
First Line | This is my Father’s world, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
