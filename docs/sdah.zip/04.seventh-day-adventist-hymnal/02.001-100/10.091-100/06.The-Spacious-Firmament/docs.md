---
title: 96. The Spacious Firmament - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 96. The Spacious Firmament. 1. The spacious firmament on high, With all the blue, ethereal sky, And spangled heavens, a shining frame, Their great Original proclaim. Th’unwearied sun from day to day Does his Creator’s power display, And publishes to every land The work of an almighty hand
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The Spacious Firmament, The spacious firmament on high, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 96. THE SPACIOUS FIRMAMENT
#### Seventh Day Adventist Hymnal

```txt



1.
The spacious firmament on high,
With all the blue, ethereal sky,
And spangled heavens, a shining frame,
Their great Original proclaim.
Th’unwearied sun from day to day
Does his Creator’s power display,
And publishes to every land
The work of an almighty hand

2.
Soon as the evening shades prevail,
The moon takes up the wondrous tale;
And nightly to the listening earth
Repeats the story of her birth;
While all the stars that round her burn,
And all the planets in their turn,
Confirm the tidings as they roll,
And spread the truth from pole to pole

3.
What though in solemn silence all
Move round the dark terrestrial ball?
What though no real voice nor sound
Amid their radiant orbs be found?
In reason’s ear they all rejoice
And utter forth a glorious voice,
Forever singing as they shine,
“The hand that made us is divine.”



```

- |   -  |
-------------|------------|
Title | The Spacious Firmament |
Key |  |
Titles | undefined |
First Line | The spacious firmament on high, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
