---
title: 93. All Things Bright and Beautiful - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 93. All Things Bright and Beautiful. 1. Each little flow’r that opens Each little bird that sings He made their glowing colours He made their tiny wings.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, All Things Bright and Beautiful, Each little flow’r that opens 
    author: Brian Onang'o
---

#### Advent Hymnals
## 93. ALL THINGS BRIGHT AND BEAUTIFUL
#### Seventh Day Adventist Hymnal

```txt



1.
Each little flow’r that opens
Each little bird that sings
He made their glowing colours
He made their tiny wings.

2.
The purple-headed mountain
The river running by
The sunset and the morning
That brighten up the sky.

3.
The cold wind in the winter
The pleasant summer sun
The ripe fruits in the garden
He made them, every one.

4.
He gave us eyes to see them
And lips that we might tell
How great is God Almighty
Who has made all things well.



```

- |   -  |
-------------|------------|
Title | All Things Bright and Beautiful |
Key |  |
Titles | undefined |
First Line | Each little flow’r that opens |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
