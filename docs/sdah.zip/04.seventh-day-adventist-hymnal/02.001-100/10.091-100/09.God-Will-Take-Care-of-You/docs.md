---
title: 99. God Will Take Care of You - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 99. God Will Take Care of You. 1. Be not dismayed whate’er betide, God will take care of you; beneath his wings of love abide, God will take care of you. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God Will Take Care of You, Be not dismayed whate’er betide, ,God will take care of you,
    author: Brian Onang'o
---

#### Advent Hymnals
## 99. GOD WILL TAKE CARE OF YOU
#### Seventh Day Adventist Hymnal

```txt



1.
Be not dismayed whate’er betide,
God will take care of you;
beneath his wings of love abide,
God will take care of you.


Refrain:
God will take care of you,
through every day, o’er all the way;
he will take care of you,
God will take care of you.


2.
Through days of toil when heart doth fail,
God will take care of you;
when dangers fierce your path assail,
God will take care of you.


Refrain:
God will take care of you,
through every day, o’er all the way;
he will take care of you,
God will take care of you.

3.
All you may need he will provide,
God will take care of you;
nothing you ask will be denied,
God will take care of you.


Refrain:
God will take care of you,
through every day, o’er all the way;
he will take care of you,
God will take care of you.

4.
No matter what may be the test,
God will take care of you;
lean, weary one, upon his breast,
God will take care of you.

Refrain:
God will take care of you,
through every day, o’er all the way;
he will take care of you,
God will take care of you.




```

- |   -  |
-------------|------------|
Title | God Will Take Care of You |
Key |  |
Titles | God will take care of you, |
First Line | Be not dismayed whate’er betide, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
