---
title: 91. Ye Watchers and Ye Holy Ones - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 91. Ye Watchers and Ye Holy Ones. 1. Ye watchers and ye holy ones, Bright seraphs, cherubim and thrones, Raise the glad strain, Alleluia! Cry out, dominions, princedoms, powers, Virtues, archangels, angels’ choirs: 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Ye Watchers and Ye Holy Ones, Ye watchers and ye holy ones, ,Alleluia! Alleluia!
    author: Brian Onang'o
---

#### Advent Hymnals
## 91. YE WATCHERS AND YE HOLY ONES
#### Seventh Day Adventist Hymnal

```txt



1.
Ye watchers and ye holy ones,
Bright seraphs, cherubim and thrones,
Raise the glad strain, Alleluia!
Cry out, dominions, princedoms, powers,
Virtues, archangels, angels’ choirs:


Refrain:
Alleluia! Alleluia!
Alleluia! Alleluia!
Alleluia!


2.
O higher than the cherubim,
More glorious than the seraphim,
Lead their praises, Alleluia!
Thou bearer of th’eternal Word,
Most gracious, magnify the Lord.


Refrain:
Alleluia! Alleluia!
Alleluia! Alleluia!
Alleluia!

3.
O friends, in gladness let us sing,
Supernal anthems echoing,
Alleluia! Alleluia!
To God the Father, God the Son,
And God the Spirit, Three in One.

Refrain:
Alleluia! Alleluia!
Alleluia! Alleluia!
Alleluia!




```

- |   -  |
-------------|------------|
Title | Ye Watchers and Ye Holy Ones |
Key |  |
Titles | Alleluia! Alleluia! |
First Line | Ye watchers and ye holy ones, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
