---
title: 97. Lord of the Boundless Curves of Space - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 97. Lord of the Boundless Curves of Space. 1. Lord of the boundless curves of space And time’s deep mystery, To Your creative might we trace All nature’s energy.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord of the Boundless Curves of Space, Lord of the boundless curves of space 
    author: Brian Onang'o
---

#### Advent Hymnals
## 97. LORD OF THE BOUNDLESS CURVES OF SPACE
#### Seventh Day Adventist Hymnal

```txt



1.
Lord of the boundless curves of space
And time’s deep mystery,
To Your creative might we trace
All nature’s energy.

2.
Your mind conceived the galaxy,
Each atom’s secret planned,
And every age of history
Your purpose, Lord, has spanned.

3.
Yours is the image stamped on man,
Though marred by man’s own sin;
And Yours the liberating plan
Again his soul to win.

4.
Give us to know Your truth; but more,
The strength to do Your will;
Until the love our souls adore
Shall all our being fill.



```

- |   -  |
-------------|------------|
Title | Lord of the Boundless Curves of Space |
Key |  |
Titles | undefined |
First Line | Lord of the boundless curves of space |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
