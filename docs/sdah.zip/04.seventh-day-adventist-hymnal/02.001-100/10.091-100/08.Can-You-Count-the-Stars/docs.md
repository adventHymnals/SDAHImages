---
title: 98. Can You Count the Stars? - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 98. Can You Count the Stars?. 1. Can you count the stars that brightly Twinkle in the midnight sky? Can you count the clouds, so lightly O’er the meadows floating by? God, the Lord, doth mark their number With His eyes that never slumber; He hath made every one, He hath made them every one.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Can You Count the Stars?, Can you count the stars that brightly 
    author: Brian Onang'o
---

#### Advent Hymnals
## 98. CAN YOU COUNT THE STARS?
#### Seventh Day Adventist Hymnal

```txt



1.
Can you count the stars that brightly
Twinkle in the midnight sky?
Can you count the clouds, so lightly
O’er the meadows floating by?
God, the Lord, doth mark their number
With His eyes that never slumber;
He hath made every one,
He hath made them every one.

2.
Can you count the wings now flashing
In the sunshine’s golden light?
Can you count the fishes splashing
In the cooling waters bright?
God, the Lord, a name hath given,
To all creatures under heaven;
He hath named them every one,
He hath named them every one.

3.
Do you know how many children
Rise each morning blithe and gay?
Can you count their jolly voices,
Singing sweetly day by day?
God hears all the happy voices,
In their merry songs rejoices;
And He loves them, every one,
And He loves them, every one.



```

- |   -  |
-------------|------------|
Title | Can You Count the Stars? |
Key |  |
Titles | undefined |
First Line | Can you count the stars that brightly |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
