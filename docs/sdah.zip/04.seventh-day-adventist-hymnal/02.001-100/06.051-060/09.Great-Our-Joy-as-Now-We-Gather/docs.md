---
title: 59. Great Our Joy as Now We Gather - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 59. Great Our Joy as Now We Gather. 1. Great our joy as now we gather Where the Master makes us one: Where we worship God the Father Thro’ the Spirit of His Son. All who search for His church Find it where His will is done.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Great Our Joy as Now We Gather, Great our joy as now we gather 
    author: Brian Onang'o
---

#### Advent Hymnals
## 59. GREAT OUR JOY AS NOW WE GATHER
#### Seventh Day Adventist Hymnal

```txt



1.
Great our joy as now we gather
Where the Master makes us one:
Where we worship God the Father
Thro’ the Spirit of His Son.
All who search for His church
Find it where His will is done.

2.
Precious is the tie that binds us
To our God when faith grows cold;
Precious all that now reminds us
He is still our safe stronghold.
Faithful love serves to prove
Here the Shepherd has His fold.

3.
May we learn from Christ’s example
How to use this house of prayer:
He who loved and cleansed His temple
Wants us all to worship there.
God the Son shuts out none:
In His kingdom all may share.

4.
Lord, inspire us with Your vision
Of a world which must be won!
Glorious is the church’s mission,
Long endeavoured, scarce begun!
Faithful now – this is how
God’s eternal will is done.



```

- |   -  |
-------------|------------|
Title | Great Our Joy as Now We Gather |
Key |  |
Titles | undefined |
First Line | Great our joy as now we gather |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
