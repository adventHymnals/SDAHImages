---
title: 60. Blessed Jesus at Thy Word - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 60. Blessed Jesus at Thy Word. 1. Blessed Jesus, at Thy word, We have gathered all to hear Thee; By Thy word our hearts were stirred, Now to seek and love and fear Thee. By Thy teachings sweet and holy, Let us learn to love Thee solely.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Blessed Jesus at Thy Word, Blessed Jesus, at Thy word, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 60. BLESSED JESUS AT THY WORD
#### Seventh Day Adventist Hymnal

```txt



1.
Blessed Jesus, at Thy word,
We have gathered all to hear Thee;
By Thy word our hearts were stirred,
Now to seek and love and fear Thee.
By Thy teachings sweet and holy,
Let us learn to love Thee solely.

2.
All our knowledge, sense, and sight,
Lie in deepest darkness shrouded;
Till Thy Spirit breaks our night,
With His beams of truth unclouded.
He alone to God canst win us,
He who works all good within us.

3.
Glorious Lord, Thy self impart!
Light of light, from God proceeding.
Open Thou our ears and heart
Help us, by Thy Spirit’s pleading.
Hear the cry Thy people raises!
Hear, and bless our prayer and praises!



```

- |   -  |
-------------|------------|
Title | Blessed Jesus at Thy Word |
Key |  |
Titles | undefined |
First Line | Blessed Jesus, at Thy word, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
