---
title: 56. The Day Thou Gavest - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 56. The Day Thou Gavest. 1. The day Thou gavest, Lord, is ended; the darkness falls at Thy behest; to Thee our morning hymns ascended; Thy praise shall hallow now our rest.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The Day Thou Gavest, The day Thou gavest, Lord, is ended; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 56. THE DAY THOU GAVEST
#### Seventh Day Adventist Hymnal

```txt



1.
The day Thou gavest, Lord, is ended;
the darkness falls at Thy behest;
to Thee our morning hymns ascended;
Thy praise shall hallow now our rest.

2.
We thank Thee that Thy church, unsleeping
while earth rolls onward into light,
through all the world her watch is keeping,
and rests not now by day or night.

3.
As o’er each continent and island
the dawn leads on another day,
the voice of prayer is never silent,
nor die the strains of praise away.

4.
So be it, Lord; Thy throne shall never,
like earth’s proud empires, pass away.
Thy kingdom stands, and grows forever,
till all Thy creatures own Thy sway.



```

- |   -  |
-------------|------------|
Title | The Day Thou Gavest |
Key |  |
Titles | undefined |
First Line | The day Thou gavest, Lord, is ended; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
