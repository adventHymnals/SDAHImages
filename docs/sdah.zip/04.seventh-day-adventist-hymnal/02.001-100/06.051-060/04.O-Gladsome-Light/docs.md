---
title: 54. O Gladsome Light - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 54. O Gladsome Light. 1. O gladsome light, Of God the Father’s face, The eternal splendour wearing; Celestial, holy, blest, Our Saviour, Jesus Christ, Joyful in Thine appearing.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Gladsome Light, O gladsome light, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 54. O GLADSOME LIGHT
#### Seventh Day Adventist Hymnal

```txt



1.
O gladsome light,
Of God the Father’s face,
The eternal splendour wearing;
Celestial, holy, blest,
Our Saviour, Jesus Christ,
Joyful in Thine appearing.

2.
Now e’er day fadeth quite,
We see the evening light,
Our wonted hymn outpouring;
Father of might unknown,
Thee His incarnate Son,
And Holy Spirit adoring.

3.
To Thee of right belongs
All praise of holy songs,
O Son of God, life giver;
Thee, therefore, O most high,
The world doth glorify
And shall exalt forever.



```

- |   -  |
-------------|------------|
Title | O Gladsome Light |
Key |  |
Titles | undefined |
First Line | O gladsome light, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
