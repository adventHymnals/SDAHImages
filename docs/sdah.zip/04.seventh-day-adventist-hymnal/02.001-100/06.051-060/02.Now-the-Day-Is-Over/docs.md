---
title: 52. Now the Day Is Over - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 52. Now the Day Is Over. 1. Now the day is over, night is drawing nigh, Shadows of the evening steal across the sky.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Now the Day Is Over, Now the day is over, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 52. NOW THE DAY IS OVER
#### Seventh Day Adventist Hymnal

```txt



1.
Now the day is over,
night is drawing nigh,
Shadows of the evening
steal across the sky.

2.
Father, give the weary,
calm and sweet repose;
With Thy tenderest blessing
May our eyelids close.

3.
Through the long night watches,
may thine angels spread
Their white wings above me,
watching round my bed.



```

- |   -  |
-------------|------------|
Title | Now the Day Is Over |
Key |  |
Titles | undefined |
First Line | Now the day is over, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
