---
title: 55. Jesus, Tender Shepherd, Hear Me - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 55. Jesus, Tender Shepherd, Hear Me. 1. Jesus, tender Shepherd, hear me, Bless Thy little lamb tonight; Through the darkness be Thou near me; Watch my sleep till morning light.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Jesus, Tender Shepherd, Hear Me, Jesus, tender Shepherd, hear me, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 55. JESUS, TENDER SHEPHERD, HEAR ME
#### Seventh Day Adventist Hymnal

```txt



1.
Jesus, tender Shepherd, hear me,
Bless Thy little lamb tonight;
Through the darkness be Thou near me;
Watch my sleep till morning light.

2.
All this day Thy hand has led me,
And I thank Thee for Thy care;
Thou hast clothed me, warmed and fed me;
Listen to my evening prayer.



```

- |   -  |
-------------|------------|
Title | Jesus, Tender Shepherd, Hear Me |
Key |  |
Titles | undefined |
First Line | Jesus, tender Shepherd, hear me, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
