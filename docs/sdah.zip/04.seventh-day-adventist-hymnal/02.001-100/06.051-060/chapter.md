---
title: Seventh Day Adventist Hymnal - 051-060
metadata:
    description: |
      Seventh Day Adventist Hymnal - 051-060
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 051-060
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 051-060

# Index of Titles
# | Title                        
-- |-------------
51|[Day Is Dying in the West](/seventh-day-adventist-hymnal/001-100/051-060/Day-Is-Dying-in-the-West)
52|[Now the Day Is Over](/seventh-day-adventist-hymnal/001-100/051-060/Now-the-Day-Is-Over)
53|[All Praise to Thee](/seventh-day-adventist-hymnal/001-100/051-060/All-Praise-to-Thee)
54|[O Gladsome Light](/seventh-day-adventist-hymnal/001-100/051-060/O-Gladsome-Light)
55|[Jesus, Tender Shepherd, Hear Me](/seventh-day-adventist-hymnal/001-100/051-060/Jesus,-Tender-Shepherd,-Hear-Me)
56|[The Day Thou Gavest](/seventh-day-adventist-hymnal/001-100/051-060/The-Day-Thou-Gavest)
57|[Now All the Woods Are Sleeping](/seventh-day-adventist-hymnal/001-100/051-060/Now-All-the-Woods-Are-Sleeping)
58|[Hark, the Vesper Hymn Is Stealing](/seventh-day-adventist-hymnal/001-100/051-060/Hark,-the-Vesper-Hymn-Is-Stealing)
59|[Great Our Joy as Now We Gather](/seventh-day-adventist-hymnal/001-100/051-060/Great-Our-Joy-as-Now-We-Gather)
60|[Blessed Jesus at Thy Word](/seventh-day-adventist-hymnal/001-100/051-060/Blessed-Jesus-at-Thy-Word)