---
title: 51. Day Is Dying in the West - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 51. Day Is Dying in the West. 1. Day is dying in the west; Heaven is touching earth with rest; Wait and worship while the night Sets the evening lamps alight Through all the sky. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Day Is Dying in the West, Day is dying in the west; ,Holy, holy, holy, Lord God of Hosts!
    author: Brian Onang'o
---

#### Advent Hymnals
## 51. DAY IS DYING IN THE WEST
#### Seventh Day Adventist Hymnal

```txt



1.
Day is dying in the west;
Heaven is touching earth with rest;
Wait and worship while the night
Sets the evening lamps alight
Through all the sky.


Refrain:
Holy, holy, holy, Lord God of Hosts!
Heaven and earth are full of Thee!
Heaven and earth are praising Thee,
O Lord most high!


2.
Lord of life, beneath the dome
Of the universe, Thy home,
Gather us who seek Thy face
To the fold of Thy embrace,
For Thou art nigh.


Refrain:
Holy, holy, holy, Lord God of Hosts!
Heaven and earth are full of Thee!
Heaven and earth are praising Thee,
O Lord most high!

3.
While the deepening shadows fall,
Heart of love enfolding all,
Through the glory and the grace
Of the stars that veil Thy face,
Our hearts ascend.


Refrain:
Holy, holy, holy, Lord God of Hosts!
Heaven and earth are full of Thee!
Heaven and earth are praising Thee,
O Lord most high!

4.
When forever from our sight
Pass the stars, the day, the night,
Lord of angels, on our eyes
Let eternal morning rise
And shadows end.

Refrain:
Holy, holy, holy, Lord God of Hosts!
Heaven and earth are full of Thee!
Heaven and earth are praising Thee,
O Lord most high!




```

- |   -  |
-------------|------------|
Title | Day Is Dying in the West |
Key |  |
Titles | Holy, holy, holy, Lord God of Hosts! |
First Line | Day is dying in the west; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
