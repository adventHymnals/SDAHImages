---
title: 38. Arise, My Soul, Arise! - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 38. Arise, My Soul, Arise!. 1. Arise, my soul, arise! Stretch forth to things eternal And hasten to the feet of your Redeemer God. Though hid from mortal eyes, He dwells in light supernal; Yet worship Him in humbleness and call Him Lord. His banquet of love Awaits you above; Yet here He grants a foretaste of the feast to come! Rejoice, my soul, rejoice, To heav’n lift up your voice: Alleluia, alleluia, alleluia!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Arise, My Soul, Arise!, Arise, my soul, arise! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 38. ARISE, MY SOUL, ARISE!
#### Seventh Day Adventist Hymnal

```txt



1.
Arise, my soul, arise!
Stretch forth to things eternal
And hasten to the feet of your Redeemer God.
Though hid from mortal eyes,
He dwells in light supernal;
Yet worship Him in humbleness and call Him Lord.
His banquet of love
Awaits you above;
Yet here He grants a foretaste of the feast
to come!
Rejoice, my soul, rejoice,
To heav’n lift up your voice:
Alleluia, alleluia, alleluia!

2.
Now hear the harps of heav’n!
Oh, hear the song victorious,
The never-ending anthem sounding
through the sky!
To mortals is not giv’n
To join in strains so glorious;
Yet here on earth we too can sing
our praises high!
He bought with His blood
The ransomed of God;
To Him be everlasting pow’r and victory.
And let the great amen
Resound through heav’n again.
Alleluia, alleluia, alleluia!



```

- |   -  |
-------------|------------|
Title | Arise, My Soul, Arise! |
Key |  |
Titles | undefined |
First Line | Arise, my soul, arise! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
