---
title: 33. Sing a New Song to the Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 33. Sing a New Song to the Lord. 1. Sing a new song to the Lord, He to whom wonders belong. Rejoice in His triumph and tell of His power. O sing a new song to the Lord.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Sing a New Song to the Lord, Sing a new song to the Lord, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 33. SING A NEW SONG TO THE LORD
#### Seventh Day Adventist Hymnal

```txt



1.
Sing a new song to the Lord,
He to whom wonders belong.
Rejoice in His triumph and tell of His power.
O sing a new song to the Lord.

2.
Now to the ends of the earth
See His salvation is shown.
And still He remembers His mercy and truth,
Unchanging in love to His own.

3.
Sing a new song and rejoice.
Publish His praises abroad.
Let voices in chorus with trumpet and horn,
Resound for the joy of the Lord.

4.
Join with the hills and the sea,
Thunders of praise to prolong.
In judgement and justice
He comes to the earth
O sing a new song to the Lord.



```

- |   -  |
-------------|------------|
Title | Sing a New Song to the Lord |
Key |  |
Titles | undefined |
First Line | Sing a new song to the Lord, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
