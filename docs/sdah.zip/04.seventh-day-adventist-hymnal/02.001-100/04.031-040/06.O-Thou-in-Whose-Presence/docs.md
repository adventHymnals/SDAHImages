---
title: 36. O Thou in Whose Presence - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 36. O Thou in Whose Presence. 1. O Thou in whose presence my soul takes delight, On whom in affliction I call, My comfort by day and my song in the night, My hope, my salvation, my all!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Thou in Whose Presence, O Thou in whose presence my soul takes delight, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 36. O THOU IN WHOSE PRESENCE
#### Seventh Day Adventist Hymnal

```txt



1.
O Thou in whose presence my soul takes delight,
On whom in affliction I call,
My comfort by day and my song in the night,
My hope, my salvation, my all!

2.
His voice, as the sound of the dulcimer sweet,
Is heard through the shadows of death;
The cedars of Lebanon bow at His feet,
The air is perfumed with His breath.

3.
His lips, as a fountain of righteousness flow,
To water the gardens of grace;
From which their salvation the Gentiles shall know,
And bask in the smiles of His face.

4.
He looks, and ten thousands of angels rejoice,
And myriads wait for His word;
He speaks, and eternity, filled with His voice,
Re-echoes the praise of the Lord.



```

- |   -  |
-------------|------------|
Title | O Thou in Whose Presence |
Key |  |
Titles | undefined |
First Line | O Thou in whose presence my soul takes delight, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
