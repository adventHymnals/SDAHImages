---
title: 35. With Songs and Honors - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 35. With Songs and Honors. 1. With songs and honors sounding loud, Address the Lord on high; Over the heavens He spreads His cloud, And waters veil the sky.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, With Songs and Honors, With songs and honors sounding loud, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 35. WITH SONGS AND HONORS
#### Seventh Day Adventist Hymnal

```txt



1.
With songs and honors sounding loud,
Address the Lord on high;
Over the heavens He spreads His cloud,
And waters veil the sky.

2.
He sends His showers of blessing down
To cheer the plains below;
He makes the grass the mountains crown,
And corning valleys grow.

3.
His steady counsels change the face
Of the declining year;
He bids the sun cut short his race,
And wintry days appear.

4.
He sends His word, and melts the snow;
The fields no longer mourn;
He calls the warmer gales to blow,
And bids the spring return.

5.
The changing wind, the flying cloud,
Obey His mighty word:
With songs and honors sounding loud
Praise ye the sovereign Lord!



```

- |   -  |
-------------|------------|
Title | With Songs and Honors |
Key |  |
Titles | undefined |
First Line | With songs and honors sounding loud, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
