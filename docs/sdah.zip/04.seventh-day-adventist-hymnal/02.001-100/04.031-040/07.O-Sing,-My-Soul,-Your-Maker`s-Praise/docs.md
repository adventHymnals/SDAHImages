---
title: 37. O Sing, My Soul, Your Maker`s Praise - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 37. O Sing, My Soul, Your Maker`s Praise. 1. O sing my soul, your Maker’s praise In grateful hymns ascending; Whose steadfast love has crowned your days With heav’nly gifts un ending. I sought the Lord, He heard my cry; His holy angels hover nigh The tents of those who love Him.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Sing, My Soul, Your Maker`s Praise, O sing my soul, your Maker’s praise 
    author: Brian Onang'o
---

#### Advent Hymnals
## 37. O SING, MY SOUL, YOUR MAKER`S PRAISE
#### Seventh Day Adventist Hymnal

```txt



1.
O sing my soul, your Maker’s praise
In grateful hymns ascending;
Whose steadfast love has crowned your days
With heav’nly gifts un ending.
I sought the Lord, He heard my cry;
His holy angels hover nigh
The tents of those who love Him.

2.
The Lord is good to those who seek
His face in time of sorrow,
Providing comfort to the weak
And grace for each tomorrow.
Though grief may tarry for a night,
The morn shall break in joy and light
With blessings from His presence.

3.
The Lord will turn His face in peace
When troubled souls draw near Him;
His loving kindness shall not cease
To those who trust and fear Him.
Our God will not forsake His own;
Eternal is His heav’nly throne;
His kingdom stands forever.



```

- |   -  |
-------------|------------|
Title | O Sing, My Soul, Your Maker`s Praise |
Key |  |
Titles | undefined |
First Line | O sing my soul, your Maker’s praise |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
