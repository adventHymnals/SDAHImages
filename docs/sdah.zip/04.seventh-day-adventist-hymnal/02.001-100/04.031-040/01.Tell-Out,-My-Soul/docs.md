---
title: 31. Tell Out, My Soul - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 31. Tell Out, My Soul. 1. Tell out my soul, the greatness of the Lord: Unnumbered blessings, give my spirit voice; Tender to me the promise of His Word; In God my Saviour shall my heart rejoice.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Tell Out, My Soul, Tell out my soul, the greatness of the Lord; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 31. TELL OUT, MY SOUL
#### Seventh Day Adventist Hymnal

```txt



1.
Tell out my soul, the greatness of the Lord:
Unnumbered blessings, give my spirit voice;
Tender to me the promise of His Word;
In God my Saviour shall my heart rejoice.

2.
Tell out, my soul, the greatness of His name:
Make known His might, the deeds His arm has done;
His mercy sure, from age to age the same;
His holy name, the Lord, the Mighty One.

3.
Tell out, my soul, the greatness of His might:
Pow’rs and dominions lay their glory by;
Proud hearts and stubborn wills are put to flight,
The hungry fed, the humble lifted high.

4.
Tell out, my soul, the glories of His word:
Firm is His promise, and His mercy sure.
Tell out, my soul, the greatness of the Lord
To children’s children and forevermore.



```

- |   -  |
-------------|------------|
Title | Tell Out, My Soul |
Key |  |
Titles | undefined |
First Line | Tell out my soul, the greatness of the Lord: |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
