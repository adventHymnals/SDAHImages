---
title: Seventh Day Adventist Hymnal - 031-040
metadata:
    description: |
      Seventh Day Adventist Hymnal - 031-040
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 031-040
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 031-040

# Index of Titles
# | Title                        
-- |-------------
31|[Tell Out, My Soul](/seventh-day-adventist-hymnal/001-100/031-040/Tell-Out,-My-Soul)
32|[When in Our Music God is Glorified](/seventh-day-adventist-hymnal/001-100/031-040/When-in-Our-Music-God-is-Glorified)
33|[Sing a New Song to the Lord](/seventh-day-adventist-hymnal/001-100/031-040/Sing-a-New-Song-to-the-Lord)
34|[Wake the Song](/seventh-day-adventist-hymnal/001-100/031-040/Wake-the-Song)
35|[With Songs and Honors](/seventh-day-adventist-hymnal/001-100/031-040/With-Songs-and-Honors)
36|[O Thou in Whose Presence](/seventh-day-adventist-hymnal/001-100/031-040/O-Thou-in-Whose-Presence)
37|[O Sing, My Soul, Your Maker\`s Praise](/seventh-day-adventist-hymnal/001-100/031-040/O-Sing,-My-Soul,-Your-Maker`s-Praise)
38|[Arise, My Soul, Arise!](/seventh-day-adventist-hymnal/001-100/031-040/Arise,-My-Soul,-Arise!)
39|[Lord, in the Morning](/seventh-day-adventist-hymnal/001-100/031-040/Lord,-in-the-Morning)
40|[The Dawn of God\`s Dear Sabbath](/seventh-day-adventist-hymnal/001-100/031-040/The-Dawn-of-God`s-Dear-Sabbath)