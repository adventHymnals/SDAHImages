---
title: 32. When in Our Music God is Glorified - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 32. When in Our Music God is Glorified. 1. When in our music God is glorified, And adoration leaves no room for pride, It is as though the whole creation cried: Alleluia!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, When in Our Music God is Glorified, When in our music God is glorified, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 32. WHEN IN OUR MUSIC GOD IS GLORIFIED
#### Seventh Day Adventist Hymnal

```txt



1.
When in our music God is glorified,
And adoration leaves no room for pride,
It is as though the whole creation cried:
Alleluia!

2.
How oft, in making music, we have found
A new dimension in the world of sound,
As worship moved us to a more profound
Alleluia!

3.
And did not Jesus sing a psalm that night
When utmost evil strove against the light?
Then let us sing for whom He won the fight:
Alleluia!

4.
Let every instrument be used for praise;
Let all rejoice who have a voice to raise;
And may God give us faith to sing always:
Alleluia!



```

- |   -  |
-------------|------------|
Title | When in Our Music God is Glorified |
Key |  |
Titles | undefined |
First Line | When in our music God is glorified, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
