---
title: 39. Lord, in the Morning - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 39. Lord, in the Morning. 1. Lord, in the morning Thou shalt hear My voice ascending high; To Thee will I direct my prayer, To Thee lift up mine eye-
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord, in the Morning, Lord, in the morning Thou shalt hear 
    author: Brian Onang'o
---

#### Advent Hymnals
## 39. LORD, IN THE MORNING
#### Seventh Day Adventist Hymnal

```txt



1.
Lord, in the morning Thou shalt hear
My voice ascending high;
To Thee will I direct my prayer,
To Thee lift up mine eye-

2.
Up to the hills where Christ is gone
To plead for all His saints,
Presenting at His Father’s throne
Our songs and our complaints.

3.
O may Thy Spirit guide my feet
In ways of righteousness;
Make every path of duty straight
And plain before my face.
4 The men that love and fear Thy name
Shall see their hopes fulfilled;
The mighty God will compass them
With favor as a shield.



```

- |   -  |
-------------|------------|
Title | Lord, in the Morning |
Key |  |
Titles | undefined |
First Line | Lord, in the morning Thou shalt hear |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
