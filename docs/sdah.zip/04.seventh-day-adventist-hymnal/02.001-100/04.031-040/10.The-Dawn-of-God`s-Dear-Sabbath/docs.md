---
title: 40. The Dawn of God`s Dear Sabbath - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 40. The Dawn of God`s Dear Sabbath. 1. The dawn of God’s dear Sabbath Breaks o’er the earth again, As some sweet summer morning After a night of pain; It comes as cooling showers To some exhausted land, As shade of clustered palm trees ‘Mid weary wastes of sand.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The Dawn of God`s Dear Sabbath, The dawn of God’s dear Sabbath 
    author: Brian Onang'o
---

#### Advent Hymnals
## 40. THE DAWN OF GOD`S DEAR SABBATH
#### Seventh Day Adventist Hymnal

```txt



1.
The dawn of God’s dear Sabbath
Breaks o’er the earth again,
As some sweet summer morning
After a night of pain;
It comes as cooling showers
To some exhausted land,
As shade of clustered palm trees
‘Mid weary wastes of sand.

2.
Lord, we would bring for offering,
Though marred with earthly soil,
A week of earnest labor,
Of steady, faithful toil,
Fair fruits of self denial,
Of strong, deep love to Thee,
Fostered by Thine own Spirit,
In true humility.

3.
And we would bring our burden
Of sinful thought and deed,
In Thy pure presence kneeling,
From bondage to be freed,
Our heart’s most bitter sorrow
For all Thy work undone-
So many talents wasted!
So few bright laurels won!

4.
And with that sorrow mingling,
A steadfast faith, and sure,
And love so deep and fervent,
For Thee to make it pure,
In Thy dear presence finding
The pardon that we need,
And then the peace so lasting-
Celestial peace indeed.



```

- |   -  |
-------------|------------|
Title | The Dawn of God`s Dear Sabbath |
Key |  |
Titles | undefined |
First Line | The dawn of God’s dear Sabbath |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
