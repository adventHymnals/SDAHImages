---
title: 13. New Songs of Celebration Render - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 13. New Songs of Celebration Render. 1. New songs of celebration render To Him who has great wonders done. Love sits enthroned in ageless splendor: Come, and adore the mighty One. He has made known His great salvation Which all His friends with joy confess: He has revealed to every nation His everlasting righteousness.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, New Songs of Celebration Render, New songs of celebration render 
    author: Brian Onang'o
---

#### Advent Hymnals
## 13. NEW SONGS OF CELEBRATION RENDER
#### Seventh Day Adventist Hymnal

```txt



1.
New songs of celebration render
To Him who has great wonders done.
Love sits enthroned in ageless splendor:
Come, and adore the mighty One.
He has made known His great salvation
Which all His friends with joy confess:
He has revealed to every nation
His everlasting righteousness.

2.
Joyfully, heartily resounding,
Let every instrument and voice
Peal out the praise of grace abounding
Calling the whole world to rejoice.
Trumpets and organs, set in motion
Such sounds as make the heavens ring;
All things that live in earth and ocean,
Make music for your mighty King.

3.
Rivers and seas and torrents roaring,
Honor the Lord with wild acclaim;
Mountains and stones look up adoring,
And find a voice to praise His name.
Righteous, commanding, ever glorious,
Praises be His that never cease:
Just is our God, whose truth victorious,
Establishes the world in peace.



```

- |   -  |
-------------|------------|
Title | New Songs of Celebration Render |
Key | G |
Titles | undefined |
First Line | New songs of celebration render |
Author | Erik Routley
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
