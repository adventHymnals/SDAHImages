---
title: 12. Joyful, Joyful, We Adore Thee - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 12. Joyful, Joyful, We Adore Thee. 1. Joyful, joyful, we adore Thee, God of glory, Lord of love; Hearts unfold like flow’rs before Thee, Hail Thee as the sun above. Melt the clouds of sin and sadness, Drive the dark of doubt away; Giver of immortal gladness, Fill us with the light of day!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Joyful, Joyful, We Adore Thee, Joyful, joyful, we adore Thee, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 12. JOYFUL, JOYFUL, WE ADORE THEE
#### Seventh Day Adventist Hymnal

```txt



1.
Joyful, joyful, we adore Thee,
God of glory, Lord of love;
Hearts unfold like flow’rs before Thee,
Hail Thee as the sun above.
Melt the clouds of sin and sadness,
Drive the dark of doubt away;
Giver of immortal gladness,
Fill us with the light of day!

2.
All Thy works with joy surround Thee,
Earth and heav’n reflect Thy rays,
Stars and angels sing around Thee,
Center of unbroken praise;
Field and forest, vale and mountain,
Bloss’ming meadow, flashing sea,
Chanting bird and flowing fountain
Call us to rejoice in Thee.

3.
Thou art giving and forgiving,
Ever blessing, ever blest,
Wellspring of the joy of living,
Oceandepth of happy rest!
Thou the father, Christ our Brother –
All who live in love are Thine:
Teach us how to love each other,
Lift us to the joy divine.



```

- |   -  |
-------------|------------|
Title | Joyful, Joyful, We Adore Thee |
Key | G |
Titles | undefined |
First Line | Joyful, joyful, we adore Thee, |
Author | Henry van Dyke
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
