---
title: 18. O Morning Star, How Fair and Bright - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 18. O Morning Star, How Fair and Bright. 1. O Morning Star, how fair and bright! You shine with God’s own truth and light, Aglow with grace and mercy! Of Jacob’s race, King David’s son, Our Lord and Master, You have won Our hearts to serve You only! Lowly, holy! Great and Glorious, all victorious, Rich in blessing! Rule and might o’er all possessing!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Morning Star, How Fair and Bright, O Morning Star, how fair and bright! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 18. O MORNING STAR, HOW FAIR AND BRIGHT
#### Seventh Day Adventist Hymnal

```txt



1.
O Morning Star, how fair and bright!
You shine with God’s own truth and light,
Aglow with grace and mercy!
Of Jacob’s race, King David’s son,
Our Lord and Master, You have won
Our hearts to serve You only!
Lowly, holy!
Great and Glorious, all victorious,
Rich in blessing! Rule and might o’er all possessing!

2.
Lord, when you look on us in love,
At once there falls from God above
A ray of purest pleasure.
Your Word and Spirit, flesh and blood,
Refresh our souls with heav-‘nly food.
You are our dearest treasure!
Let Your mercy warm and cheer us!
O draw near us! For You teach us
God’s own love through You has reached us.

3.
Almighty Father, in Your Son
You loved us, when not yet begun
Was this old earth’s foundation!
Your Son has ransomed us in love
To live in Him here and above:
This is Your great salvation.
Alleluia! Christ the living,
To us giving life forever,
Keeps us Yours and fails us never!

4.
O let the harps break forth in sound!
Our joy be all with music crowned,
Our voices gaily blending!
For Christ goes with us all the way –
Today, tomorrow, every day!
His love is never ending!
Sing out! Ring out!
Jubilation! Exultation!
Tell the story!
Great is He, the King of glory!



```

- |   -  |
-------------|------------|
Title | O Morning Star, How Fair and Bright |
Key | D |
Titles | undefined |
First Line | O Morning Star, how fair and bright! |
Author | Philip Nicolai
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
