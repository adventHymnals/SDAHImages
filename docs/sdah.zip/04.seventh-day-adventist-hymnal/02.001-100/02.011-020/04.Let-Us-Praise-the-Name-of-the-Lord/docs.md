---
title: 14. Let Us Praise the Name of the Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 14. Let Us Praise the Name of the Lord. 1. Let us praise the name of the Lord! Give Him glory, Amen.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Let Us Praise the Name of the Lord, Let us praise the name of the Lord! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 14. LET US PRAISE THE NAME OF THE LORD
#### Seventh Day Adventist Hymnal

```txt



1.
Let us praise the name of the Lord!
Give Him glory, Amen.

2.
Go ye into all the world.
Alleluia, Amen.

3.
Amen, amen,
Amen, amen.



```

- |   -  |
-------------|------------|
Title | Let Us Praise the Name of the Lord |
Key | C |
Titles | undefined |
First Line | Let us praise the name of the Lord! |
Author | Ursula Schlenker
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
