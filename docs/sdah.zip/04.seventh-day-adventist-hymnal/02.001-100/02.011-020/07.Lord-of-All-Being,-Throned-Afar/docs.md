---
title: 17. Lord of All Being, Throned Afar - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 17. Lord of All Being, Throned Afar. 1. Lord of all being, throned afar, Thy glory flames from sun and star; Center and soul of every sphere Yet to each loving heart how near! Yet to each loving heart how near!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord of All Being, Throned Afar, Lord of all being, throned afar, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 17. LORD OF ALL BEING, THRONED AFAR
#### Seventh Day Adventist Hymnal

```txt



1.
Lord of all being, throned afar,
Thy glory flames from sun and star;
Center and soul of every sphere
Yet to each loving heart how near!
Yet to each loving heart how near!

2.
Sun of our life, Thy quickening ray
Shed on our path the glow of day;
Star of our hope, Thy softened light
Cheers the long watches of the night,
Cheers the long watches of the night.

3.
Our midnight is Thy smile withdrawn;
Our noontide is Thy gracious dawn;
Our rainbow arch, Thy mercy’s sign;
All, save the clouds of sin, are Thine,
All, save the clouds of sin, are Thine.

4.
Lord of all life, below, above
Whose light is truth, whose warmth is love,
Before Thy ever-blazing throne
We ask no luster of our own,
We ask no luster of our own.

5.
Grant us Thy truth to make us free
And kindling hearts that burn for Thee;
Till all Thy living altars claim
One holy light, one heavenly flame!
One holy light, one heavenly flame.



```

- |   -  |
-------------|------------|
Title | Lord of All Being, Throned Afar |
Key | F |
Titles | undefined |
First Line | Lord of all being, throned afar, |
Author | Oliver Wendell Holmes
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
