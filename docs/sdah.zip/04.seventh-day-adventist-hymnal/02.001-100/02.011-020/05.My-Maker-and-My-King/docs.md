---
title: 15. My Maker and My King - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 15. My Maker and My King. 1. My Maker and my King, To Thee my all I owe; Thy sovereign bounty is the spring Whence all my blessings flow; Thy sovereign bounty is the spring Whence all my blessings flow.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, My Maker and My King, My Maker and my King, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 15. MY MAKER AND MY KING
#### Seventh Day Adventist Hymnal

```txt



1.
My Maker and my King,
To Thee my all I owe;
Thy sovereign bounty is the spring
Whence all my blessings flow;
Thy sovereign bounty is the spring
Whence all my blessings flow.

2.
The creature of Thy hand,
On Thee alone I live;
My God, Thy benefits demand
More praise than I can give.
My God, Thy benefits demand
More praise than I can give.

3.
Lord, what can I impart
When all is Thine before?
Thy love demands a thankful heart;
The gift, alas! how poor.
Thy love demands a thankful heart;
The gift, alas! how poor.

4.
O! let Thy grace inspire
My soul with strength divine;
Let every word each desire
And all my days be Thine.
Let every word each desire
And all my days be Thine.



```

- |   -  |
-------------|------------|
Title | My Maker and My King |
Key | C |
Titles | undefined |
First Line | My Maker and my King, |
Author | Anne Steele
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
