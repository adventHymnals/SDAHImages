---
title: 11. The God of Abraham Praise - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 11. The God of Abraham Praise. 1. The God of Abraham praise, Who reigns enthroned above; Ancient of everlasting days, And God of love; Jehovah! Great I AM! By earth and heaven confessed; I bow and bless the sacred name, Forever blest.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The God of Abraham Praise, The God of Abraham praise, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 11. THE GOD OF ABRAHAM PRAISE
#### Seventh Day Adventist Hymnal

```txt



1.
The God of Abraham praise,
Who reigns enthroned above;
Ancient of everlasting days,
And God of love;
Jehovah! Great I AM!
By earth and heaven confessed;
I bow and bless the sacred name,
Forever blest.

2.
The God of Abraham praise,
At whose supreme command
From earth I rise, and seek the joys
At His right hand;
I all on earth forsake,
Its wisdom, fame and power;
And Him my only portion make,
My shield and tower.

3.
The whole triumphant host
Give thanks to God on high;
“Hail, Father, Son, and Holy Ghost!”
They ever cry;
Hail, Abraham’s God and mine!
I join the heavenly lays;
All might and majesty are Thine,
And endless praise.



```

- |   -  |
-------------|------------|
Title | The God of Abraham Praise |
Key | G |
Titles | undefined |
First Line | The God of Abraham praise, |
Author | Thomas Olivers
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
