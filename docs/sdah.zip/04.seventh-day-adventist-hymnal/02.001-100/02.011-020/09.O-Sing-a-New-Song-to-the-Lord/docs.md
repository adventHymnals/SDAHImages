---
title: 19. O Sing a New Song to the Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 19. O Sing a New Song to the Lord. 1. O sing a new song to the Lord For marvels He has done; His right hand and His holy arm The victory have won.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Sing a New Song to the Lord, O sing a new song to the Lord 
    author: Brian Onang'o
---

#### Advent Hymnals
## 19. O SING A NEW SONG TO THE LORD
#### Seventh Day Adventist Hymnal

```txt



1.
O sing a new song to the Lord
For marvels He has done;
His right hand and His holy arm
The victory have won.

2.
With harp, and voice of psalms
Unto Jehovah sing;
Let trumpets and the echoing horn
Acclaim the Lord our King!

3.
Let seas with all their creatures roar,
The world and dwellers there,
And let the rivers clap their hands,
The hills their joy declare.

4.
Before the Lord: because He comes,
To judge the earth come He;
He’ll judge the world
with righteousness,
His folk with equity.



```

- |   -  |
-------------|------------|
Title | O Sing a New Song to the Lord |
Key | G |
Titles | undefined |
First Line | O sing a new song to the Lord |
Author | Scottish Psalter
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
