---
title: 16. All People That on Earth Do Well - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 16. All People That on Earth Do Well. 1. All people that on earth do dwell, sing to the Lord with cheerful voice. Him serve with mirth, his praise forth tell; come ye before him and rejoice.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, All People That on Earth Do Well, All people that on earth do dwell, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 16. ALL PEOPLE THAT ON EARTH DO WELL
#### Seventh Day Adventist Hymnal

```txt



1.
All people that on earth do dwell,
sing to the Lord with cheerful voice.
Him serve with mirth, his praise forth tell;
come ye before him and rejoice.

2.
Know that the Lord is God indeed;
without our aid he did us make;
we are his folk, he doth us feed,
and for his sheep he doth us take.

3.
O enter then his gates with praise;
approach with joy his courts unto;
praise, laud, and bless his name always,
for it is seemly so to do.

4.
For why! the Lord our God is good;
his mercy is forever sure;
his truth at all times firmly stood,
and shall from age to age endure.



```

- |   -  |
-------------|------------|
Title | All People That on Earth Do Well |
Key | G |
Titles | undefined |
First Line | All people that on earth do dwell, |
Author | Wiliam Kethe
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
