---
title: 81. Though I Speak With Tongues - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 81. Though I Speak With Tongues. 1. Though I speak with tongues of men and angels, Though I have the prophet’s gift, Though I hold the keys to hidden knowledge, Though my faith can mountains shift; Without love I am no better, Without love it’s all for naught; Lord, You spent Your life in loving others: What this means I would be taught.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Though I Speak With Tongues, Though I speak with tongues of men and angels, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 81. THOUGH I SPEAK WITH TONGUES
#### Seventh Day Adventist Hymnal

```txt



1.
Though I speak with tongues of men and angels,
Though I have the prophet’s gift,
Though I hold the keys to hidden knowledge,
Though my faith can mountains shift;
Without love I am no better,
Without love it’s all for naught;
Lord, You spent Your life in loving others:
What this means I would be taught.

2.
Love is patient, knows no envy,
Never gloats when others sin;
Love is never glad to see injustice,
Always wants the truth to win.
There’s no end to love’s endurance,
There’s no test it cannot face;
Lord, You spent Your life in loving others:
I shall fail without Your grace.

3.
Though there’ll be an end to hidden knowledge,
Visions, raptures, prophecy:
Faith and hope and love shall last forever,
Love the greatest of the three.
Without love I am no better,
Without love it’s all for naught;
Lord, You gave Your life in saving others:
What this means I would be taught.



```

- |   -  |
-------------|------------|
Title | Though I Speak With Tongues |
Key |  |
Titles | undefined |
First Line | Though I speak with tongues of men and angels, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
