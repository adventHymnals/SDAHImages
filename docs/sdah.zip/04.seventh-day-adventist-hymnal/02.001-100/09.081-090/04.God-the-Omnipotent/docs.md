---
title: 84. God the Omnipotent - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 84. God the Omnipotent. 1. God the Omnipotent! King, who ordainest Great winds Thy clarions, the lightnings Thy sword; Show forth Thy pity on high where Thou reignest, Give to us peace, O most merciful Lord.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God the Omnipotent, God the Omnipotent! King, who ordainest 
    author: Brian Onang'o
---

#### Advent Hymnals
## 84. GOD THE OMNIPOTENT
#### Seventh Day Adventist Hymnal

```txt



1.
God the Omnipotent! King, who ordainest
Great winds Thy clarions, the lightnings Thy sword;
Show forth Thy pity on high where Thou reignest,
Give to us peace, O most merciful Lord.

2.
God the all merciful! earth hath forsaken
Thy precepts holy, and slighted Thy word;
Bid not Thy wrath in its terrors awaken;
Give to us peace, O most merciful Lord.

3.
God the all righteousness One! man hath defied Thee;
Yet to eternity standeth Thy word;
Falsehood and wrong shall not tarry beside Thee;
Prosper the right, O most merciful Lord.

4.
So shall we render Thee thankful devotion,
For Thy deliverance from peril and sword,
Singing in chorus from ocean to ocean,
“Thine is the power and the glory, O Lord.”



```

- |   -  |
-------------|------------|
Title | God the Omnipotent |
Key |  |
Titles | undefined |
First Line | God the Omnipotent! King, who ordainest |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
