---
title: 83. O Worship the King - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 83. O Worship the King. 1. O worship the King, all glorious above, O gratefully sing His wonderful love; Our Shield and Defender, the Ancient of Days, Pavilioned in splendor, and girded with praise.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Worship the King, O worship the King, all glorious above, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 83. O WORSHIP THE KING
#### Seventh Day Adventist Hymnal

```txt



1.
O worship the King, all glorious above,
O gratefully sing His wonderful love;
Our Shield and Defender, the Ancient of Days,
Pavilioned in splendor, and girded with praise.

2.
O tell of His might, O sing of His grace,
Whose robe is the light, whose canopy space,
His chariots of wrath the deep thunderclouds form,
And dark is His path on the wings of the storm.

3.
Thy bountiful care, what tongue can recite?
It breathes in the air, it shines in the light;
It streams from the hills, it descends to the plain,
And sweetly distills in the dew and the rain.

4.
Frail children of dust, and feeble as frail,
In Thee do we trust, nor find Thee to fail;
Thy mercies how tender, how firm to the end!
Our Maker, Defender, Redeemer, and Friend.



```

- |   -  |
-------------|------------|
Title | O Worship the King |
Key |  |
Titles | undefined |
First Line | O worship the King, all glorious above, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
