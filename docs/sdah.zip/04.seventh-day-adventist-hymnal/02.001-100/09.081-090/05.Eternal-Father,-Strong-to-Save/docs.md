---
title: 85. Eternal Father, Strong to Save - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 85. Eternal Father, Strong to Save. 1. Eternal Father, strong to save, Whose arm doth bind the restless wave, Who bidd’st the mighty ocean deep Its own appointed limits keep; O hear us when we cry to Thee For those in peril on the sea.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Eternal Father, Strong to Save, Eternal Father, strong to save, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 85. ETERNAL FATHER, STRONG TO SAVE
#### Seventh Day Adventist Hymnal

```txt



1.
Eternal Father, strong to save,
Whose arm doth bind the restless wave,
Who bidd’st the mighty ocean deep
Its own appointed limits keep;
O hear us when we cry to Thee
For those in peril on the sea.

2.
O Saviour, whose almighty word
The winds and waves submissive heard,
Who walkedst on the foaming deep,
And calm amid its rage didst sleep;
O hear us when we cry to Thee
For those in peril on the sea.

3.
O Sacred Spirit, who didst brood
Upon the chaos dark and rude,
Who badd’st its angry tumult cease,
And gavest light and life and peace;
O hear us when we cry to Thee
For those in peril on the sea.

4.
O Trinity of love and power,
Our brethren shield in danger’s hour;
From rock and tempest, fire and foe,
Protect them wheresoe’er they go;
And ever let there rise to Thee
Glad hymns of praise from land and sea.



```

- |   -  |
-------------|------------|
Title | Eternal Father, Strong to Save |
Key |  |
Titles | undefined |
First Line | Eternal Father, strong to save, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
