---
title: 90. Eternal God, Whose Power Upholds - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 90. Eternal God, Whose Power Upholds. 1. Eternal God, whose power upholds Both flower and flaming star, To whom there is no here nor there, No time, no near nor far, No alien race, no foreign shore, No child unsought, unknown: O send us forth, Your prophets true, To make all lands Your own!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Eternal God, Whose Power Upholds, Eternal God, whose power upholds Both flower and flaming star, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 90. ETERNAL GOD, WHOSE POWER UPHOLDS
#### Seventh Day Adventist Hymnal

```txt



1.
Eternal God, whose power upholds Both flower and flaming star,
To whom there is no here nor there, No time, no near nor far,
No alien race, no foreign shore, No child unsought, unknown:
O send us forth, Your prophets true, To make all lands Your own!

2.
O God of truth, whom science seeks And reverent souls adore,
Illumine every earnest mind Of every clime and shore:
Dispel the gloom of error’s night, Of ignorance and fear,
Until true wisdom from above Shall make life’s pathway clear!

3.
O God of beauty, oft revealed In dreams of human art,
In speech that flows to melody, In holiness of heart:
Teach us to ban al ugliness, And all disharmony,
Till all shall know the loveliness Of lives made fair and free!

4.
O God of righteousness and grace, Seen in the Christ, Your Son,
Whose life and death reveal Your face, By whom Your will was done;
Help us to spread Your gracious reign Till greed and hate shall cease,
And kindness dwell in human hearts, And all the earth find peace!



```

- |   -  |
-------------|------------|
Title | Eternal God, Whose Power Upholds |
Key |  |
Titles | undefined |
First Line | Eternal God, whose power upholds Both flower and flaming star, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
