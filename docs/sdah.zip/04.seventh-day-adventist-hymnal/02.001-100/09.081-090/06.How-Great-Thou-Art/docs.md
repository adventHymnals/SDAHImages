---
title: 86. How Great Thou Art - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 86. How Great Thou Art. 1. O Lord my God When I in awesome wonder Consider all the worlds Thy Hands have made I see the stars I hear the rolling thunder Thy power throughout the universe displayed 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, How Great Thou Art, O Lord my God ,Then sings my soul
    author: Brian Onang'o
---

#### Advent Hymnals
## 86. HOW GREAT THOU ART
#### Seventh Day Adventist Hymnal

```txt



1.
O Lord my God
When I in awesome wonder
Consider all the worlds Thy Hands have made
I see the stars
I hear the rolling thunder
Thy power throughout the universe displayed


Refrain:
Then sings my soul
My Saviour God to Thee
How great Thou art
How great Thou art
Then sings my soul
My Saviour God to Thee
How great Thou art
How great Thou art


2.
When through the woods
And forest glades I wander
And hear the birds sing sweetly in the trees
When I look down
From lofty mountain grandeur
And see the brook and feel the gentle breeze


Refrain:
Then sings my soul
My Saviour God to Thee
How great Thou art
How great Thou art
Then sings my soul
My Saviour God to Thee
How great Thou art
How great Thou art

3.
And when I think
That God His Son not sparing
Sent Him to die I scarce can take it in
That on the Cross
My burden gladly bearing
He bled and died to take away my sin.


Refrain:
Then sings my soul
My Saviour God to Thee
How great Thou art
How great Thou art
Then sings my soul
My Saviour God to Thee
How great Thou art
How great Thou art

4.
When Christ shall come
With shouts of acclamation
And take me home
What joy shall fill my heart
Then I shall bow
In humble adoration
And then proclaim
“My God, how great Thou art!”

Refrain:
Then sings my soul
My Saviour God to Thee
How great Thou art
How great Thou art
Then sings my soul
My Saviour God to Thee
How great Thou art
How great Thou art




```

- |   -  |
-------------|------------|
Title | How Great Thou Art |
Key |  |
Titles | Then sings my soul |
First Line | O Lord my God |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
