---
title: 87. God Who Spoke in the Beginning - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 87. God Who Spoke in the Beginning. 1. God who spoke in the beginning, Forming rock and shaping spar, Set all life and growth in motion, Earthly world and distant star; He who calls the earth to order Is the ground of what we are.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God Who Spoke in the Beginning, God who spoke in the beginning, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 87. GOD WHO SPOKE IN THE BEGINNING
#### Seventh Day Adventist Hymnal

```txt



1.
God who spoke in the beginning,
Forming rock and shaping spar,
Set all life and growth in motion,
Earthly world and distant star;
He who calls the earth to order
Is the ground of what we are.

2.
God who spoke thro’ men and nations,
Thro’ events long past and gone,
Showing still today His purpose,
Speaks supremely through His Son;
He who calls the earth to order
Gives His word and it is done.

3.
God whose speech becomes incarnate –
Christ is servant, Christ is Lord –
Calls us to a life of service,
Heart and will to action stirred;
He who uses man’s obedience
Has the first and final word.



```

- |   -  |
-------------|------------|
Title | God Who Spoke in the Beginning |
Key |  |
Titles | undefined |
First Line | God who spoke in the beginning, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
