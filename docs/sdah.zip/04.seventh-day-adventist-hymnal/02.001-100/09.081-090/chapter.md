---
title: Seventh Day Adventist Hymnal - 081-090
metadata:
    description: |
      Seventh Day Adventist Hymnal - 081-090
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 081-090
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 081-090

# Index of Titles
# | Title                        
-- |-------------
81|[Though I Speak With Tongues](/seventh-day-adventist-hymnal/001-100/081-090/Though-I-Speak-With-Tongues)
82|[Before Jehova\`s Awful Throne](/seventh-day-adventist-hymnal/001-100/081-090/Before-Jehova`s-Awful-Throne)
83|[O Worship the King](/seventh-day-adventist-hymnal/001-100/081-090/O-Worship-the-King)
84|[God the Omnipotent](/seventh-day-adventist-hymnal/001-100/081-090/God-the-Omnipotent)
85|[Eternal Father, Strong to Save](/seventh-day-adventist-hymnal/001-100/081-090/Eternal-Father,-Strong-to-Save)
86|[How Great Thou Art](/seventh-day-adventist-hymnal/001-100/081-090/How-Great-Thou-Art)
87|[God Who Spoke in the Beginning](/seventh-day-adventist-hymnal/001-100/081-090/God-Who-Spoke-in-the-Beginning)
88|[I Sing the Migthy Power of God](/seventh-day-adventist-hymnal/001-100/081-090/I-Sing-the-Migthy-Power-of-God)
89|[Let All on Earth Their Voices Raise](/seventh-day-adventist-hymnal/001-100/081-090/Let-All-on-Earth-Their-Voices-Raise)
90|[Eternal God, Whose Power Upholds](/seventh-day-adventist-hymnal/001-100/081-090/Eternal-God,-Whose-Power-Upholds)