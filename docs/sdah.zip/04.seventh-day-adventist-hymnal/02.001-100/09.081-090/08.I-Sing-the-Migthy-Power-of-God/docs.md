---
title: 88. I Sing the Migthy Power of God - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 88. I Sing the Migthy Power of God. 1. I sing the almighty power of God, that made the mountains rise, that spread the flowing seas abroad, and built the lofty skies. I sing the wisdom that ordained the sun to rule the day; the moon shines full at God’s command, and all the stars obey.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Sing the Migthy Power of God, I sing the almighty power of God, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 88. I SING THE MIGTHY POWER OF GOD
#### Seventh Day Adventist Hymnal

```txt



1.
I sing the almighty power of God,
that made the mountains rise,
that spread the flowing seas abroad,
and built the lofty skies.
I sing the wisdom that ordained
the sun to rule the day;
the moon shines full at God’s command,
and all the stars obey.

2.
I sing the goodness of the Lord,
who filled the earth with food,
who formed the creatures thru the Word,
and then pronounced them good.
Lord, how thy wonders are displayed,
where’er I turn my eye,
if I survey the ground I tread,
or gaze upon the sky!

3.
There’s not a plant or flower below,
but makes thy glories known,
and clouds arise, and tempests blow,
by order from thy thrown;
while all that borrows life from thee
is ever in thy care;
and everywhere that we can be,
thou, God, art present there.



```

- |   -  |
-------------|------------|
Title | I Sing the Migthy Power of God |
Key |  |
Titles | undefined |
First Line | I sing the almighty power of God, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
