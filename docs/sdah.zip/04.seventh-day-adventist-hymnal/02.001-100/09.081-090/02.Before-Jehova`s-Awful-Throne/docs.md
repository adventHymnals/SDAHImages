---
title: 82. Before Jehova`s Awful Throne - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 82. Before Jehova`s Awful Throne. 1. Before Jehovah’s awful throne, Ye nations, bow with sacred joy; Know that the Lord is God alone; He can create, and He destroy.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Before Jehova`s Awful Throne, Before Jehovah’s awful throne, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 82. BEFORE JEHOVA`S AWFUL THRONE
#### Seventh Day Adventist Hymnal

```txt



1.
Before Jehovah’s awful throne,
Ye nations, bow with sacred joy;
Know that the Lord is God alone;
He can create, and He destroy.

2.
His sovereign power, without our aid,
Made us of clay, and formed us men;
and when like wandering sheep we strayed,
He brought us to His fold again.

3.
We’ll crowd His gates with thankful songs,
High as the heavens our voices raise;
And earth, with her ten thousand tongues,
Shall fill His courts with sounding praise.

4.
Wide as the world is His command,
Vast as Eternity His love;
Firm as a rock His truth shall stand,
When rolling years shall cease to move.



```

- |   -  |
-------------|------------|
Title | Before Jehova`s Awful Throne |
Key |  |
Titles | undefined |
First Line | Before Jehovah’s awful throne, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
