---
title: 71. Come Thou Almighty King - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 71. Come Thou Almighty King. 1. Come, Thou almighty King, Help us Thy name to sing, Help us to praise! Father all glorious, O’er all victorious, Come, and reign over us, Ancient of Days!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Come Thou Almighty King, Come, Thou almighty King, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 71. COME THOU ALMIGHTY KING
#### Seventh Day Adventist Hymnal

```txt



1.
Come, Thou almighty King,
Help us Thy name to sing,
Help us to praise!
Father all glorious,
O’er all victorious,
Come, and reign over us,
Ancient of Days!

2.
Come, Thou incarnate Word,
Gird on Thy mighty sword,
Our prayer attend;
Come, and Thy people bless,
And give Thy Word success;
Spirit of holiness,
On us descend!

3.
Come, holy Comforter,
Thy sacred witness bear,
In this glad hour:
Thou who almighty art,
Now rule in every heart,
And ne’er from us depart,
Spirit of power!

4.
To Thee, great One in Three,
Eternal praises be,
Hence, evermore:
Thy sovereign majesty
May we in glory see,
And to eternity
Love and adore!



```

- |   -  |
-------------|------------|
Title | Come Thou Almighty King |
Key |  |
Titles | undefined |
First Line | Come, Thou almighty King, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
