---
title: 80. O World of God - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 80. O World of God. 1. O world of God, so vast and strange, Profound and wonderful and fair, Beyond the utmost reach of thought, But not beyond a Father’s care! We are not strangers on this earth Whirling amid the suns of space; We are God’s children, this our home, With those of every clime and race.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O World of God, O world of God, so vast and strange, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 80. O WORLD OF GOD
#### Seventh Day Adventist Hymnal

```txt



1.
O world of God, so vast and strange,
Profound and wonderful and fair,
Beyond the utmost reach of thought,
But not beyond a Father’s care!
We are not strangers on this earth
Whirling amid the suns of space;
We are God’s children, this our home,
With those of every clime and race.

2.
O world of man where life is lived,
So strangely mingling joy and pain,
So full of evil and of good,
So needful that the god shall reign!
It is this world that God has loved,
And goodness was its Maker’s plan,
The promise of God’s triumph is
His coming in a Son of Man.

3.
O world of time’s far-stretching years!
There was a day when time stood still,
A central moment when there rose
A cross upon a cruel hill;
In pain and death love’s power was seen,
The mystery of time revealed,
The wisdom of the ways of God,
The grace through which man’s hurt is healed.



```

- |   -  |
-------------|------------|
Title | O World of God |
Key |  |
Titles | undefined |
First Line | O world of God, so vast and strange, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
