---
title: 72. Creator of the Stars of Night - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 72. Creator of the Stars of Night. 1. Creator of the stars of night, Thy people’s everlasting light, O Christ, Thou Saviour of us all, We pray Thee, hear us when we call.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Creator of the Stars of Night, Creator of the stars of night, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 72. CREATOR OF THE STARS OF NIGHT
#### Seventh Day Adventist Hymnal

```txt



1.
Creator of the stars of night,
Thy people’s everlasting light,
O Christ, Thou Saviour of us all,
We pray Thee, hear us when we call.

2.
At the great name of Jesus, now
All knees must bend, all hearts must bow;
And things celestial Thee shall own,
And things terrestrial, Lord alone.

3.
To God the Father, God the Son,
And God the Spirit, Three in One,
Laud, honour, might, and glory be
From age to age eternally.
Amen.



```

- |   -  |
-------------|------------|
Title | Creator of the Stars of Night |
Key |  |
Titles | undefined |
First Line | Creator of the stars of night, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
