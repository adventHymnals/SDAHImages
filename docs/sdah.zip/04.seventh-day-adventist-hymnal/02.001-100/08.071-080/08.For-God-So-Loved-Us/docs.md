---
title: 78. For God So Loved Us - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 78. For God So Loved Us. 1. For God so loved us, He sent the Savior: For God so loved us, and loves me too. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, For God So Loved Us, For God so loved us, ,Love so unending!
    author: Brian Onang'o
---

#### Advent Hymnals
## 78. FOR GOD SO LOVED US
#### Seventh Day Adventist Hymnal

```txt



1.
For God so loved us,
He sent the Savior:
For God so loved us,
and loves me too.


Refrain:
Love so unending!
I’ll sing His praises,
God loves His children,
loves even me.


2.
He sent the Savior,
the blest Redeemer;
He sent the Savior
to set me free.


Refrain:
Love so unending!
I’ll sing His praises,
God loves His children,
loves even me.

3.
He bade me welcome,
O word of mercy;
He bade me welcome,
O voice divine.


Refrain:
Love so unending!
I’ll sing His praises,
God loves His children,
loves even me.

4.
Glory and honor,
O Love eternal,
To Him be given
while life shall last.

Refrain:
Love so unending!
I’ll sing His praises,
God loves His children,
loves even me.




```

- |   -  |
-------------|------------|
Title | For God So Loved Us |
Key |  |
Titles | Love so unending! |
First Line | For God so loved us, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
