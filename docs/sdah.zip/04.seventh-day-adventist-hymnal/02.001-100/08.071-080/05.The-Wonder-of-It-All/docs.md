---
title: 75. The Wonder of It All - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 75. The Wonder of It All. 1. There’s the wonder of sunset at evening, The wonder as sunrise I see; But the wonder of wonders that thrills my soul Is the wonder that God loves me. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The Wonder of It All, There’s the wonder of sunset at evening, ,O, the wonder of it all!
    author: Brian Onang'o
---

#### Advent Hymnals
## 75. THE WONDER OF IT ALL
#### Seventh Day Adventist Hymnal

```txt



1.
There’s the wonder of sunset at evening,
The wonder as sunrise I see;
But the wonder of wonders that thrills my soul
Is the wonder that God loves me.


Refrain:
O, the wonder of it all!
The wonder of it all!
Just to think that God loves me.
O, the wonder of it all!
The wonder of it all!
Just to think that God loves me.


2.
There’s the wonder of springtime and harvest,
The sky, the stars, the sun;
But the wonder of wonders that thrills my soul
Is the wonder that’s only begun.

Refrain:
O, the wonder of it all!
The wonder of it all!
Just to think that God loves me.
O, the wonder of it all!
The wonder of it all!
Just to think that God loves me.




```

- |   -  |
-------------|------------|
Title | The Wonder of It All |
Key |  |
Titles | O, the wonder of it all! |
First Line | There’s the wonder of sunset at evening, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
