---
title: Seventh Day Adventist Hymnal - 071-080
metadata:
    description: |
      Seventh Day Adventist Hymnal - 071-080
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 071-080
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 071-080

# Index of Titles
# | Title                        
-- |-------------
71|[Come Thou Almighty King](/seventh-day-adventist-hymnal/001-100/071-080/Come-Thou-Almighty-King)
72|[Creator of the Stars of Night](/seventh-day-adventist-hymnal/001-100/071-080/Creator-of-the-Stars-of-Night)
73|[Holy, Holy, Holy](/seventh-day-adventist-hymnal/001-100/071-080/Holy,-Holy,-Holy)
74|[Like a River Glorious](/seventh-day-adventist-hymnal/001-100/071-080/Like-a-River-Glorious)
75|[The Wonder of It All](/seventh-day-adventist-hymnal/001-100/071-080/The-Wonder-of-It-All)
76|[O Love That Wilt Not Let Me Go](/seventh-day-adventist-hymnal/001-100/071-080/O-Love-That-Wilt-Not-Let-Me-Go)
77|[O Love of God Most Full](/seventh-day-adventist-hymnal/001-100/071-080/O-Love-of-God-Most-Full)
78|[For God So Loved Us](/seventh-day-adventist-hymnal/001-100/071-080/For-God-So-Loved-Us)
79|[O Love of God, How Strong and True!](/seventh-day-adventist-hymnal/001-100/071-080/O-Love-of-God,-How-Strong-and-True!)
80|[O World of God](/seventh-day-adventist-hymnal/001-100/071-080/O-World-of-God)