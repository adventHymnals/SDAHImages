---
title: 73. Holy, Holy, Holy - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 73. Holy, Holy, Holy. 1. Holy, holy, holy! Lord God Almighty! Early in the morning our song shall rise to Thee; Holy, holy, holy, merciful and mighty! God in three Persons, blessed Trinity!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Holy, Holy, Holy, Holy, holy, holy! Lord God Almighty! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 73. HOLY, HOLY, HOLY
#### Seventh Day Adventist Hymnal

```txt



1.
Holy, holy, holy! Lord God Almighty!
Early in the morning our song shall rise to Thee;
Holy, holy, holy, merciful and mighty!
~~God in three Persons, blessed Trinity!~~

2.
Holy, holy, holy! Angels adore Thee,
Casting down their golden crowns around the glassy sea;
Thousands and ten thousands worship low before Thee,
Which wert, and art, and evermore shalt be.

3.
Holy, holy, holy! though the darkness hide Thee,
Though the eye of sinful man Thy glory may not see;
Only Thou art holy; there is none beside Thee,
Perfect in power, in love, and purity.

4.
Holy, holy, holy! Lord God Almighty!
All Thy works shall praise Thy name, in earth, and sky, and sea;
Holy, holy, holy; merciful and mighty!
~~God in three Persons, blessed Trinity!~~



```

- |   -  |
-------------|------------|
Title | Holy, Holy, Holy |
Key |  |
Titles | undefined |
First Line | Holy, holy, holy! Lord God Almighty! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
