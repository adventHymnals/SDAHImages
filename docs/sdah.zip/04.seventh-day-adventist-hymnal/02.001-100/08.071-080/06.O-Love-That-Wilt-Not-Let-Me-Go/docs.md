---
title: 76. O Love That Wilt Not Let Me Go - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 76. O Love That Wilt Not Let Me Go. 1. O Love that wilt not let me go, I rest my weary soul in thee; I give thee back the life I owe, that in thine ocean depths its flow may richer, fuller be.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Love That Wilt Not Let Me Go, O Love that wilt not let me go, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 76. O LOVE THAT WILT NOT LET ME GO
#### Seventh Day Adventist Hymnal

```txt



1.
O Love that wilt not let me go,
I rest my weary soul in thee;
I give thee back the life I owe,
that in thine ocean depths
its flow may richer, fuller be.

2.
O Light that followest all my way,
I yield my flickering torch to thee;
my heart restores its borrowed ray,
that in they sunshine’s blaze
its day may brighter, fairer be.

3.
O Joy that seekest me through pain,
I cannot close my heart to thee;
I trace the rainbow thru the rain,
and feel the promise is not vain,
that morn shall tearless be.

4.
O Cross that liftest up my head,
I dare not ask to fly from thee;
I lay in dust life’s glory dead,
and from the ground there blossoms
red life that shall endless be.



```

- |   -  |
-------------|------------|
Title | O Love That Wilt Not Let Me Go |
Key |  |
Titles | undefined |
First Line | O Love that wilt not let me go, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
