---
title: 77. O Love of God Most Full - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 77. O Love of God Most Full. 1. O love of God most full, O love of God most free, Come warm my heart, come fill my soul, Come lead me unto Thee.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Love of God Most Full, O love of God most full, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 77. O LOVE OF GOD MOST FULL
#### Seventh Day Adventist Hymnal

```txt



1.
O love of God most full,
O love of God most free,
Come warm my heart, come fill my soul,
Come lead me unto Thee.

2.
Warm as the glowing sun
So shines Thy love on me,
It wraps me ‘round with kindly care,
It draws me unto Thee.

3.
The wildest sea is calm,
The tempest brings no fear,
The darkest night is full of light,
Because Thy love is near.

4.
O love of God most full,
O love of God most free,
It warms my heart, it fills my soul,
With might it strengthens me.



```

- |   -  |
-------------|------------|
Title | O Love of God Most Full |
Key |  |
Titles | undefined |
First Line | O love of God most full, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
