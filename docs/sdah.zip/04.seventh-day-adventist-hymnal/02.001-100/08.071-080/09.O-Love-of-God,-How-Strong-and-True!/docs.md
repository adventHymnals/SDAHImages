---
title: 79. O Love of God, How Strong and True! - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 79. O Love of God, How Strong and True!. 1. O love of God, how strong and true! Eternal, and yet ever new; Uncomprehended and unbought, Beyond all knowledge and all thought.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Love of God, How Strong and True!, O love of God, how strong and true! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 79. O LOVE OF GOD, HOW STRONG AND TRUE!
#### Seventh Day Adventist Hymnal

```txt



1.
O love of God, how strong and true!
Eternal, and yet ever new;
Uncomprehended and unbought,
Beyond all knowledge and all thought.

2.
O love of God, how deep and great,
Far deeper than man’s deepest hate;
Self-fed, self-kindled like the light,
Changeless, eternal, infinite.

3.
We read thee best in Him who cam
To bear for us the cross of shame;
Sent by the Father from on high,
Our life to live, our death to die.

4.
We read thy power to bless and save,
E’en in the darkness of the grave;
Still more in resurrection light
We read the fullness of thy might.

5.
O love of God, our shield and stay
Through all the perils of our way!
Eternal love, in thee we rest,
Forever safe, forever blest.



```

- |   -  |
-------------|------------|
Title | O Love of God, How Strong and True! |
Key |  |
Titles | undefined |
First Line | O love of God, how strong and true! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
