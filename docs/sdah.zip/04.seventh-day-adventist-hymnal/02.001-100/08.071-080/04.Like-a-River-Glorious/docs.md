---
title: 74. Like a River Glorious - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 74. Like a River Glorious. 1. Like a river glorious, is God’s perfect peace, Over all victorious, in its bright increase; Perfect, yet it floweth, fuller every day, Perfect, yet it groweth, deeper all the way. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Like a River Glorious, Like a river glorious, is God’s perfect peace, ,Stayed upon Jehovah, hearts are fully blessed
    author: Brian Onang'o
---

#### Advent Hymnals
## 74. LIKE A RIVER GLORIOUS
#### Seventh Day Adventist Hymnal

```txt



1.
Like a river glorious, is God’s perfect peace,
Over all victorious, in its bright increase;
Perfect, yet it floweth, fuller every day,
Perfect, yet it groweth, deeper all the way.


Refrain:
Stayed upon Jehovah, hearts are fully blessed
Finding, as He promised, perfect peace and rest.


2.
Hidden in the hollow of His blessed hand,
Never foe can follow, never traitor stand;
Not a surge of worry, not a shade of care,
Not a blast of hurry touch the spirit there.


Refrain:
Stayed upon Jehovah, hearts are fully blessed
Finding, as He promised, perfect peace and rest.

3.
Every joy or trial falleth from above,
Traced upon our dial by the Sun of Love;
We may trust Him fully all for us to do.
They who trust Him wholly find Him wholly true.

Refrain:
Stayed upon Jehovah, hearts are fully blessed
Finding, as He promised, perfect peace and rest.




```

- |   -  |
-------------|------------|
Title | Like a River Glorious |
Key |  |
Titles | Stayed upon Jehovah, hearts are fully blessed |
First Line | Like a river glorious, is God’s perfect peace, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
