---
title: Seventh Day Adventist Hymnal - 041-050
metadata:
    description: |
      Seventh Day Adventist Hymnal - 041-050
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 041-050
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 041-050

# Index of Titles
# | Title                        
-- |-------------
41|[O Splendor of God\`s Glory Bright](/seventh-day-adventist-hymnal/001-100/041-050/O-Splendor-of-God`s-Glory-Bright)
42|[Now That the Daylight Fills the Sky](/seventh-day-adventist-hymnal/001-100/041-050/Now-That-the-Daylight-Fills-the-Sky)
43|[When Morning Gilds the Skies](/seventh-day-adventist-hymnal/001-100/041-050/When-Morning-Gilds-the-Skies)
44|[Morning Has Broken](/seventh-day-adventist-hymnal/001-100/041-050/Morning-Has-Broken)
45|[Open Now Thy Gates of Beauty](/seventh-day-adventist-hymnal/001-100/041-050/Open-Now-Thy-Gates-of-Beauty)
46|[Abide With Me, \`Tis Eventide](/seventh-day-adventist-hymnal/001-100/041-050/Abide-With-Me,-`Tis-Eventide)
47|[God, Who Made the Earth and Heaven](/seventh-day-adventist-hymnal/001-100/041-050/God,-Who-Made-the-Earth-and-Heaven)
48|[Softly Now the Light of Day](/seventh-day-adventist-hymnal/001-100/041-050/Softly-Now-the-Light-of-Day)
49|[Savior, Breathe an Evening Blessing](/seventh-day-adventist-hymnal/001-100/041-050/Savior,-Breathe-an-Evening-Blessing)
50|[Abide With Me](/seventh-day-adventist-hymnal/001-100/041-050/Abide-With-Me)