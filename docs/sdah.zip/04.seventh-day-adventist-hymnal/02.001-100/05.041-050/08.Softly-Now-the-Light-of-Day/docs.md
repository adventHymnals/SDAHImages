---
title: 48. Softly Now the Light of Day - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 48. Softly Now the Light of Day. 1. Softly now the light of day Fades upon out sight away: Free from care, from labor free, Lord, we would commune with Thee.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Softly Now the Light of Day, Softly now the light of day 
    author: Brian Onang'o
---

#### Advent Hymnals
## 48. SOFTLY NOW THE LIGHT OF DAY
#### Seventh Day Adventist Hymnal

```txt



1.
Softly now the light of day
Fades upon out sight away:
Free from care, from labor free,
Lord, we would commune with Thee.

2.
Thou, whose allpervading eye
Nought escapes, without, within,
Pardon each infirmity,
Open fault, and secret sin.

3.
Soon from us the light of day
Shall forever pass away;
Then, from sin and sorrow free,
Take us, Lord, to dwell with Thee.



```

- |   -  |
-------------|------------|
Title | Softly Now the Light of Day |
Key |  |
Titles | undefined |
First Line | Softly now the light of day |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
