---
title: 41. O Splendor of God`s Glory Bright - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 41. O Splendor of God`s Glory Bright. 1. O splendor of God’s glory bright, From light eternal bringing light; O Light of life, light’s living spring, True day, all days illumining.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Splendor of God`s Glory Bright, O splendor of God’s glory bright, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 41. O SPLENDOR OF GOD`S GLORY BRIGHT
#### Seventh Day Adventist Hymnal

```txt



1.
O splendor of God’s glory bright,
From light eternal bringing light;
O Light of life, light’s living spring,
True day, all days illumining.

2.
O Thou true Sun, on us Thy glance
Let fall in royal radiance;
The Spirit’s sanctifying beam
Upon our earthly senses stream.

3.
O joyful be the passing day
With thoughts as clear as morning’s ray,
With faith like noontide shining bright,
Our souls unshadowed by the night.

4.
Dawn’s glory gilds the earth and skies;
Let Him, our perfect morn, arise;
The Father’s help His children claim,
And sing the Father’s glorious name. Amen.



```

- |   -  |
-------------|------------|
Title | O Splendor of God`s Glory Bright |
Key |  |
Titles | undefined |
First Line | O splendor of God’s glory bright, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
