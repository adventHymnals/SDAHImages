---
title: 45. Open Now Thy Gates of Beauty - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 45. Open Now Thy Gates of Beauty. 1. Open now thy gates of beauty, Zion, let me enter there, Where my soul in joyful duty Waits for God Who answers prayer. Oh, how blessèd is this place, Filled with solace, light, and grace!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Open Now Thy Gates of Beauty, Open now thy gates of beauty, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 45. OPEN NOW THY GATES OF BEAUTY
#### Seventh Day Adventist Hymnal

```txt



1.
Open now thy gates of beauty,
Zion, let me enter there,
Where my soul in joyful duty
Waits for God Who answers prayer.
Oh, how blessèd is this place,
Filled with solace, light, and grace!

2.
Gracious God, I come before Thee,
Come Thou also unto me;
Where we find Thee and adore Thee,
There a heav’n on earth must be.
To my heart, oh, enter Thou,
Let it be Thy temple now!

3.
Here Thy praise is gladly chanted,
Here Thy seed is duly sown;
Let my soul, where it is planted,
Bring forth precious sheaves alone,
So that all I hear may be
Fruitful unto life in me.

4.
Thou my faith increase and quicken,
Let me keep Thy gift divine,
Howsoe’er temptations thicken;
May Thy Word still o’er me shine
As my guiding star through life,
As my comfort in my strife.

5.
Speak, O God, and I will hear Thee,
Let Thy will be done indeed;
May I undisturbed draw near Thee
While Thou dost Thy people feed.
Here of life the fountain flows;
Here is balm for all our woes.



```

- |   -  |
-------------|------------|
Title | Open Now Thy Gates of Beauty |
Key |  |
Titles | undefined |
First Line | Open now thy gates of beauty, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
