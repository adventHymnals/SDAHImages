---
title: 43. When Morning Gilds the Skies - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 43. When Morning Gilds the Skies. 1. When morning gilds the skies my heart awaking cries, May Jesus Christ be praised! Alike at work and prayer, to Jesus I repair: May Jesus Christ be praised!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, When Morning Gilds the Skies, When morning gilds the skies my heart awaking cries, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 43. WHEN MORNING GILDS THE SKIES
#### Seventh Day Adventist Hymnal

```txt



1.
When morning gilds the skies my heart awaking cries,
May Jesus Christ be praised!
Alike at work and prayer, to Jesus I repair:
May Jesus Christ be praised!

2.
Whene’er the sweet church bell peals over hill and dell,
May Jesus Christ praised!
O hark to what it sings, as joyously it rings,
May Jesus Christ be praised!

3.
The night becomes as day when from the heart we say:
May Jesus Christ be praised!
The powers of darkness fear when this sweet chant they hear:
May Jesus Christ be praised!

4.
Ye nations of mankind, in this your concord find,
May Jesus Christ praised!
Let all the earth around ring joyous with the sound,
May Jesus Christ praised!

5.
In heaven’s eternal bliss the loveliest strain is this,
May Jesus Christ praised!
Let earth, and sea and sky from depth to height reply,
May Jesus Christ praised!

6.
Be this, while life is mine, my canticle divine:
May Jesus Christ be praised!
Be this th’eternal song through all the ages long,
May Jesus Christ be praised!



```

- |   -  |
-------------|------------|
Title | When Morning Gilds the Skies |
Key |  |
Titles | undefined |
First Line | When morning gilds the skies my heart awaking cries, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
