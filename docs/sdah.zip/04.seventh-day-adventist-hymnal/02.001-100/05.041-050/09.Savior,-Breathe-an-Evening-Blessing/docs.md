---
title: 49. Savior, Breathe an Evening Blessing - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 49. Savior, Breathe an Evening Blessing. 1. Savior, breathe an evening blessing, Ere repose our spirits seal; Sin and want we come confessing; Thou canst save, and Thou canst heal.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Savior, Breathe an Evening Blessing, Savior, breathe an evening blessing, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 49. SAVIOR, BREATHE AN EVENING BLESSING
#### Seventh Day Adventist Hymnal

```txt



1.
Savior, breathe an evening blessing,
Ere repose our spirits seal;
Sin and want we come confessing;
Thou canst save, and Thou canst heal.

2.
Though the night be dark and dreary,
Darkness cannot hide from Thee;
Thou art He who, never weary,
Watchest where Thy people be.

3.
Though destruction walk around us.
Though the arrow past us fly,
Angel guards from Thee Surround us,
We are safe if Thou art nigh.

4.
Should swift death this night o’re-take us,
And our couch become our tomb,
May the morn of glory wake us,
Clad in light and deathless bloom.



```

- |   -  |
-------------|------------|
Title | Savior, Breathe an Evening Blessing |
Key |  |
Titles | undefined |
First Line | Savior, breathe an evening blessing, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
