---
title: 47. God, Who Made the Earth and Heaven - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 47. God, Who Made the Earth and Heaven. 1. God, who made the earth and heaven, Darkness and light: You the day for work have given, For rest the night. May Your angel guards defend us, Slumber sweet Your mercy send us, Holy dreams and hopes attend us All through the night.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God, Who Made the Earth and Heaven, God, who made the earth and heaven, Darkness and light; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 47. GOD, WHO MADE THE EARTH AND HEAVEN
#### Seventh Day Adventist Hymnal

```txt



1.
God, who made the earth and heaven, Darkness and light:
You the day for work have given, For rest the night.
May Your angel guards defend us,
Slumber sweet Your mercy send us,
Holy dreams and hopes attend us
All through the night.

2.
And when morn again shall call us to run life’s way,
May we still, what-e’er befall us, Your will obey.
From the pow’r of evil hide us,
In the narrow pathway guide us,
Never be Your smile denied us
All through the day.

3.
Guard us waking, guard us sleeping, And, when we die,
May we in Your mighty keeping All peaceful lie.
When the trumpet call shall wake us, Then,
O Lord, do not forsake us,
But to reign in glory take us with You on high.

4.
Holy Father, throned in heaven, All holy Son,
Holy Spirit, freely given, Blest Three in One:
Grant us grace, we now implore You,
Till we lay our crowns before You
And in worthier strains adore You while ages run.



```

- |   -  |
-------------|------------|
Title | God, Who Made the Earth and Heaven |
Key |  |
Titles | undefined |
First Line | God, who made the earth and heaven, Darkness and light: |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
