---
title: 30. Holy God, We Praise Your Name - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 30. Holy God, We Praise Your Name. 1. Holy God, we praise Your name; Lord of all, we bow before You! All on earth Your scepter claim, All in heaven above adore You; Infinite Your vast domain. Everlasting is Your reign.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Holy God, We Praise Your Name, Holy God, we praise Your name; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 30. HOLY GOD, WE PRAISE YOUR NAME
#### Seventh Day Adventist Hymnal

```txt



1.
Holy God, we praise Your name;
Lord of all, we bow before You!
All on earth Your scepter claim,
All in heaven above adore You;
Infinite Your vast domain.
Everlasting is Your reign.

2.
Hark! the loud celestial hymn
Angel choirs above are raising,
Cherubim and seraphim,
In unceasing chorus praising;
Fill the heavens with sweet accord:
Holy, holy, holy, Lord.

3.
Holy Father, Holy Son,
Holy Spirit, three we name You;
While in essence only one,
Undivided God we claim You;
And adoring bend the knee,
While we own the mystery.



```

- |   -  |
-------------|------------|
Title | Holy God, We Praise Your Name |
Key | D |
Titles | undefined |
First Line | Holy God, we praise Your name; |
Author | German, 18th Century
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
