---
title: 23. Now the Joyful Bells A-Ringing - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 23. Now the Joyful Bells A-Ringing. 1. Now the joyful bells a-ring, All ye mountains of the Lord! Lift our hearts like birds a-winging, All ye mountains, praise the Lord! Now our festal season bringing Kinsmen all to bide and board, Sets our cheery voices singing; All ye mountains, praise the Lord!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Now the Joyful Bells A-Ringing, Now the joyful bells a-ring, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 23. NOW THE JOYFUL BELLS A-RINGING
#### Seventh Day Adventist Hymnal

```txt



1.
Now the joyful bells a-ring,
All ye mountains of the Lord!
Lift our hearts like birds a-winging,
All ye mountains, praise the Lord!
Now our festal season bringing
Kinsmen all to bide and board,
Sets our cheery voices singing;
All ye mountains, praise the Lord!

2.
Dear our home as dear none other;
Where the mountains praise the Lord!
Gladly here our care we smother;
Where the mountains praise the Lord!
Here we know that Christ our brother
Binds us all as by a cord:
He was born of Mary mother
Where the mountains praise the Lord!

3.
Cold the year, new whiteness wearing,
All ye mountains, praise the Lord!
Peace, good will to us a-bearing,
All ye mountains, praise the Lord!
Now we all God’s goodness sharing
Break the bread and sheath the Sword:
Bright our hearths the signal flaring,
All ye mountains, praise the Lord!



```

- |   -  |
-------------|------------|
Title | Now the Joyful Bells A-Ringing |
Key | D |
Titles | undefined |
First Line | Now the joyful bells a-ring, |
Author | Welsh Carol
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
