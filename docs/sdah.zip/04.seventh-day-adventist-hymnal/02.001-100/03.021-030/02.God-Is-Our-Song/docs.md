---
title: 22. God Is Our Song - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 22. God Is Our Song. 1. God is our Song, and every singer blest Who praising Him finds energy and rest. All who praise God with unaffected joy Give back to us the widom we destroy, Give back to us the widom we destroy.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God Is Our Song, God is our Song, and every singer blest 
    author: Brian Onang'o
---

#### Advent Hymnals
## 22. GOD IS OUR SONG
#### Seventh Day Adventist Hymnal

```txt



1.
God is our Song, and every singer blest
Who praising Him finds energy and rest.
All who praise God with unaffected joy
Give back to us the widom we destroy,
Give back to us the widom we destroy.

2.
God is our Song, for Jesus comes to save;
While praising Him we offer all we have.
New songs we sing, in ventures new unite,
When Jesus leads us upward into light,
When Jesus leads us upward into light.

3.
This is our Song no conflict ever drowns;
Who praises God our human wrath disowns.
Love knows what rich complexities of sound
God builds upon a simple common ground,
God builds upon a simple common ground.

4.
God is our Silence when no songs are sung,
When ecstasy or sorrow stills the tongue.
Glorious the faith which silently obeys
Until we find again the voice of praise,
Until we find again the voice of praise.



```

- |   -  |
-------------|------------|
Title | God Is Our Song |
Key | F |
Titles | undefined |
First Line | God is our Song, and every singer blest |
Author | Fred Pratt Green
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
