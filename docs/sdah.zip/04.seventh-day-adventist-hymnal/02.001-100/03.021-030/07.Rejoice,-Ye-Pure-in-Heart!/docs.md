---
title: 27. Rejoice, Ye Pure in Heart! - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 27. Rejoice, Ye Pure in Heart!. 1. Rejoice ye pure in heart! Rejoice, give thanks, and sing; Your festal banner wave on high, The cross of Christ your King. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Rejoice, Ye Pure in Heart!, Rejoice ye pure in heart! ,Rejoice, rejoice, rejoice,
    author: Brian Onang'o
---

#### Advent Hymnals
## 27. REJOICE, YE PURE IN HEART!
#### Seventh Day Adventist Hymnal

```txt



1.
Rejoice ye pure in heart!
Rejoice, give thanks, and sing;
Your festal banner wave on high,
The cross of Christ your King.


Refrain:
Rejoice, rejoice, rejoice,
Give thanks and sing.


2.
With voice as full and strong
As ocean’s surging praise,
Send forth the sturdy hymns of old,
The psalms of ancient days.


Refrain:
Rejoice, rejoice, rejoice,
Give thanks and sing.

3.
With all the angel choirs,
With all the saints of earth,
Pour out the strains of joy and bliss,
True rapture, noblest mirth.


Refrain:
Rejoice, rejoice, rejoice,
Give thanks and sing.

4.
Yes, on through life’s long path,
Still chanting as ye go;
From youth to age, by night and day,
In gladness and in woe.


Refrain:
Rejoice, rejoice, rejoice,
Give thanks and sing.

5.
Praise Him who reigns on high,
The Lord whom we adore,
The Father, Son and Holy Ghost,
One God forever more.

Refrain:
Rejoice, rejoice, rejoice,
Give thanks and sing.




```

- |   -  |
-------------|------------|
Title | Rejoice, Ye Pure in Heart! |
Key | F |
Titles | Rejoice, rejoice, rejoice, |
First Line | Rejoice ye pure in heart! |
Author | Edward H. Plumptre
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
