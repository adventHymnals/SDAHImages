---
title: 24. Every Star Shall Sing a Carol - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 24. Every Star Shall Sing a Carol. 1. Every star shall sing a carol; Every creatures, high or low, Come and praise the King of heaven By whatever name you know. God above, Man below, Holy is the name I know.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Every Star Shall Sing a Carol, Every star shall sing a carol; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 24. EVERY STAR SHALL SING A CAROL
#### Seventh Day Adventist Hymnal

```txt



1.
Every star shall sing a carol;
Every creatures, high or low,
Come and praise the King of heaven
By whatever name you know.
God above, Man below,
Holy is the name I know.

2.
When the King of all creation
Had a cradle on the earth,
Holy was the human body,
Holy was the human birth.
God above, Man below,
Holy is the name I know.

3.
Every star and every planet,
Every creature, high or low,
Come and praise the King of heaven
By whatever name you know.
God above, Man below,
Holy is the name I know.



```

- |   -  |
-------------|------------|
Title | Every Star Shall Sing a Carol |
Key | A#/Bb |
Titles | undefined |
First Line | Every star shall sing a carol; |
Author | Sydney Carter
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
