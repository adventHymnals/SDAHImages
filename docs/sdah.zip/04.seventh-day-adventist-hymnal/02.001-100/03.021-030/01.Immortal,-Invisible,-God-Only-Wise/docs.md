---
title: 21. Immortal, Invisible, God Only Wise - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 21. Immortal, Invisible, God Only Wise. 1. Immortal, invisible, God only wise, In light inaccessible hid from our eyes, Most blessed, most glorious, the Ancient of Days, Almighty, victorious, Thy great Name we praise.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Immortal, Invisible, God Only Wise, Immortal, invisible, God only wise, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 21. IMMORTAL, INVISIBLE, GOD ONLY WISE
#### Seventh Day Adventist Hymnal

```txt



1.
Immortal, invisible, God only wise,
In light inaccessible hid from our eyes,
Most blessed, most glorious, the Ancient of Days,
Almighty, victorious, Thy great Name we praise.

2.
Unresting, unhasting, and silent as light,
Nor wanting, nor wasting, Thou rulest in might;
Thy justice, like mountains, high soaring above
Thy clouds, which are fountains of goodness and love.

3.
To all, life Thou givest, to both great and small;
In all life Thou livest, the true life of all;
We blossom and flourish as leaves on the tree,
And wither and perish – but naught changeth Thee.

4.
Great Father of glory, pure Father of light,
Thine angels adore Thee, all veiling their sight;
All praise we would render; O help us to see
‘Tis only the splendor of light hideth Thee!



```

- |   -  |
-------------|------------|
Title | Immortal, Invisible, God Only Wise |
Key | G |
Titles | undefined |
First Line | Immortal, invisible, God only wise, |
Author | Walter Chalmers Smith
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
