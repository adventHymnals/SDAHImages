---
title: 62. How Lovely Is Thy Dwelling Place - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 62. How Lovely Is Thy Dwelling Place. 1. How lovely is Thy dwelling place, O Lord of hosts to me! The tabenacles of Thy grace How pleasant, Lord, they be!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, How Lovely Is Thy Dwelling Place, How lovely is Thy dwelling place, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 62. HOW LOVELY IS THY DWELLING PLACE
#### Seventh Day Adventist Hymnal

```txt



1.
How lovely is Thy dwelling place,
O Lord of hosts to me!
The tabenacles of Thy grace
How pleasant, Lord, they be!

2.
My thirsty soul longs ardently,
Yea, faints Thy courts to see;
My very heart and flesh cry out,
O living God, for Thee.

3.
Behold the sparrow findeth out
A house where-in to rest;
The swallow also, for herself
Provided hath a nest.

4.
Ev’n Thine own altars, where she safe
Her young ones forth may bring,
O Thou, almighty Lord of hosts,
Who art my God and King.

5.
Blest are they in Thy house that dwell,
They ever give Thee praise.
Blest is the man whose strength Thou art,
In whose heart are Thy ways.



```

- |   -  |
-------------|------------|
Title | How Lovely Is Thy Dwelling Place |
Key |  |
Titles | undefined |
First Line | How lovely is Thy dwelling place, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
