---
title: 70. Praise Ye the Father - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 70. Praise Ye the Father. 1. Praise ye the Father for His loving kindness, Tenderly cares He for His erring children; Praise Him, ye angels, praise Him in the heavens; Praise ye Jehovah!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Praise Ye the Father, Praise ye the Father for His loving kindness, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 70. PRAISE YE THE FATHER
#### Seventh Day Adventist Hymnal

```txt



1.
Praise ye the Father for His loving kindness,
Tenderly cares He for His erring children;
Praise Him, ye angels, praise Him in the heavens;
Praise ye Jehovah!

2.
Praise ye the Savior, great is the compassion,
Graciously cares He for His chosen people;
Young men and maidens, ye old men and children,
Praise ye the Savior!

3.
Praise ye the Spirit, comforter of Israel,
Sent of the Father and the Son to bless us;
Praise ye the Father, Son, and Holy Spirit,
Praise the Eternal Three!



```

- |   -  |
-------------|------------|
Title | Praise Ye the Father |
Key |  |
Titles | undefined |
First Line | Praise ye the Father for His loving kindness, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
