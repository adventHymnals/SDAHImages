---
title: 69. Lord, Make Us More Holy - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 69. Lord, Make Us More Holy. 1. Lord, make us more holy; Lord, make us more holy; Lord, make us more holy Until we meet again.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord, Make Us More Holy, Lord, make us more holy; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 69. LORD, MAKE US MORE HOLY
#### Seventh Day Adventist Hymnal

```txt



1.
Lord, make us more holy;
Lord, make us more holy;
Lord, make us more holy
Until we meet again.

2.
Lord, make us more faithful;
Lord, make us more faithful;
Lord, make us more faithful
Until we meet again.

3.
Lord, make us more humble;
Lord, make us more humble;
Lord, make us more humble
Until we meet again.

4.
Lord, make us more loving;
Lord, make us more loving;
Lord, make us more loving
Until we meet again.
Like Jesus, the Saviour,
Until we meet again.



```

- |   -  |
-------------|------------|
Title | Lord, Make Us More Holy |
Key |  |
Titles | undefined |
First Line | Lord, make us more holy; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
