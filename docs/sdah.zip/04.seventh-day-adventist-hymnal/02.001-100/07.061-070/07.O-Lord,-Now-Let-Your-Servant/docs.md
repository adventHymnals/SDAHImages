---
title: 67. O Lord, Now Let Your Servant - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 67. O Lord, Now Let Your Servant. 1. O Lord, now let Your servant Depart in heav’nly peace, For I have seen the glory Of Your redeeming grace: A light to lead the Gentiles Unto Your holy hill, The glory of Your people, Your chosen Israel.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Lord, Now Let Your Servant, O Lord, now let Your servant 
    author: Brian Onang'o
---

#### Advent Hymnals
## 67. O LORD, NOW LET YOUR SERVANT
#### Seventh Day Adventist Hymnal

```txt



1.
O Lord, now let Your servant
Depart in heav’nly peace,
For I have seen the glory
Of Your redeeming grace:
A light to lead the Gentiles
Unto Your holy hill,
The glory of Your people,
Your chosen Israel.

2.
Then grant that I may follow Your gleam,
O glorious Light,
Till earthly shadows scatter,
And faith is changed to sight;
Till raptured saints shall gather
Upon that shining shore,
Where Christ, the blessed Day star,
Shall light them evermore.



```

- |   -  |
-------------|------------|
Title | O Lord, Now Let Your Servant |
Key |  |
Titles | undefined |
First Line | O Lord, now let Your servant |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
