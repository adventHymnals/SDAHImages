---
title: 61. God Is Here! - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 61. God Is Here!. 1. God is here as we his people meet to offer praise and prayer, may we find in fuller measure what it is in Christ we share. Here, as in the world around us, all our varied skills and arts wait the coming of his Spirit into open minds and hearts.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God Is Here!, God is here as we his people 
    author: Brian Onang'o
---

#### Advent Hymnals
## 61. GOD IS HERE!
#### Seventh Day Adventist Hymnal

```txt



1.
God is here as we his people
meet to offer praise and prayer,
may we find in fuller measure
what it is in Christ we share.
Here, as in the world around us,
all our varied skills and arts
wait the coming of his Spirit
into open minds and hearts.

2.
Here are symbols to remind us
of our lifelong need of grace;
here are table, font and pulpit;
here the Word has central place.
Here in honesty of preaching,
here in silence, as in speech,
here in newness and renewal,
God the Spirit comes to each.

3.
Here our children find a welcome
in the Shepherd’s flock and fold.
Here, as bread and wine are taken,
Christ sustains us, as of old.
Here the servants of the Servant
seek in worship to explore
what it means in daily living
to believe and to adore.

4.
Lord of all, Church and Kingdom,
in an age of change and doubt,
keep us faithful to the Gospel,
help us work your purpose out.
Here, in this day’s dedication,
all we have to give, receive:
we, who cannot live without you,
we adore you! We believe!



```

- |   -  |
-------------|------------|
Title | God Is Here! |
Key |  |
Titles | undefined |
First Line | God is here as we his people |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
