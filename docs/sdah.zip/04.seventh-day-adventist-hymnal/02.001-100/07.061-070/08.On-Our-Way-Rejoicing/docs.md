---
title: 68. On Our Way Rejoicing - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 68. On Our Way Rejoicing. 1. On our way rejoicing Gladly let us go; Conquer’d hath our Leader, Vanquish’d is the foe. Christ without, our safety; Christ within, our joy; Who, if we be faithful, Can our hope destroy? 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, On Our Way Rejoicing, On our way rejoicing ,On our way rejoicing
    author: Brian Onang'o
---

#### Advent Hymnals
## 68. ON OUR WAY REJOICING
#### Seventh Day Adventist Hymnal

```txt



1.
On our way rejoicing
Gladly let us go;
Conquer’d hath our Leader,
Vanquish’d is the foe.
Christ without, our safety;
Christ within, our joy;
Who, if we be faithful,
Can our hope destroy?


Refrain:
On our way rejoicing
As we forward move,
Hearken to our praises,
O blest God of love!


2.
Unto God the Father
Joyful songs we sing,
Unto God the Savior
Thankful hearts we bring,
Unto God the Spirit
Bow we and adore,
On our way rejoicing
Now and evermore.

Refrain:
On our way rejoicing
As we forward move,
Hearken to our praises,
O blest God of love!




```

- |   -  |
-------------|------------|
Title | On Our Way Rejoicing |
Key |  |
Titles | On our way rejoicing |
First Line | On our way rejoicing |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
