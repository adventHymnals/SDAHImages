---
title: 63. O Come, Let Us Sing to the Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 63. O Come, Let Us Sing to the Lord. 1. O come, let us sing to the Lord, Come let us every one A joyful noise make to the Rock Of our salvation.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Come, Let Us Sing to the Lord, O come, let us sing to the Lord, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 63. O COME, LET US SING TO THE LORD
#### Seventh Day Adventist Hymnal

```txt



1.
O come, let us sing to the Lord,
Come let us every one
A joyful noise make to the Rock
Of our salvation.

2.
Let us before His presence come
With glad and thankful voice;
Let us sing psalms of praise to Him,
And make a joyful noise.

3.
For God, a great God and great King,
Above all gods, He is;
The depths of earth are in His hand,
The strength of hills is His.

4.
To Him the ocean vast belongs,
For He the sea did make;
The dry land also from His hands,
Its form at first did take.

5.
O come, bow down and worship Him,
And kneeling, humbly pray,
Come to our Maker and our God,
And hear His voice today.



```

- |   -  |
-------------|------------|
Title | O Come, Let Us Sing to the Lord |
Key |  |
Titles | undefined |
First Line | O come, let us sing to the Lord, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
