---
title: 66. God Be With You - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 66. God Be With You. 1. God be with you till we meet again; By His counsels guide, uphold you, With His sheep securely fold you: God be with you till we meet again.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God Be With You, God be with you till we meet again; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 66. GOD BE WITH YOU
#### Seventh Day Adventist Hymnal

```txt

1.
God be with you till we meet again;
By His counsels guide, uphold you,
With His sheep securely fold you:
God be with you till we meet again.

2.
God be with you till we meet again;
Neath His wings securely hide you,
Daily manna still provide you:
God be with you till we meet again.

3.
God be with you till we meet again;
When life’s perils thick confound you,
Put His arms unfailing round you:
God be with you till we meet again.

4.
God be with you till we meet again;
Keep love’s banner floating o’er you,
Smite death’s threatening wave before you:
God be with you till we meet again.

```

- |   -  |
-------------|------------|
Title | God Be With You |
Key |  |
Titles | undefined |
First Line | God be with you till we meet again; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
