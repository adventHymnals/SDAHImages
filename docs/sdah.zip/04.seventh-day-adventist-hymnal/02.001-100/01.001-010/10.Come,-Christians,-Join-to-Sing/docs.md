---
title: 10. Come, Christians, Join to Sing - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 10. Come, Christians, Join to Sing. 1. Come, Christians, join to sing, Alleluia! Amen! Loud praise to Christ our King; Alleluia! Amen! Let all, with heart and voice, Before His throne rejoice; Praise is His gracious choice: Alleluia! Amen!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Come, Christians, Join to Sing, Come, Christians, join to sing, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 10. COME, CHRISTIANS, JOIN TO SING
#### Seventh Day Adventist Hymnal

```txt



1.
Come, Christians, join to sing,
Alleluia! Amen!
Loud praise to Christ our King;
Alleluia! Amen!
Let all, with heart and voice,
Before His throne rejoice;
Praise is His gracious choice:
Alleluia! Amen!

2.
Come, lift your hearts on high;
Alleluia! Amen!
Let praises fill the sky;
Alleluia! Amen!
He is our Guide and Friend;
To us He’ll condescend;
His love shall never end:
Alleluia! Amen!

3.
Praise yet our Christ again;
Alleluia! Amen!
Life shall not end the strain;
Alleluia! Amen!
On heaven’s blissful shore
His goodness we’ll adore,
Singing forevermore,
Alleluia! Amen!



```

- |   -  |
-------------|------------|
Title | Come, Christians, Join to Sing |
Key | A |
Titles | undefined |
First Line | Come, Christians, join to sing, |
Author | Christian Henry Bateman
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
