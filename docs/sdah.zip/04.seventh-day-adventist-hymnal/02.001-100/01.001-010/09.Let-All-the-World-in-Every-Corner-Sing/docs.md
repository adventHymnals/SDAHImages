---
title: 9. Let All the World in Every Corner Sing - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 9. Let All the World in Every Corner Sing. 1. Let all the world in every corner sing, My God and King! The heavens are not too high, His praise may thither fly; The earth is not too low, His praises there may grow. Let all the world in every corner sing, My God and King!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Let All the World in Every Corner Sing, Let all the world in every corner sing, My God and King! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 9. LET ALL THE WORLD IN EVERY CORNER SING
#### Seventh Day Adventist Hymnal

```txt



1.
Let all the world in every corner sing, My God and King!
The heavens are not too high, His praise may thither fly;
The earth is not too low, His praises there may grow.
Let all the world in every corner sing, My God and King!

2.
Let all the world in every corner sing, My God and King!
The church with psalms must shout, No door can keep them out;
But, above all, the heart must bear the longest part.
Let all the world in every corner sing, My God and King!



```

- |   -  |
-------------|------------|
Title | Let All the World in Every Corner Sing |
Key | C#/Db |
Titles | undefined |
First Line | Let all the world in every corner sing, My God and King! |
Author | George Herbert
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
