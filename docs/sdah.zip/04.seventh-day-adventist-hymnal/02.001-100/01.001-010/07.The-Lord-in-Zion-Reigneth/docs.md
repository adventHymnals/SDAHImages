---
title: 7. The Lord in Zion Reigneth - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 7. The Lord in Zion Reigneth. 1. The Lord in Zion reigneth, let all the world rejoice, And come before His throne of grace with tuneful heart and voice; The Lord in Zion reigneth, and there His praise shall ring, To Him shall princes bend the knee and kings their glory bring.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The Lord in Zion Reigneth, The Lord in Zion reigneth, let all the world rejoice, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 7. THE LORD IN ZION REIGNETH
#### Seventh Day Adventist Hymnal

```txt



1.
The Lord in Zion reigneth, let all the world rejoice,
And come before His throne of grace with tuneful heart and voice;
The Lord in Zion reigneth, and there His praise shall ring,
To Him shall princes bend the knee and kings their glory bring.

2.
The Lord in Zion reigneth, and who so great as He?
The depths of earth are in His hands; He rules the mighty sea.
O crown His Name with honor, and let His standard wave,
Till distant isles beyond the deep shall own His power to save.

3.
The Lord in Zion reigneth, these hours to Him belong;
O enter now His temple gates, and fill His courts with song;
Beneath His royal banner let every creature fall,
Exalt the King of heaven and earth, and crown Him Lord of all.



```

- |   -  |
-------------|------------|
Title | The Lord in Zion Reigneth |
Key | D |
Titles | undefined |
First Line | The Lord in Zion reigneth, let all the world rejoice, |
Author | Fanny J. Crosby
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
