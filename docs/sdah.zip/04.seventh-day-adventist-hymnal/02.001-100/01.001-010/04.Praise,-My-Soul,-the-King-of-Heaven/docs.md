---
title: 4. Praise, My Soul, the King of Heaven - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 4. Praise, My Soul, the King of Heaven. 1. Praise, my soul, the King of heaven; To his feet thy tribute bring; Ransomed, healed, restored, forgiven, Who like thee His praise should sing? Praise Him, praise Him, alleluia! Praise the everlasting King.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Praise, My Soul, the King of Heaven, Praise, my soul, the King of heaven; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 4. PRAISE, MY SOUL, THE KING OF HEAVEN
#### Seventh Day Adventist Hymnal

```txt



1.
Praise, my soul, the King of heaven;
To his feet thy tribute bring;
Ransomed, healed, restored, forgiven,
Who like thee His praise should sing?
Praise Him, praise Him, alleluia!
Praise the everlasting King.

2.
Praise him for his grace and favor
To our fathers in distress;
Praise him still the same forever,
Slow to chide and swift to bless:
Praise Him, praise Him, alleluia!
Glorious in His faithfulness.

3.
Tenderly He shields and spares us;
Well our feeble frame he knows;
In his hands He gently bears us,
Rescues us from all our foes.
Praise Him, praise Him, alleluia!
Widely yet his mercy flows.

4.
Angels, help us to adore him;
Ye behold him face to face;
Sun and moon, bow down before him,
Dwellers all in time and space.
Praise Him, praise Him, alleluia!
Praise with us the God of grace.



```

- |   -  |
-------------|------------|
Title | Praise, My Soul, the King of Heaven |
Key | D |
Titles | undefined |
First Line | Praise, my soul, the King of heaven; |
Author | Henry Francis Lyte
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
