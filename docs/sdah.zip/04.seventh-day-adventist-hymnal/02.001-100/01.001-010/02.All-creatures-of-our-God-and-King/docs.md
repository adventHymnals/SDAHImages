---
title: 2. All creatures of our God and King - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 2. All creatures of our God and King. 1. All creatures of our God and King Lift up your voice and with us sing, Alleluia! Alleluia! O burning sun with golden beam And silver moon with softer gleam! 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, All creatures of our God and King, All creatures of our God and King ,O praise Him! O praise Him!
    author: Brian Onang'o
---

#### Advent Hymnals
## 2. ALL CREATURES OF OUR GOD AND KING
#### Seventh Day Adventist Hymnal

```txt



1.
All creatures of our God and King
Lift up your voice and with us sing,
Alleluia! Alleluia!
O burning sun with golden beam
And silver moon with softer gleam!


Refrain:
O praise Him! O praise Him!
Alleluia! Alleluia! Alleluia!


2.
O rushing wind and breezes soft,
O clouds that ride the winds aloft,
O praise Him! Alleluia!
O rising morn, in praise rejoice,
O lights of evening, find a voice!


Refrain:
O praise Him! O praise Him!
Alleluia! Alleluia! Alleluia!

3.
O flowing waters, pure and clear,
Make music for your Lord to hear,
O praise Him! Alleluia!
O fire so masterful and bright,
Providing us with warmth and light.


Refrain:
O praise Him! O praise Him!
Alleluia! Alleluia! Alleluia!

4.
Let all things their Creator bless,
And worship Him in humbleness,
O praise Him! Alleluia!
Oh, praise the Father, praise the Son,
And praise the Spirit, three in One!

Refrain:
O praise Him! O praise Him!
Alleluia! Alleluia! Alleluia!




```

- |   -  |
-------------|------------|
Title | All creatures of our God and King |
Key | D |
Titles | O praise Him! O praise Him! |
First Line | All creatures of our God and King |
Author | Francis of Asisi
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
