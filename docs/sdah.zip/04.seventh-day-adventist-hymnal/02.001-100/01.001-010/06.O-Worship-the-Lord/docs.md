---
title: 6. O Worship the Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 6. O Worship the Lord. 1. O worship the Lord in the beauty of holiness, Bow down before Him, His glory proclaim; With gold of obedience, and incense of lowliness, Kneel and adore Him: the Lord is His name.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Worship the Lord, O worship the Lord in the beauty of holiness, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 6. O WORSHIP THE LORD
#### Seventh Day Adventist Hymnal

```txt



1.
O worship the Lord in the beauty of holiness,
Bow down before Him, His glory proclaim;
With gold of obedience, and incense of lowliness,
Kneel and adore Him: the Lord is His name.

2.
Low at His feet lay thy burden of carefulness,
High on His heart He will bear it for thee,
Comfort thy sorrows, and answer thy prayerfulness,
Guiding thy steps as may best for thee be.

3.
Fear not to enter His courts in the slenderness
Of the poor wealth thou wouldst reckon as thine;
Truth in its beauty, and love in its tenderness,
These are the offerings to lay on His shrine.

4.
These, though we bring them in trembling and fearfulness,
He will accept for the name that is dear;
Mornings of joy give for evenings of tearfulness,
Trust for our trembling, and hope for our fear.



```

- |   -  |
-------------|------------|
Title | O Worship the Lord |
Key | C |
Titles | undefined |
First Line | O worship the Lord in the beauty of holiness, |
Author | J. S. B. Monsell
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
