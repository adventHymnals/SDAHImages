---
title: 8. We Gather Together - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 8. We Gather Together. 1. We gather together to ask the Lord’s blessing; He chastens and hastens His will to make known. The wicked oppressing now cease from distressing. Sing praises to His Name; He forgets not His own.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, We Gather Together, We gather together to ask the Lord’s blessing; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 8. WE GATHER TOGETHER
#### Seventh Day Adventist Hymnal

```txt



1.
We gather together to ask the Lord’s blessing;
He chastens and hastens His will to make known.
The wicked oppressing now cease from distressing.
Sing praises to His Name; He forgets not His own.

2.
Beside us to guide us, our God with us joining,
Ordaining, maintaining His kingdom divine;
So from the beginning the fight we were winning;
Thou, Lord, were at our side, all glory be Thine!

3.
We all do extol Thee, Thou leader triumphant,
And pray that Thou still our defender wilt be.
Let Thy congregation escape tribulation;
Thy name be ever praised! O Lord, make us free!



```

- |   -  |
-------------|------------|
Title | We Gather Together |
Key | C |
Titles | undefined |
First Line | We gather together to ask the Lord’s blessing; |
Author | Anon
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
