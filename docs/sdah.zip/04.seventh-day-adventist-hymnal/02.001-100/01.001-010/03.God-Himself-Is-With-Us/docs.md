---
title: 3. God Himself Is With Us - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 3. God Himself Is With Us. 1. God Himself is with us; Let us all adore Him, And with awe appear before Him. God is here within us; Soul, in silence fear Him, Humbly, fervently draw near Him. Now His own who have known God, In worship lowly, Yield their spirits wholly.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God Himself Is With Us, God Himself is with us; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 3. GOD HIMSELF IS WITH US
#### Seventh Day Adventist Hymnal

```txt



1.
God Himself is with us;
Let us all adore Him,
And with awe appear before Him.
God is here within us;
Soul, in silence fear Him,
Humbly, fervently draw near Him.
Now His own who have known God,
In worship lowly,
Yield their spirits wholly.

2.
Come, abide within me;
Let my soul, like Mary,
Be Thine earthly sanctuary.
Come, indwelling Spirit,
With transfigured splendor;
Love and honor will I render.
Where I go here below,
Let me bow before Thee,
Know Thee and adore Thee.

3.
Gladly we surrender
Earth’s deceitful treasures,
Pride of life and sinful pleasures:
Gladly, Lord, we offer
Thine to be forever,
Soul and life and each endeavor.
Thou alone shall be known
Lord of all our being,
Life’s true way decreeing.



```

- |   -  |
-------------|------------|
Title | God Himself Is With Us |
Key | G |
Titles | undefined |
First Line | God Himself is with us; |
Author | Gerhard Tersteegen
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
