---
title: 338. Redeemed!
metadata:
    description: 
    keywords: Seventh Day Adventist Hymnal, Redeemed!, , 
    author: Brian Onang'o
---


## 338. REDEEMED!

```txt
1.
Redeemed, how I love to proclaim it!
Redeemed by the blood of the Lamb;
Redeemed thro’ His infinite mercy,
His child, and forever, I am.


Refrain:
Redeemed, redeemed,
Redeemed by the blood of the Lamb;
Redeemed, how I love to proclaim it!
His child and forever I am.


2.
I think of my blessed Redeemer,
I think of Him all the day long;
I sing, for I cannot be silent;
His love is the theme of my song.


Refrain:
Redeemed, redeemed,
Redeemed by the blood of the Lamb;
Redeemed, how I love to proclaim it!
His child and forever I am.

3.
I know I shall see in His beauty
The King in whose law I delight,
Who lovingly guardeth my footsteps,
And giveth me songs in the night.

Refrain:
Redeemed, redeemed,
Redeemed by the blood of the Lamb;
Redeemed, how I love to proclaim it!
His child and forever I am.

```

- |   -  |
-------------|------------|
Title | Redeemed! |
Key |  |
Titles |  |
First Line |  |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas | 3 |
Chorus | Yes |
Chorus Type | chorus |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
