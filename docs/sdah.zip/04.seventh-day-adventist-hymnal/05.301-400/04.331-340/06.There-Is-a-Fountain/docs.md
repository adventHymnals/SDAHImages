---
title: 336. There Is a Fountain - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 336. There Is a Fountain. 1. There is a fountain filled with blood drawn from Emmanuel’s veins; And sinners plunged beneath that flood lose all their guilty stains. Lose all their guilty stains, lose all their guilty stains; And sinners plunged beneath that flood lose all their guilty stains.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, There Is a Fountain, There is a fountain filled with blood drawn from Emmanuel’s veins; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 336. THERE IS A FOUNTAIN
#### Seventh Day Adventist Hymnal

```txt



1.
There is a fountain filled with blood drawn from Emmanuel’s veins;
And sinners plunged beneath that flood lose all their guilty stains.
Lose all their guilty stains, lose all their guilty stains;
And sinners plunged beneath that flood lose all their guilty stains.

2.
The dying thief rejoiced to see that fountain in his day;
And there may I, though vile as he, wash all my sins away.
Wash all my sins away, wash all my sins away;
And there may I, though vile as he, wash all my sins away.

3.
Thou dying Lamb, Thy precious blood shall never lose its power
Till all the ransomed church of God are saved, to sin no more.
Are saved, to sin no more, are saved, to sin no more;
Till all the ransomed church of God are saved, to sin no more.

4.
E’er since, by faith, I saw the stream Thy flowing wounds supply,
Redeeming love has been my theme, and shall be till I die.
And shall be till I die, and shall be till I die;
Redeeming love has been my theme, and shall be till I die.

5.
Lord, I believe Thou hast prepared, unworthy though I be,
For me a blood-bought free reward, a golden harp for me!
A golden harp for me! A golden harp for me!
For me a blood-bought free reward, a golden harp for me!

6.
There in a nobler, sweeter song, I’ll sing Thy power to save,
When this poor lisping, stammering tongue is ransomed from the the grave.
Is ransomed from the grave, is ransomed from the grace;
When this poor lisping, stammering tongue is ransomed from the the grave.



```

- |   -  |
-------------|------------|
Title | There Is a Fountain |
Key |  |
Titles | undefined |
First Line | There is a fountain filled with blood drawn from Emmanuel’s veins; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
