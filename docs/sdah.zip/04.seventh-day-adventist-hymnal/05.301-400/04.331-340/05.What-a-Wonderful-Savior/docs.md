---
title: 335. What a Wonderful Savior - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 335. What a Wonderful Savior. 1. Christ has for sin atonement made, What a wonderful Saviour! We are redeemed! the price is paid! What a wonderful Savior! 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, What a Wonderful Savior, Christ has for sin atonement made, ,What a wonderful Savior
    author: Brian Onang'o
---

#### Advent Hymnals
## 335. WHAT A WONDERFUL SAVIOR
#### Seventh Day Adventist Hymnal

```txt



1.
Christ has for sin atonement made,
What a wonderful Saviour!
We are redeemed! the price is paid!
What a wonderful Savior!


Refrain:
What a wonderful Savior
is Jesus, my Jesus!
What a wonderful Savior
is Jesus, my Lord!


2.
I praise Him for the cleansing blood,
What a wonderful Saviour!
That reconciled my soul to God;
What a wonderful Saviour!


Refrain:
What a wonderful Savior
is Jesus, my Jesus!
What a wonderful Savior
is Jesus, my Lord!

3.
He walks beside me all the way,
What a wonderful Saviour!
And keeps me faithful day by day;
What a wonderful Saviour!


Refrain:
What a wonderful Savior
is Jesus, my Jesus!
What a wonderful Savior
is Jesus, my Lord!

4.
He gives me overcoming power,
What a wonderful Saviour!
And triumph in each trying hour;
What a wonderful Saviour!

Refrain:
What a wonderful Savior
is Jesus, my Jesus!
What a wonderful Savior
is Jesus, my Lord!




```

- |   -  |
-------------|------------|
Title | What a Wonderful Savior |
Key |  |
Titles | What a wonderful Savior |
First Line | Christ has for sin atonement made, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
