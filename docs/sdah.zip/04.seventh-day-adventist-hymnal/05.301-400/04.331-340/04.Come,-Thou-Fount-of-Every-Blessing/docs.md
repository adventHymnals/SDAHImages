---
title: 334. Come, Thou Fount of Every Blessing - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 334. Come, Thou Fount of Every Blessing. 1. Come, thou Fount of every blessing, Tune my heart to sing thy grace; Streams of mercy, never ceasing, Call for songs of loudest praise. Teach me ever to adore Thee, May I still Thy goodness prove, While the hope of endless glory Fills my heart with joy and love.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Come, Thou Fount of Every Blessing, Come, thou Fount of every blessing, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 334. COME, THOU FOUNT OF EVERY BLESSING
#### Seventh Day Adventist Hymnal

```txt



1.
Come, thou Fount of every blessing,
Tune my heart to sing thy grace;
Streams of mercy, never ceasing,
Call for songs of loudest praise.
Teach me ever to adore Thee,
May I still Thy goodness prove,
While the hope of endless glory
Fills my heart with joy and love.

2.
Here I raise mine Ebenezer;
Hither by thy help I’ve come;
And I hope, by thy good pleasure,
Safely to arrive at home.
Jesus sought me when a stranger,
Wandering from the fold of God;
He, to rescue me from danger,
Interposed his precious blood.

3.
O, to grace how great a debtor
Daily I’m constrained to be!
Let thy goodness, like a fetter,
Bind me closer still to thee.
Prone to wander, Lord, I feel it,
Prone to leave the God I love;
Here’s my heart–O, take and seal it,
Seal it for thy courts above.



```

- |   -  |
-------------|------------|
Title | Come, Thou Fount of Every Blessing |
Key |  |
Titles | undefined |
First Line | Come, thou Fount of every blessing, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
