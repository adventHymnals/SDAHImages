---
title: 340. Jesus Saves - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 340. Jesus Saves. 1. We have heard a joyful sound, Jesus saves, Jesus saves; Spread the gladness all around, Jesus saves, Jesus saves; Bear the news to every land, Climb the steeps and cross the waves, Onward, ’tis our Lord’s command, Jesus saves, Jesus saves.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Jesus Saves, We have heard a joyful sound, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 340. JESUS SAVES
#### Seventh Day Adventist Hymnal

```txt



1.
We have heard a joyful sound,
Jesus saves, Jesus saves;
Spread the gladness all around,
Jesus saves, Jesus saves;
Bear the news to every land,
Climb the steeps and cross the waves,
Onward, ’tis our Lord’s command,
Jesus saves, Jesus saves.

2.
Waft it on the rolling tide,
Jesus saves, Jesus saves;
Tell to sinners, far and wide,
Jesus saves, Jesus saves;
Sing, ye islands of the sea.
Echo back, ye ocean caves,
Earth shall keep her jubilee,
Jesus saves, Jesus saves.

3.
Sing above the battle’s strife,
Jesus saves, Jesus saves;
By His death and endless life,
Jesus saves, Jesus saves;
Sing it softly through the gloom,
When the heart for mercy craves,
Sing in triumph o’er the tomb,
Jesus saves, Jesus saves.

4.
Give the winds a mighty voice,
Jesus saves, Jesus saves;
Let the nations now rejoice,
Jesus saves, Jesus saves;
Shout salvation full and free,
Highest hills and deepest caves,
This our song of victory,
Jesus saves, Jesus saves.



```

- |   -  |
-------------|------------|
Title | Jesus Saves |
Key |  |
Titles | undefined |
First Line | We have heard a joyful sound, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
