---
title: 331. O Jesus, I Have Promised - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 331. O Jesus, I Have Promised. 1. O Jesus, I have promised to serve thee to the end; be thou forever near me, my Master and my friend. I shall not fear the battle if thou art by my side, nor wander from the pathway if thou wilt be my guide.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Jesus, I Have Promised, O Jesus, I have promised 
    author: Brian Onang'o
---

#### Advent Hymnals
## 331. O JESUS, I HAVE PROMISED
#### Seventh Day Adventist Hymnal

```txt



1.
O Jesus, I have promised
to serve thee to the end;
be thou forever near me,
my Master and my friend.
I shall not fear the battle
if thou art by my side,
nor wander from the pathway
if thou wilt be my guide.

2.
O let me feel thee near me!
The world is ever near;
I see the sights that dazzle,
the tempting sounds I hear;
my foes are ever near me,
around me and within;
but Jesus, draw thou nearer,
and shield my soul from sin.

3.
O Jesus, thou hast promised
to all who follow thee
that where thou art in glory
there shall thy servant be.
And Jesus, I have promised
to serve thee to the end;
O give me grace to follow,
my Master and my Friend.



```

- |   -  |
-------------|------------|
Title | O Jesus, I Have Promised |
Key |  |
Titles | undefined |
First Line | O Jesus, I have promised |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
