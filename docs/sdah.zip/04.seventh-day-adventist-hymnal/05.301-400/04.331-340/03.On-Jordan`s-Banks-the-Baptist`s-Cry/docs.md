---
title: 333. On Jordan`s Banks the Baptist`s Cry - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 333. On Jordan`s Banks the Baptist`s Cry. 1. On Jordan’s banks the Baptist’s cry Announces that the Lord is nigh; Awake and hearken, for he brings Glad tidings of the King of kings!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, On Jordan`s Banks the Baptist`s Cry, On Jordan’s banks the Baptist’s cry 
    author: Brian Onang'o
---

#### Advent Hymnals
## 333. ON JORDAN`S BANKS THE BAPTIST`S CRY
#### Seventh Day Adventist Hymnal

```txt



1.
On Jordan’s banks the Baptist’s cry
Announces that the Lord is nigh;
Awake and hearken, for he brings
Glad tidings of the King of kings!

2.
Then cleansed be every life from sin;
Make straight the way for God within,
And let us all our hearts prepare
For Christ to come and enter there.

3.
We hail You as our Savior, Lord,
Our refuge and our great reward;
Without Your grace we waste away
Like flow’rs that wither and decay.

4.
Stretch forth Your hand, our health restore,
And make us rise to fall no more;
Oh, let Your face upon us shine
And fill the world with love divine.



```

- |   -  |
-------------|------------|
Title | On Jordan`s Banks the Baptist`s Cry |
Key |  |
Titles | undefined |
First Line | On Jordan’s banks the Baptist’s cry |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
