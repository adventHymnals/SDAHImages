---
title: 339. God Is My Strong Salvation - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 339. God Is My Strong Salvation. 1. God is my strong salvation, What foe have I to fear? In darkness and temptation, My Light, my Help, is near: Though hosts encamp around me, Firm in the fight I stand; What terror can confound me, With God at my right hand?
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God Is My Strong Salvation, God is my strong salvation, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 339. GOD IS MY STRONG SALVATION
#### Seventh Day Adventist Hymnal

```txt



1.
God is my strong salvation,
What foe have I to fear?
In darkness and temptation,
My Light, my Help, is near:
Though hosts encamp around me,
Firm in the fight I stand;
What terror can confound me,
With God at my right hand?

2.
Place on the reliance;
My soul with courage wait;
His truth be thine affiance,
When faint and desolate.
His might thy heart shall strengthen,
His love thy joy increase;
Mercy thy days shall lengthen;
The Lord will give thee peace.



```

- |   -  |
-------------|------------|
Title | God Is My Strong Salvation |
Key |  |
Titles | undefined |
First Line | God is my strong salvation, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
