---
title: 332. The Cleansing Wave - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 332. The Cleansing Wave. 1. Oh now I see the crimson wave, The fountain deep and wide; Jesus, my Lord, mighty to save, Points to His wounded side. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The Cleansing Wave, Oh now I see the crimson wave, ,The cleansing stream I see, I see,
    author: Brian Onang'o
---

#### Advent Hymnals
## 332. THE CLEANSING WAVE
#### Seventh Day Adventist Hymnal

```txt



1.
Oh now I see the crimson wave,
The fountain deep and wide;
Jesus, my Lord, mighty to save,
Points to His wounded side.


Refrain:
The cleansing stream I see, I see,
I plunge, and O, it cleanseth me!
O praise the Lord! it cleanseth me,
It cleanseth me, yes, cleanseth me.


2.
I see the new creation rise,
I hear the speaking blood;
It speaks polluted nature dies,
Sinks ‘neath the cleansing flood.


Refrain:
The cleansing stream I see, I see,
I plunge, and O, it cleanseth me!
O praise the Lord! it cleanseth me,
It cleanseth me, yes, cleanseth me.

3.
I rise to walk in heaven’s own light,
Above the world and sin;
With heart made pure and garments white,
And Christ enthroned within.


Refrain:
The cleansing stream I see, I see,
I plunge, and O, it cleanseth me!
O praise the Lord! it cleanseth me,
It cleanseth me, yes, cleanseth me.

4.
Amazing grace! ’tis heaven below
To feel the blood applied,
And Jesus, only Jesus, know,
My Jesus crucified.

Refrain:
The cleansing stream I see, I see,
I plunge, and O, it cleanseth me!
O praise the Lord! it cleanseth me,
It cleanseth me, yes, cleanseth me.




```

- |   -  |
-------------|------------|
Title | The Cleansing Wave |
Key |  |
Titles | The cleansing stream I see, I see, |
First Line | Oh now I see the crimson wave, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
