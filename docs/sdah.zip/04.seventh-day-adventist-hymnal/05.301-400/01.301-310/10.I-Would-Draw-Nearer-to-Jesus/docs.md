---
title: 310. I Would Draw Nearer to Jesus - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 310. I Would Draw Nearer to Jesus. 1. I would draw nearer to Jesus, In His sweet presence abide, Constantly trying to serve Him, Safe and secure at His side. I would draw nearer to Jesus, I would draw nearer to Him; Fully surrendered each moment, I would draw nearer to Him.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Would Draw Nearer to Jesus, I would draw nearer to Jesus, In His sweet presence abide, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 310. I WOULD DRAW NEARER TO JESUS
#### Seventh Day Adventist Hymnal

```txt



1.
I would draw nearer to Jesus, In His sweet presence abide,
Constantly trying to serve Him, Safe and secure at His side.
I would draw nearer to Jesus, I would draw nearer to Him;
Fully surrendered each moment, I would draw nearer to Him.

2.
I would draw nearer to Jesus, Nothing withholding from Him,
Knowing He loves to be gracious, I would draw nearer to Him.
I would draw nearer to Jesus, I would draw nearer to Him;
Fully surrendered each moment, I would draw nearer to Him.

3.
I would draw nearer to Jesus, Seeking Hi strength to be true,
Willing to tell of His goodness, Gladly His blest will to do.
I would draw nearer to Jesus, I would draw nearer to Him;
Fully surrendered each moment, I would draw nearer to Him.



```

- |   -  |
-------------|------------|
Title | I Would Draw Nearer to Jesus |
Key |  |
Titles | undefined |
First Line | I would draw nearer to Jesus, In His sweet presence abide, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
