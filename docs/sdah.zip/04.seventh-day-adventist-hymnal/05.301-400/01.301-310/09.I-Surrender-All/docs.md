---
title: 309. I Surrender All - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 309. I Surrender All. 1. All to Jesus I surrender; all to him I freely give; I will ever love and trust him, in his presence daily live. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Surrender All, All to Jesus I surrender; ,I surrender all, I surrender all,
    author: Brian Onang'o
---

#### Advent Hymnals
## 309. I SURRENDER ALL
#### Seventh Day Adventist Hymnal

```txt



1.
All to Jesus I surrender;
all to him I freely give;
I will ever love and trust him,
in his presence daily live.


Refrain:
I surrender all, I surrender all,
all to thee, my blessed Savior,
I surrender all.


2.
All to Jesus I surrender;
humbly at his feet I bow,
worldly pleasures all forsaken;
take me, Jesus, take me now.


Refrain:
I surrender all, I surrender all,
all to thee, my blessed Savior,
I surrender all.

3.
All to Jesus I surrender;
make me, Savior, wholly thine;
fill me with thy love and power;
truly know that thou art mine.


Refrain:
I surrender all, I surrender all,
all to thee, my blessed Savior,
I surrender all.

4.
All to Jesus I surrender;
now I feel the sacred flame.
O the joy of full salvation!
Glory, glory, to his name!

Refrain:
I surrender all, I surrender all,
all to thee, my blessed Savior,
I surrender all.




```

- |   -  |
-------------|------------|
Title | I Surrender All |
Key |  |
Titles | I surrender all, I surrender all, |
First Line | All to Jesus I surrender; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
