---
title: 306. Draw Me Nearer - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 306. Draw Me Nearer. 1. I am thine, O Lord, I have heard thy voice, and it told thy love to me; but I long to rise in the arms of faith and be closer drawn to thee. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Draw Me Nearer, I am thine, O Lord, I have heard thy voice, ,Draw me nearer, nearer, blessed Lord,
    author: Brian Onang'o
---

#### Advent Hymnals
## 306. DRAW ME NEARER
#### Seventh Day Adventist Hymnal

```txt



1.
I am thine, O Lord, I have heard thy voice,
and it told thy love to me;
but I long to rise in the arms of faith
and be closer drawn to thee.


Refrain:
Draw me nearer, nearer, blessed Lord,
to the cross where thou hast died.
Draw me nearer, nearer, nearer, blessed Lord,
to thy precious, bleeding side.


2.
Consecrate me now to thy service, Lord,
by the power of grace divine;
let my soul look up with a steadfast hope,
and my will be lost in thine.


Refrain:
Draw me nearer, nearer, blessed Lord,
to the cross where thou hast died.
Draw me nearer, nearer, nearer, blessed Lord,
to thy precious, bleeding side.

3.
O the pure delight of a single hour
that before thy throne I spend,
when I kneel in prayer, and with thee, my God,
I commune as friend with friend!

Refrain:
Draw me nearer, nearer, blessed Lord,
to the cross where thou hast died.
Draw me nearer, nearer, nearer, blessed Lord,
to thy precious, bleeding side.




```

- |   -  |
-------------|------------|
Title | Draw Me Nearer |
Key |  |
Titles | Draw me nearer, nearer, blessed Lord, |
First Line | I am thine, O Lord, I have heard thy voice, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
