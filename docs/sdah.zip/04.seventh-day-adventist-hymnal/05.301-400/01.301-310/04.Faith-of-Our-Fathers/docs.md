---
title: 304. Faith of Our Fathers - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 304. Faith of Our Fathers. 1. Faith of our fathers, living still, In spite of dungeon, fire and sword; O how our hearts beat high with joy Whenever we hear that glorious Word! Faith of our fathers, holy faith! We will be true to thee till death.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Faith of Our Fathers, Faith of our fathers, living still, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 304. FAITH OF OUR FATHERS
#### Seventh Day Adventist Hymnal

```txt



1.
Faith of our fathers, living still,
In spite of dungeon, fire and sword;
O how our hearts beat high with joy
Whenever we hear that glorious Word!
Faith of our fathers, holy faith!
We will be true to thee till death.

2.
Our fathers, chained in prisons dark,
Were still in heart and conscience free:
How sweet would be their children’s fate.
If they, like them, could die for thee!
Faith of our fathers, holy faith!
We will be true to thee till death.

3.
Faith of our fathers, we will love
Both friend and foe in all our strife;
And preach Thee, too, as love knows how
By kindly words and virtuous life.
Faith of our fathers, holy faith!
We will be true to thee till death.



```

- |   -  |
-------------|------------|
Title | Faith of Our Fathers |
Key |  |
Titles | undefined |
First Line | Faith of our fathers, living still, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
