---
title: 305. Give Me Jesus - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 305. Give Me Jesus. 1. In the morning, when I rise In the morning, when I rise In the morning, when I rise 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Give Me Jesus, In the morning, when I rise ,Give me Jesus.
    author: Brian Onang'o
---

#### Advent Hymnals
## 305. GIVE ME JESUS
#### Seventh Day Adventist Hymnal

```txt



1.
In the morning, when I rise
In the morning, when I rise
In the morning, when I rise


Refrain:
Give me Jesus.
Give me Jesus,
Give me Jesus.
You can have all this world,
Just give me Jesus.


2.
Dark mid-night was my cry,
Dark mid-night was my cry,
Dark midnight was my cry,
Give me Jesus.


Refrain:
Give me Jesus.
Give me Jesus,
Give me Jesus.
You can have all this world,
Just give me Jesus.

3.
Just about the break of day,
Just about the break of day,
Just about the break of day,
Give me Jesus.


Refrain:
Give me Jesus.
Give me Jesus,
Give me Jesus.
You can have all this world,
Just give me Jesus.

4.
Oh, when I come to die,
Oh, when I come to die,
Oh, when I come to die,
Give me Jesus.

Refrain:
Give me Jesus.
Give me Jesus,
Give me Jesus.
You can have all this world,
Just give me Jesus.




```

- |   -  |
-------------|------------|
Title | Give Me Jesus |
Key |  |
Titles | Give me Jesus. |
First Line | In the morning, when I rise |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
