---
title: 301. Near, Still Nearer - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 301. Near, Still Nearer. 1. Nearer, still nearer, close to Thy heart, Draw me, my Savior, so precious Thou art; Fold me, O fold me close to Thy breast, Shelter me safe in that haven of rest, Shelter me safe in that haven of rest.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Near, Still Nearer, Nearer, still nearer, close to Thy heart, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 301. NEAR, STILL NEARER
#### Seventh Day Adventist Hymnal

```txt



1.
Nearer, still nearer, close to Thy heart,
Draw me, my Savior, so precious Thou art;
Fold me, O fold me close to Thy breast,
Shelter me safe in that haven of rest,
Shelter me safe in that haven of rest.

2.
Nearer, still nearer, nothing I bring,
Nought as an offering to Jesus my King-
Only my sinful now contrite heart,
Grant me the cleansing Thy blood doth impart,
Grant me the cleansing Thy blood doth impart.

3.
Nearer, still nearer, Lord, to be Thine;
Sin, with its follies, I gladly resign,
All of its pleasures, pomp and its pride;
Give me but Jesus, my Lord crucified,
Give me but Jesus, my Lord crucified.

4.
Nearer, still nearer, while life shall last;
Till safe in glory my anchor is cast;
Through endless ages, ever to be,
Nearer, my Savior, still nearer to Thee,
Nearer, my Savior, still nearer to Thee.



```

- |   -  |
-------------|------------|
Title | Near, Still Nearer |
Key |  |
Titles | undefined |
First Line | Nearer, still nearer, close to Thy heart, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
