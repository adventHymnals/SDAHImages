---
title: 303. Beneath the Cross of Jesus - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 303. Beneath the Cross of Jesus. 1. Beneath the cross of Jesus I fain would take my stand, the shadow of a mighty rock within a weary land; a home within the wilderness, a rest upon the way, from the burning of the noontide heat, and the burden of the day.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Beneath the Cross of Jesus, Beneath the cross of Jesus 
    author: Brian Onang'o
---

#### Advent Hymnals
## 303. BENEATH THE CROSS OF JESUS
#### Seventh Day Adventist Hymnal

```txt



1.
Beneath the cross of Jesus
I fain would take my stand,
the shadow of a mighty rock
within a weary land;
a home within the wilderness,
a rest upon the way,
from the burning of the noontide heat,
and the burden of the day.

2.
Upon that cross of Jesus
mine eye at times can see
the very dying form of One
who suffered there for me;
and from my stricken heart with tears
two wonders I confess:
the wonders of redeeming love
and my unworthiness.

3.
I take, O cross, thy shadow
for my abiding place;
I ask no other sunshine than
the sunshine of his face;
content to let the world go by,
to know no gain nor loss,
my sinful self my only shame,
my glory all the cross.



```

- |   -  |
-------------|------------|
Title | Beneath the Cross of Jesus |
Key |  |
Titles | undefined |
First Line | Beneath the cross of Jesus |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
