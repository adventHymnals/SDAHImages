---
title: 302. Deeper Yet - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 302. Deeper Yet. 1. In the blood from the cross, I have been washed from sin; But to be free from dross, Still I would enter in. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Deeper Yet, In the blood from the cross, ,Deeper yet, deeper yet,
    author: Brian Onang'o
---

#### Advent Hymnals
## 302. DEEPER YET
#### Seventh Day Adventist Hymnal

```txt



1.
In the blood from the cross,
I have been washed from sin;
But to be free from dross,
Still I would enter in.


Refrain:
Deeper yet, deeper yet,
Into the crimson flood;
Deeper yet, deeper yet,
Under the precious blood.


2.
Day by day, hour by hour,
Blessings are sent to me;
But for more of His power,
Ever my prayer shall be.


Refrain:
Deeper yet, deeper yet,
Into the crimson flood;
Deeper yet, deeper yet,
Under the precious blood.

3.
Near to Christ I would live,
Following Him each day;
What I ask He will give;
So then with faith I pray.


Refrain:
Deeper yet, deeper yet,
Into the crimson flood;
Deeper yet, deeper yet,
Under the precious blood.

4.
Now I have peace, sweet peace,
While in this world of sin;
But to pray I’ll not cease
Till I am pure within.

Refrain:
Deeper yet, deeper yet,
Into the crimson flood;
Deeper yet, deeper yet,
Under the precious blood.




```

- |   -  |
-------------|------------|
Title | Deeper Yet |
Key |  |
Titles | Deeper yet, deeper yet, |
First Line | In the blood from the cross, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
