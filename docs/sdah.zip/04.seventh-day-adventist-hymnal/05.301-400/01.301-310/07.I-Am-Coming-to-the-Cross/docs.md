---
title: 307. I Am Coming to the Cross - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 307. I Am Coming to the Cross. 1. I am coming to the cross; I am poor and weak and blind; I am counting all but dross; I shall full salvation find. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Am Coming to the Cross, I am coming to the cross; ,I am trusting, Lord, in Thee.
    author: Brian Onang'o
---

#### Advent Hymnals
## 307. I AM COMING TO THE CROSS
#### Seventh Day Adventist Hymnal

```txt



1.
I am coming to the cross;
I am poor and weak and blind;
I am counting all but dross;
I shall full salvation find.


Refrain:
I am trusting, Lord, in Thee.
O thou Lamb of Calvary;
Humbly at Thy cross I bow.
Save me, Jesus, save me now.


2.
Long my heart has sighed for Thee;
Long has evil reigned within;
Jesus sweetly speaks to me:
“I will cleanse you from all sin.”


Refrain:
I am trusting, Lord, in Thee.
O thou Lamb of Calvary;
Humbly at Thy cross I bow.
Save me, Jesus, save me now.

3.
Here I give my all to Thee:
Friends and time and earthly store;
Soul and body Thine to be,
Wholly Thine forevermore.


Refrain:
I am trusting, Lord, in Thee.
O thou Lamb of Calvary;
Humbly at Thy cross I bow.
Save me, Jesus, save me now.

4.
Jesus comes! He fills my soul!
Perfected in Him I am;
I am every whit made whole:
Glory, glory to the Lamb!

Refrain:
I am trusting, Lord, in Thee.
O thou Lamb of Calvary;
Humbly at Thy cross I bow.
Save me, Jesus, save me now.




```

- |   -  |
-------------|------------|
Title | I Am Coming to the Cross |
Key |  |
Titles | I am trusting, Lord, in Thee. |
First Line | I am coming to the cross; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
