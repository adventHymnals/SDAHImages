---
title: 308. Wholly Thine - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 308. Wholly Thine. 1. I would be, dear Savior, wholly Thine; Teach me how, teach me how; I would do Thy will, O Lord, not mine; Help me, help me now. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Wholly Thine, I would be, dear Savior, wholly Thine; ,Wholly Thine, wholly Thine,
    author: Brian Onang'o
---

#### Advent Hymnals
## 308. WHOLLY THINE
#### Seventh Day Adventist Hymnal

```txt



1.
I would be, dear Savior, wholly Thine;
Teach me how, teach me how;
I would do Thy will, O Lord, not mine;
Help me, help me now.


Refrain:
Wholly Thine, wholly Thine,
Wholly Thine, this is my vow;
Wholly Thine, wholly Thine,
Wholly Thine, O Lord, just now.


2.
What is worldly pleasure, wealth or fame,
Without Thee, without Thee?
I will leave them all for Thy dear Name,
This my wealth shall be.


Refrain:
Wholly Thine, wholly Thine,
Wholly Thine, this is my vow;
Wholly Thine, wholly Thine,
Wholly Thine, O Lord, just now.

3.
As I cast earth’s transient joys behind,
Come Thou near, come Thou near;
In Thy presence all in all I find,
’Tis my comfort here.

Refrain:
Wholly Thine, wholly Thine,
Wholly Thine, this is my vow;
Wholly Thine, wholly Thine,
Wholly Thine, O Lord, just now.




```

- |   -  |
-------------|------------|
Title | Wholly Thine |
Key |  |
Titles | Wholly Thine, wholly Thine, |
First Line | I would be, dear Savior, wholly Thine; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
