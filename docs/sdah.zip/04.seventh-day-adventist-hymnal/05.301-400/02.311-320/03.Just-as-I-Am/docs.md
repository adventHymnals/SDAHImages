---
title: 313. Just as I Am - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 313. Just as I Am. 1. Just as I am, without one plea, But that Thy blood was shed for me, And that Thou bidst me come to Thee, O Lamb of God, I come, I come.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Just as I Am, Just as I am, without one plea, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 313. JUST AS I AM
#### Seventh Day Adventist Hymnal

```txt



1.
Just as I am, without one plea,
But that Thy blood was shed for me,
And that Thou bidst me come to Thee,
O Lamb of God, I come, I come.

2.
Just as I am, and waiting not
To rid my soul of one dark blot,
To Thee whose blood can cleanse each spot,
O Lamb of God, I come, I come.

3.
Just as I am, though tossed about
With many a conflict, many a doubt,
“Fightings within, and fears without,”
O Lamb of God, I come, I come.

4.
Just as I am, poor, wretched, blind;
Sight, riches, healing of the mind,
Yea, all I need in Thee to find,
O Lamb of God, I come, I come.

5.
Just as I am, Thou wilt receive,
Wilt welcome, pardon, cleanse, relieve;
Because Thy promise I believe,
O Lamb of God, I come, I come.

6.
Just as I am, Thy love I own
Has broken every barrier down;
Now, to be Thine, and Thine alone,
O Lamb of God, I come, I come.



```

- |   -  |
-------------|------------|
Title | Just as I Am |
Key |  |
Titles | undefined |
First Line | Just as I am, without one plea, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
