---
title: 318. Whiter Than Snow - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 318. Whiter Than Snow. 1. Lord Jesus, I long to be perfectly whole; I want Thee forever to live in my soul; Break down every idol, cast out every foe; Now wash me, and I shall be whiter than snow. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Whiter Than Snow, Lord Jesus, I long to be perfectly whole; ,Whiter than snow, yes, whiter than snow;
    author: Brian Onang'o
---

#### Advent Hymnals
## 318. WHITER THAN SNOW
#### Seventh Day Adventist Hymnal

```txt



1.
Lord Jesus, I long to be perfectly whole;
I want Thee forever to live in my soul;
Break down every idol, cast out every foe;
Now wash me, and I shall be whiter than snow.


Refrain:
Whiter than snow, yes, whiter than snow;
Now wash me, and I shall be whiter than snow.


2.
Lord Jesus, look down from Thy throne in the skies,
And help me to make a complete sacrifice;
I give up myself, and whatever I know;
Now wash me, and I shall be whiter than snow.


Refrain:
Whiter than snow, yes, whiter than snow;
Now wash me, and I shall be whiter than snow.

3.
Lord Jesus, for this I most humbly entreat;
I wait, blessed Lord, at Thy crucified feet,
By faith, for my cleansing; I see Thy blood flow;
Now wash me, and I shall be whiter than snow.


Refrain:
Whiter than snow, yes, whiter than snow;
Now wash me, and I shall be whiter than snow.

4.
Lord Jesus, Thou seest I patiently wait;
Come now, and within me a new heart create;
To those who have sought Thee,
Thou never said’st No;
Now wash me, and I shall be whiter than snow.

Refrain:
Whiter than snow, yes, whiter than snow;
Now wash me, and I shall be whiter than snow.




```

- |   -  |
-------------|------------|
Title | Whiter Than Snow |
Key |  |
Titles | Whiter than snow, yes, whiter than snow; |
First Line | Lord Jesus, I long to be perfectly whole; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
