---
title: 320. Lord of Creation - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 320. Lord of Creation. 1. Lord of creation, to you be all praise! Most mighty your working, most wondrous your ways! Your glory and might are beyond us to tell, And yet in the heart of the humble you dwell.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord of Creation, Lord of creation, to you be all praise! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 320. LORD OF CREATION
#### Seventh Day Adventist Hymnal

```txt



1.
Lord of creation, to you be all praise!
Most mighty your working, most wondrous your ways!
Your glory and might are beyond us to tell,
And yet in the heart of the humble you dwell.

2.
Lord of all power, I give you my will,
In joyful obedience your tasks to fulfill.
Your bondage is freedom; your service is song;
And held in your keeping, my weakness is strong.

3.
Lord of all wisdom, I give you my mind,
Rich truth that surpasses man’s knowledge to find;
What eye has not seen and what ear has not heard
Is taught by your spirit and shines from your word.

4.
Lord of all being, I give you my all,
If I ever disown you, I stumble and fall;
But led in your service your word to obey,
I’ll walk in your freedom to the end of the way.



```

- |   -  |
-------------|------------|
Title | Lord of Creation |
Key |  |
Titles | undefined |
First Line | Lord of creation, to you be all praise! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
