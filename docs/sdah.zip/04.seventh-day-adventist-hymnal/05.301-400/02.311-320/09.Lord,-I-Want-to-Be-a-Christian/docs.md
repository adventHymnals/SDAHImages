---
title: 319. Lord, I Want to Be a Christian - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 319. Lord, I Want to Be a Christian. 1. Lord, I want to be a Christian in my heart, in my heart, Lord, I want to be a Christian in my heart, in my heart. In my heart, in my heart, Lord, I want to be a Christian in my heart, in my heart.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord, I Want to Be a Christian, Lord, I want to be a Christian in my heart, in my heart, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 319. LORD, I WANT TO BE A CHRISTIAN
#### Seventh Day Adventist Hymnal

```txt



1.
Lord, I want to be a Christian in my heart, in my heart,
Lord, I want to be a Christian in my heart, in my heart.
In my heart, in my heart,
Lord, I want to be a Christian in my heart, in my heart.

2.
Lord, I want to be more loving in my heart, in my heart,
Lord, I want to be more loving in my heart, in my heart.
In my heart, in my heart,
Lord, I want to be more loving in my heart, in my heart.

3.
Lord, I want to be more holy in my heart, in my heart,
Lord, I want to be more holy in my heart, in my heart.
In my heart, in my heart,
Lord, I want to be more holy in my heart, in my heart.

4.
Lord, I want to be more like Jesus in my heart, in my heart,
Lord, I want to be more like Jesus in my heart, in my heart.
In my heart, in my heart,
Lord, I want to be more like Jesus in my heart, in my heart.



```

- |   -  |
-------------|------------|
Title | Lord, I Want to Be a Christian |
Key |  |
Titles | undefined |
First Line | Lord, I want to be a Christian in my heart, in my heart, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
