---
title: 311. I Would Be Like Jesus - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 311. I Would Be Like Jesus. 1. Earthly pleasures vainly call me; I would be like Jesus; Nothing worldly shall enthrall me; I would be like Jesus. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Would Be Like Jesus, Earthly pleasures vainly call me; ,Be like Jesus, this my song,
    author: Brian Onang'o
---

#### Advent Hymnals
## 311. I WOULD BE LIKE JESUS
#### Seventh Day Adventist Hymnal

```txt



1.
Earthly pleasures vainly call me;
I would be like Jesus;
Nothing worldly shall enthrall me;
I would be like Jesus.


Refrain:
Be like Jesus, this my song,
In the home and in the throng;
Be like Jesus, all day long!
I would be like Jesus.


2.
He has broken every fetter,
I would be like Jesus;
That my soul may serve Him better,
I would be like Jesus.


Refrain:
Be like Jesus, this my song,
In the home and in the throng;
Be like Jesus, all day long!
I would be like Jesus.

3.
All the way from earth to glory,
I would be like Jesus;
Telling o’er and o’er the story,
I would be like Jesus.


Refrain:
Be like Jesus, this my song,
In the home and in the throng;
Be like Jesus, all day long!
I would be like Jesus.

4.
That in Heaven He may meet me,
I would be like Jesus;
That His words “Well done” may greet me,
I would be like Jesus.

Refrain:
Be like Jesus, this my song,
In the home and in the throng;
Be like Jesus, all day long!
I would be like Jesus.




```

- |   -  |
-------------|------------|
Title | I Would Be Like Jesus |
Key |  |
Titles | Be like Jesus, this my song, |
First Line | Earthly pleasures vainly call me; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
