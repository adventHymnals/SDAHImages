---
title: 315. O for a Closer Walk! - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 315. O for a Closer Walk!. 1. O for a closer walk with God, A calm and heavenly frame, A light to shine upon the road That leads me to the Lamb!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O for a Closer Walk!, O for a closer walk with God, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 315. O FOR A CLOSER WALK!
#### Seventh Day Adventist Hymnal

```txt



1.
O for a closer walk with God,
A calm and heavenly frame,
A light to shine upon the road
That leads me to the Lamb!

2.
Return, O holy Dove, return,
Sweet messenger of rest!
I hate the sins that made Thee mourn
And drove Thee from my breast.

3.
What peaceful hours I once enjoyed!
How sweet their memory still!
But they have left an aching void
The world can never fill.

4.
The dearest idol I have known,
What-e’er that idol be,
Help me to tear it from Thy throne,
And worship only Thee.



```

- |   -  |
-------------|------------|
Title | O for a Closer Walk! |
Key |  |
Titles | undefined |
First Line | O for a closer walk with God, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
