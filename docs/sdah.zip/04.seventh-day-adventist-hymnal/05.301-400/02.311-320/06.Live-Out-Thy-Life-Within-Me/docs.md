---
title: 316. Live Out Thy Life Within Me - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 316. Live Out Thy Life Within Me. 1. Live out Thy life within me, O Jesus, King of kings! Be Thou Thyself the answer To all my questionings; Live out Thy life within me, In all things have Thy way! I, the transparent medium Thy glory to display.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Live Out Thy Life Within Me, Live out Thy life within me, O Jesus, King of kings! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 316. LIVE OUT THY LIFE WITHIN ME
#### Seventh Day Adventist Hymnal

```txt



1.
Live out Thy life within me, O Jesus, King of kings!
Be Thou Thyself the answer To all my questionings;
Live out Thy life within me, In all things have Thy way!
I, the transparent medium Thy glory to display.

2.
The temple has been yielded, And purified of sin;
Let Thy Shekinah glory Now shine forth from within,
And all the earth keep silence, The body henceforth be
Thy silent, gentle servant, Moved only as by Thee.

3.
Its members every moment Held subject to Thy call,
Ready to have Thee use them, Or not be used at all;
Held without restless longing, Or strain, or stress, or fret
Or chafings at Thy dealings, Or thoughts of vain regret.

4.
But restful, calm, and pliant, From bend and bias free,
Awaiting Thy decision, When Thou hast need of me.
Live out Thy life within me, O Jesus, King of kings!
Be Thou the glorious answer To all my questionings.



```

- |   -  |
-------------|------------|
Title | Live Out Thy Life Within Me |
Key |  |
Titles | undefined |
First Line | Live out Thy life within me, O Jesus, King of kings! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
