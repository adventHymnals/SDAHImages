---
title: 317. Lead Me to Calvary - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 317. Lead Me to Calvary. 1. King of my life, I crown Thee now, Thine shall the glory be; Lest I forget Thy thorn crowned brow, Lead me to Calvary. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lead Me to Calvary, King of my life, I crown Thee now, ,Lest I forget Gethsemane,
    author: Brian Onang'o
---

#### Advent Hymnals
## 317. LEAD ME TO CALVARY
#### Seventh Day Adventist Hymnal

```txt



1.
King of my life, I crown Thee now,
Thine shall the glory be;
Lest I forget Thy thorn crowned brow,
Lead me to Calvary.


Refrain:
Lest I forget Gethsemane,
Lest I forget Thine agony;
Lest I forget Thy love for me,
Lead me to Calvary.


2.
Show me the tomb where Thou wast laid,
Tenderly mourned and wept;
Angels in robes of light arrayed
Guarded Thee whilst Thou slept.


Refrain:
Lest I forget Gethsemane,
Lest I forget Thine agony;
Lest I forget Thy love for me,
Lead me to Calvary.

3.
Let me like Mary, through the gloom,
Come with a gift to Thee;
Show to me now the empty tomb,
Lead me to Calvary.


Refrain:
Lest I forget Gethsemane,
Lest I forget Thine agony;
Lest I forget Thy love for me,
Lead me to Calvary.

4.
May I be willing, Lord, to bear
Daily my cross for Thee;
Even Thy cup of grief to share,
Thou hast borne all for me.

Refrain:
Lest I forget Gethsemane,
Lest I forget Thine agony;
Lest I forget Thy love for me,
Lead me to Calvary.




```

- |   -  |
-------------|------------|
Title | Lead Me to Calvary |
Key |  |
Titles | Lest I forget Gethsemane, |
First Line | King of my life, I crown Thee now, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
