---
title: 314. Just as I Am
metadata:
    description: 
    keywords: Seventh Day Adventist Hymnal, Just as I Am, , 
    author: Brian Onang'o
---


## 314. JUST AS I AM

```txt
1.
Just as I am, without one plea,
but that thy blood was shed for me,
and that thou bidst me come to thee,
O Lamb of God, I come, I come.

2.
Just as I am, and waiting not
to rid my soul of one dark blot,
to thee whose blood can cleanse each spot,
O Lamb of God, I come, I come.

3.
Just as I am, though tossed about
with many a conflict, many a doubt,
fightings and fears within, without,
O Lamb of God, I come, I come.

4.
Just as I am, poor, wretched, blind;
sight, riches, healing of the mind,
yea, all I need in thee to find,
O Lamb of God, I come, I come.

5.
Just as I am, thou wilt receive,
wilt welcome, pardon, cleanse, relieve;
because thy promise I believe,
O Lamb of God, I come, I come.

6.
Just as I am, thy love I own
hath broken every barrier down;
now, to be thine, and thine alone,
O Lamb of God, I come, I come.
```

- |   -  |
-------------|------------|
Title | Just as I Am |
Key |  |
Titles |  |
First Line |  |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas | 6 |
Chorus | No |
Chorus Type | - |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
