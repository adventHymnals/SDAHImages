---
title: 312. Near the Cross - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 312. Near the Cross. 1. Jesus, keep me near the cross; there a precious fountain, free to all, a healing stream, flows from Calvary’s mountain. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Near the Cross, Jesus, keep me near the cross; ,In the cross, in the cross,
    author: Brian Onang'o
---

#### Advent Hymnals
## 312. NEAR THE CROSS
#### Seventh Day Adventist Hymnal

```txt



1.
Jesus, keep me near the cross;
there a precious fountain,
free to all, a healing stream,
flows from Calvary’s mountain.


Refrain:
In the cross, in the cross,
be my glory ever,
till my raptured soul shall find
rest beyond the river.


2.
Near the cross, a trembling soul,
love and mercy found me;
there the bright and morning star
sheds its beams around me.


Refrain:
In the cross, in the cross,
be my glory ever,
till my raptured soul shall find
rest beyond the river.

3.
Near the cross! O Lamb of God,
bring its scenes before me;
help me walk from day to day
with its shadow o’er me.


Refrain:
In the cross, in the cross,
be my glory ever,
till my raptured soul shall find
rest beyond the river.

4.
Near the cross I’ll watch and wait,
hoping, trusting ever,
till I reach the golden strand

Refrain:
In the cross, in the cross,
be my glory ever,
till my raptured soul shall find
rest beyond the river.




```

- |   -  |
-------------|------------|
Title | Near the Cross |
Key |  |
Titles | In the cross, in the cross, |
First Line | Jesus, keep me near the cross; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
