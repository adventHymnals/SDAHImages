---
title: Seventh Day Adventist Hymnal - 311-320
metadata:
    description: |
      Seventh Day Adventist Hymnal - 311-320
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 311-320
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 311-320

# Index of Titles
# | Title                        
-- |-------------
311|[I Would Be Like Jesus](/seventh-day-adventist-hymnal/301-400/311-320/I-Would-Be-Like-Jesus)
312|[Near the Cross](/seventh-day-adventist-hymnal/301-400/311-320/Near-the-Cross)
313|[Just as I Am](/seventh-day-adventist-hymnal/301-400/311-320/Just-as-I-Am)
314|[Just as I Am](/seventh-day-adventist-hymnal/301-400/311-320/Just-as-I-Am_1)
315|[O for a Closer Walk!](/seventh-day-adventist-hymnal/301-400/311-320/O-for-a-Closer-Walk!)
316|[Live Out Thy Life Within Me](/seventh-day-adventist-hymnal/301-400/311-320/Live-Out-Thy-Life-Within-Me)
317|[Lead Me to Calvary](/seventh-day-adventist-hymnal/301-400/311-320/Lead-Me-to-Calvary)
318|[Whiter Than Snow](/seventh-day-adventist-hymnal/301-400/311-320/Whiter-Than-Snow)
319|[Lord, I Want to Be a Christian](/seventh-day-adventist-hymnal/301-400/311-320/Lord,-I-Want-to-Be-a-Christian)
320|[Lord of Creation](/seventh-day-adventist-hymnal/301-400/311-320/Lord-of-Creation)