---
title: 392. Dear Lord, We Come at Set of Sun - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 392. Dear Lord, We Come at Set of Sun. 1. Dear Lord, we come at set of sun, And at Your feet we kneel To worship You, Creator, King, This day, Your sign and seal.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Dear Lord, We Come at Set of Sun, Dear Lord, we come at set of sun, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 392. DEAR LORD, WE COME AT SET OF SUN
#### Seventh Day Adventist Hymnal

```txt



1.
Dear Lord, we come at set of sun,
And at Your feet we kneel
To worship You, Creator, King,
This day, Your sign and seal.

2.
Our earthly tasks we lay aside,
According to Your Word,
To enter now Your holy rest,
The Sabbath of the Lord.

3.
Sweet Sabbath rest, your sacred hours
Are as a golden chain
That reaches back to Eden’s gate
And points us home again.

4.
And when this earth shall be renewed,
And sin and death destroyed,
Shall all redeemed each Sabbath day
Still meet to praise their God.



```

- |   -  |
-------------|------------|
Title | Dear Lord, We Come at Set of Sun |
Key |  |
Titles | undefined |
First Line | Dear Lord, we come at set of sun, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
