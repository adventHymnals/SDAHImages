---
title: 391. Welcome, Welcome, Day of Rest - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 391. Welcome, Welcome, Day of Rest. 1. To the world in kindness given; Welcome to this humble breast, As the beaming light from heaven.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Welcome, Welcome, Day of Rest, To the world in kindness given; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 391. WELCOME, WELCOME, DAY OF REST
#### Seventh Day Adventist Hymnal

```txt



1.
To the world in kindness given;
Welcome to this humble breast,
As the beaming light from heaven.

2.
Day of calm and sweet repose,
Gently now thy moments run;
Balm to soothe our cares and woes,
Till our labor here is done.

3.
Holy day that most we prize,
Day of solemn praise and prayer,
Day to make the simple wise,
O, how great thy blessings are!

4.
Welcome, welcome, day of rest,
With thy influence all divine;
May thy hallowed hours be blessed
to this waiting heart of mine.



```

- |   -  |
-------------|------------|
Title | Welcome, Welcome, Day of Rest |
Key |  |
Titles | undefined |
First Line | To the world in kindness given; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
