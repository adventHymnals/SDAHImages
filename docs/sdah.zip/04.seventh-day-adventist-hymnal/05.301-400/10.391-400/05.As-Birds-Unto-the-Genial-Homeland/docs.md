---
title: 395. As Birds Unto the Genial Homeland - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 395. As Birds Unto the Genial Homeland. 1. As birds unto the genial homeland fly, The winter’s cold and low’ring skies to flee, So seeks my soul Thy gracious presence here And finds, O God, its rest and peace in Thee.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, As Birds Unto the Genial Homeland, As birds unto the genial homeland fly, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 395. AS BIRDS UNTO THE GENIAL HOMELAND
#### Seventh Day Adventist Hymnal

```txt



1.
As birds unto the genial homeland fly,
The winter’s cold and low’ring skies to flee,
So seeks my soul Thy gracious presence here
And finds, O God, its rest and peace in Thee.

2.
Here at Thy shrine we leave all vexing care,
For get the disappointment, grief and tear,
And on the wings of hopeful song and prayer
We rise, and rising feel Thy Spirit here.

3.
Bless all who spend this night in pain and woe,
The burdened heart, the fainting, and distressed,
Thy comfort send to darkened homes bereaved,
Thy saving help to those by want oppressed.

4.
Come, Sabbath joy, each trusting heart now fill,
And blissful peace within our homes abide,
May thankful praise each grateful heart now thrill,
And to God’s loving care their lives confide.



```

- |   -  |
-------------|------------|
Title | As Birds Unto the Genial Homeland |
Key |  |
Titles | undefined |
First Line | As birds unto the genial homeland fly, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
