---
title: 397. An Upper Room - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 397. An Upper Room. 1. An upper room did our Lord prepare For those loved until the end: And His disciples still gather there, To celebrate their risen Friend.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, An Upper Room, An upper room did our Lord prepare 
    author: Brian Onang'o
---

#### Advent Hymnals
## 397. AN UPPER ROOM
#### Seventh Day Adventist Hymnal

```txt



1.
An upper room did our Lord prepare
For those loved until the end:
And His disciples still gather there,
To celebrate their risen Friend.

2.
And after supper He washed their feet,
For service, too, is sacrament.
In Him our joy shall be made complete
Sent out to serve, as He was sent.

3.
A lasting gift Jesus gave His own:
To share His bread, His loving cup.
Whatever burdens may bow us down,
He by His cross shall lift us up.

4.
No end there is! we depart in peace.
He loves beyond our uttermost:
In every room in our Father’s house,
He will be there, as Lord and host.



```

- |   -  |
-------------|------------|
Title | An Upper Room |
Key |  |
Titles | undefined |
First Line | An upper room did our Lord prepare |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
