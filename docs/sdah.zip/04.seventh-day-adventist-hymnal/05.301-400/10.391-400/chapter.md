---
title: Seventh Day Adventist Hymnal - 391-400
metadata:
    description: |
      Seventh Day Adventist Hymnal - 391-400
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 391-400
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 391-400

# Index of Titles
# | Title                        
-- |-------------
391|[Welcome, Welcome, Day of Rest](/seventh-day-adventist-hymnal/301-400/391-400/Welcome,-Welcome,-Day-of-Rest)
392|[Dear Lord, We Come at Set of Sun](/seventh-day-adventist-hymnal/301-400/391-400/Dear-Lord,-We-Come-at-Set-of-Sun)
393|[Lord of the Sabbath](/seventh-day-adventist-hymnal/301-400/391-400/Lord-of-the-Sabbath)
394|[Far From All Care](/seventh-day-adventist-hymnal/301-400/391-400/Far-From-All-Care)
395|[As Birds Unto the Genial Homeland](/seventh-day-adventist-hymnal/301-400/391-400/As-Birds-Unto-the-Genial-Homeland)
396|[Lord God, Your Love Has Called Us Here](/seventh-day-adventist-hymnal/301-400/391-400/Lord-God,-Your-Love-Has-Called-Us-Here)
397|[An Upper Room](/seventh-day-adventist-hymnal/301-400/391-400/An-Upper-Room)
398|[Bread of the World](/seventh-day-adventist-hymnal/301-400/391-400/Bread-of-the-World)
399|[Beneath the Forms of Outward Rite](/seventh-day-adventist-hymnal/301-400/391-400/Beneath-the-Forms-of-Outward-Rite)
400|[I Come With Joy](/seventh-day-adventist-hymnal/301-400/391-400/I-Come-With-Joy)