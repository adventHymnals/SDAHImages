---
title: 398. Bread of the World - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 398. Bread of the World. 1. Bread of the world in mercy broken, Wine of the soul in mercy shed, By whom the words of life are spoken, And in whose death our sins are dead;
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Bread of the World, Bread of the world in mercy broken, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 398. BREAD OF THE WORLD
#### Seventh Day Adventist Hymnal

```txt



1.
Bread of the world in mercy broken,
Wine of the soul in mercy shed,
By whom the words of life are spoken,
And in whose death our sins are dead;

2.
Look on the heart by sorrow broken,
Look on the tears by sinners shed;
And be Thy feast to us the token
That by Thy grace our souls are fed. Amen.



```

- |   -  |
-------------|------------|
Title | Bread of the World |
Key |  |
Titles | undefined |
First Line | Bread of the world in mercy broken, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
