---
title: 393. Lord of the Sabbath - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 393. Lord of the Sabbath. 1. Lord of the Sabbath and its light, I hail Thy hallowed day of rest; It is my weary soul’s delight, The solace of my careworn breast, The solace of my careworn breast.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord of the Sabbath, Lord of the Sabbath and its light, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 393. LORD OF THE SABBATH
#### Seventh Day Adventist Hymnal

```txt



1.
Lord of the Sabbath and its light,
I hail Thy hallowed day of rest;
It is my weary soul’s delight,
The solace of my careworn breast,
The solace of my careworn breast.

2.
O sacred day of peace and joy,
Thy hours are ever dear to me;
Ne’er may a sinful thought destroy
The holy calm I find in thee,
The holy calm I find in thee.

3.
How sweetly now they glide along!
How hallowed is the calm they yield!
Transporting is their rapturous song,
And heavenly visions seem revealed,
And heavenly visions seem revealed.

4.
O Jesus, let me ever hail
Thy presence with the day of rest;
Then will Thy servant never fail
To deem Thy Sabbath doubly blest,
To deem Thy Sabbath doubly blest.



```

- |   -  |
-------------|------------|
Title | Lord of the Sabbath |
Key |  |
Titles | undefined |
First Line | Lord of the Sabbath and its light, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
