---
title: 400. I Come With Joy - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 400. I Come With Joy. 1. I come with joy to meet my Lord, Forgiven, loved and free, In awe and wonder to recall His life laid down for me, His life laid down for me.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Come With Joy, I come with joy to meet my Lord, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 400. I COME WITH JOY
#### Seventh Day Adventist Hymnal

```txt



1.
I come with joy to meet my Lord,
Forgiven, loved and free,
In awe and wonder to recall
His life laid down for me,
His life laid down for me.

2.
I come with Christians far and near
To find, as all are fed,
Our true community of love
In Christ’s communion bread,
In Christ’s communion bread.

3.
As Christ breaks bread for us to share
Each proud division ends.
That love that made us makes us one,
And strangers now are friends,
And strangers now are friends.

4.
And thus with joy we meet our Lord.
His presence always near,
Is in such friendship better known:
We see and praise Him here,
We see and praise Him here.

5.
Together met, together bound,
We’ll go our diff’rent ways,
And as His people in the world,
We’ll live and speak His praise,
We’ll live and speak His praise.



```

- |   -  |
-------------|------------|
Title | I Come With Joy |
Key |  |
Titles | undefined |
First Line | I come with joy to meet my Lord, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
