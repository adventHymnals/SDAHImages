---
title: 394. Far From All Care - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 394. Far From All Care. 1. Far from all care we hail the Sabbath morning; O’er waving fields and from the distant sea Swell notes of praise in harmony resounding As all creation turns her heart to Thee.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Far From All Care, Far from all care we hail the Sabbath morning; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 394. FAR FROM ALL CARE
#### Seventh Day Adventist Hymnal

```txt



1.
Far from all care we hail the Sabbath morning;
O’er waving fields and from the distant sea
Swell notes of praise in harmony resounding
As all creation turns her heart to Thee.

2.
Though man alone, Lord, of Thy great creation
Fails now to laud Thee for Thy love and power,
Yet still a remnant love Thee and remember
Thy holy law and each sweet Sabbath hour.

3.
Lord of the Sabbath, Savior and Creator,
Calm now the throbbings of each troubled breast.
Speak to our hearts the peace of Thy commandments,
Breathe on each soul fair Eden’s hallowed ret.

4.
Strong in Thy might and quiet in Thy meekness,
May we Thine image bear from day to day.
Then may we enter pearly gates eternal
And sing redemption’s song each Sabbath day.



```

- |   -  |
-------------|------------|
Title | Far From All Care |
Key |  |
Titles | undefined |
First Line | Far from all care we hail the Sabbath morning; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
