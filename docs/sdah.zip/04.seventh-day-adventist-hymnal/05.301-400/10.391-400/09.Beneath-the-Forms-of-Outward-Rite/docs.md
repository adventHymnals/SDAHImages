---
title: 399. Beneath the Forms of Outward Rite - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 399. Beneath the Forms of Outward Rite. 1. Beneath the forms of outward rite Thy supper, Lord, is spread In every quiet upper room Where fainting souls are fed.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Beneath the Forms of Outward Rite, Beneath the forms of outward rite 
    author: Brian Onang'o
---

#### Advent Hymnals
## 399. BENEATH THE FORMS OF OUTWARD RITE
#### Seventh Day Adventist Hymnal

```txt



1.
Beneath the forms of outward rite
Thy supper, Lord, is spread
In every quiet upper room
Where fainting souls are fed.

2.
The bread is always consecrate
Which men divide with men;
And every act of brotherhood
Repeats Thy feast again.

3.
The blessed cup is only passed
True memory of Thee,
When life anew pours out its wine
With rich sufficiency.

4.
O Master, through these symbols shared,
Thine own dear self impart,
That in our daily life may flame
The passion of Thy heart.



```

- |   -  |
-------------|------------|
Title | Beneath the Forms of Outward Rite |
Key |  |
Titles | undefined |
First Line | Beneath the forms of outward rite |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
