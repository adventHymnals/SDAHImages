---
title: 341. To God Be the Glory - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 341. To God Be the Glory. 1. To God be the glory, great things he hath done! So loved he the world that he gave us his Son, who yielded his life an atonement for sin, and opened the lifegate that all may go in. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, To God Be the Glory, To God be the glory, great things he hath done! ,Praise the Lord, praise the Lord,
    author: Brian Onang'o
---

#### Advent Hymnals
## 341. TO GOD BE THE GLORY
#### Seventh Day Adventist Hymnal

```txt



1.
To God be the glory, great things he hath done!
So loved he the world that he gave us his Son,
who yielded his life an atonement for sin,
and opened the lifegate that all may go in.


Refrain:
Praise the Lord, praise the Lord,
let the earth hear his voice!
Praise the Lord, praise the Lord,
let the people rejoice!
O come to the Father thru Jesus the Son,
and give him the glory, great things he hath done!


2.
O perfect redemption, the purchase of blood,
to every believer the promise of God;
the vilest offender who truly believes,
that moment from Jesus a pardon receives.


Refrain:
Praise the Lord, praise the Lord,
let the earth hear his voice!
Praise the Lord, praise the Lord,
let the people rejoice!
O come to the Father thru Jesus the Son,
and give him the glory, great things he hath done!

3.
Great things he hath taught us, great things he hath done,
and great our rejoicing thru Jesus the Son;
but purer, and higher, and greater will be
our wonder, our transport, when Jesus we see.

Refrain:
Praise the Lord, praise the Lord,
let the earth hear his voice!
Praise the Lord, praise the Lord,
let the people rejoice!
O come to the Father thru Jesus the Son,
and give him the glory, great things he hath done!




```

- |   -  |
-------------|------------|
Title | To God Be the Glory |
Key |  |
Titles | Praise the Lord, praise the Lord, |
First Line | To God be the glory, great things he hath done! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
