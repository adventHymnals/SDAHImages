---
title: 343. I Will Sing of My Redeemer - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 343. I Will Sing of My Redeemer. 1. I will sing of my Redeemer, And His wondrous love to me; On the cruel cross He suffered, From the curse to set me free. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Will Sing of My Redeemer, I will sing of my Redeemer, ,Sing, oh sing, of my Redeemer,
    author: Brian Onang'o
---

#### Advent Hymnals
## 343. I WILL SING OF MY REDEEMER
#### Seventh Day Adventist Hymnal

```txt



1.
I will sing of my Redeemer,
And His wondrous love to me;
On the cruel cross He suffered,
From the curse to set me free.


Refrain:
Sing, oh sing, of my Redeemer,
With His blood, He purchased me.
On the cross, He sealed my pardon,
Paid the debt, and made me free.


2.
I will tell the wondrous story,
How my lost estate to save,
In His boundless love and mercy,
He the ransom freely gave.


Refrain:
Sing, oh sing, of my Redeemer,
With His blood, He purchased me.
On the cross, He sealed my pardon,
Paid the debt, and made me free.

3.
I will sing of my Redeemer,
And His heavenly love to me;
He from death to life hath brought me,
Son of God with Him to be.

Refrain:
Sing, oh sing, of my Redeemer,
With His blood, He purchased me.
On the cross, He sealed my pardon,
Paid the debt, and made me free.




```

- |   -  |
-------------|------------|
Title | I Will Sing of My Redeemer |
Key |  |
Titles | Sing, oh sing, of my Redeemer, |
First Line | I will sing of my Redeemer, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
