---
title: 347. Built on the Rock - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 347. Built on the Rock. 1. Built on the Rock the Church shall stand, Even when steeples are falling; Crumbled have spires in every land, Bells still are chiming and calling Calling the young and old to rest, Calling the souls of those distressed, Longing for life everlasting.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Built on the Rock, Built on the Rock the Church shall stand, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 347. BUILT ON THE ROCK
#### Seventh Day Adventist Hymnal

```txt



1.
Built on the Rock the Church shall stand,
Even when steeples are falling;
Crumbled have spires in every land,
Bells still are chiming and calling
Calling the young and old to rest,
Calling the souls of those distressed,
Longing for life everlasting.

2.
Not in our temples made with hands
God, the Almighty, is dwelling;
High in the heav’ns His temple stands,
All earthly temples excelling.
Yet He who dwells in heav’n above
Deigns to abide with us in love,
Making our bodies His temple.

3.
We are God’s house of living stones,
Built for His own habitation;
He fills our hearts, His humble thrones,
Granting us life and salvation.
Were two or three to seek His face,
He in their midst would show His grace,
Blessings upon them bestowing.

4.
Yet in this house, an earthly frame,
Jesus His children is blessing;
Hither we come to praise His name,
Faith in our Savior confessing.
Jesus to us His Spirit sent,
Making with us His covenant,
Granting His children the kingdom.

5.
Thro‘ all the passing years, O Lord,
Grant that, when church bells are ringing,
Many may come to hear God’s Word
Where He this promise is bringing:
I know My own, My own know Me:
You, not the world, My face shall see;
My peace I leave with you. Amen.



```

- |   -  |
-------------|------------|
Title | Built on the Rock |
Key |  |
Titles | undefined |
First Line | Built on the Rock the Church shall stand, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
