---
title: 348. The Church Has One Foundation - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 348. The Church Has One Foundation. 1. The church’s one foundation is Jesus Christ her Lord; she is his new creation by water and the Word. From heaven he came and sought her to be his holy bride; with his own blood he bought her, and for her life he died.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The Church Has One Foundation, The church’s one foundation 
    author: Brian Onang'o
---

#### Advent Hymnals
## 348. THE CHURCH HAS ONE FOUNDATION
#### Seventh Day Adventist Hymnal

```txt



1.
The church’s one foundation
is Jesus Christ her Lord;
she is his new creation
by water and the Word.
From heaven he came and sought her
to be his holy bride;
with his own blood he bought her,
and for her life he died.

2.
Elect from every nation,
yet one o’er all the earth;
her charter of salvation,
one Lord, one faith, one birth;
one holy name she blesses,
partakes one holy food,
and to one hope she presses,
with every grace endued.

3.
Though with a scornful wonder
we see her sore oppressed,
by schisms rent asunder,
by heresies distressed,
yet saints their watch are keeping;
their cry goes up, “How long?”
And soon the night of weeping
shall be the morn of song.

4.
‘Mid toil and tribulation,
and tumult of her war,
she waits the consummation
of peace forevermore;
till, with the vision glorious,
her longing eyes are blest,
and the great church victorious
shall be the church at rest.



```

- |   -  |
-------------|------------|
Title | The Church Has One Foundation |
Key |  |
Titles | undefined |
First Line | The church’s one foundation |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
