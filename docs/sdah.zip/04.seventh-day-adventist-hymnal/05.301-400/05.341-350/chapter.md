---
title: Seventh Day Adventist Hymnal - 341-350
metadata:
    description: |
      Seventh Day Adventist Hymnal - 341-350
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 341-350
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 341-350

# Index of Titles
# | Title                        
-- |-------------
341|[To God Be the Glory](/seventh-day-adventist-hymnal/301-400/341-350/To-God-Be-the-Glory)
342|[Is This a Day of New Beginnings?](/seventh-day-adventist-hymnal/301-400/341-350/Is-This-a-Day-of-New-Beginnings?)
343|[I Will Sing of My Redeemer](/seventh-day-adventist-hymnal/301-400/341-350/I-Will-Sing-of-My-Redeemer)
344|[I Love Your Kingdom, Lord](/seventh-day-adventist-hymnal/301-400/341-350/I-Love-Your-Kingdom,-Lord)
345|[Christ Is the World\`s True Light](/seventh-day-adventist-hymnal/301-400/341-350/Christ-Is-the-World`s-True-Light)
346|[Lord, Who Dost Give to Thy Church](/seventh-day-adventist-hymnal/301-400/341-350/Lord,-Who-Dost-Give-to-Thy-Church)
347|[Built on the Rock](/seventh-day-adventist-hymnal/301-400/341-350/Built-on-the-Rock)
348|[The Church Has One Foundation](/seventh-day-adventist-hymnal/301-400/341-350/The-Church-Has-One-Foundation)
349|[God is Love](/seventh-day-adventist-hymnal/301-400/341-350/God-is-Love)
350|[Blest Be the Tie That Binds](/seventh-day-adventist-hymnal/301-400/341-350/Blest-Be-the-Tie-That-Binds)