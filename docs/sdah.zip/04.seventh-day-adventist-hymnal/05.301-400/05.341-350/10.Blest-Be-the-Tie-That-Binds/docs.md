---
title: 350. Blest Be the Tie That Binds - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 350. Blest Be the Tie That Binds. 1. Blest be the tie that binds our hearts in Christian love; the fellowship of kindred minds is like to that above.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Blest Be the Tie That Binds, Blest be the tie that binds 
    author: Brian Onang'o
---

#### Advent Hymnals
## 350. BLEST BE THE TIE THAT BINDS
#### Seventh Day Adventist Hymnal

```txt



1.
Blest be the tie that binds
our hearts in Christian love;
the fellowship of kindred minds
is like to that above.

2.
Before our Father’s throne
we pour our ardent prayers;
our fears, our hopes, our aims are one,
our comforts and our cares.

3.
We share each other’s woes,
our mutual burdens bear;
and often for each other flows
the sympathizing tear.

4.
When we asunder part,
it gives us inward pain;
but we shall still be joined in heart,
and hope to meet again.



```

- |   -  |
-------------|------------|
Title | Blest Be the Tie That Binds |
Key |  |
Titles | undefined |
First Line | Blest be the tie that binds |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
