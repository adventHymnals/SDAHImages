---
title: 349. God is Love - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 349. God is Love. 1. Here in Christ we gather, love of Christ our calling. Christ, our love, is with us, gladness be His greeting. Let us fear Him, yes, and love Him, God eternal. Loving Him, let each love Christ in all his brethren. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God is Love, Here in Christ we gather, love of Christ our calling. ,God is love, and where true love is
    author: Brian Onang'o
---

#### Advent Hymnals
## 349. GOD IS LOVE
#### Seventh Day Adventist Hymnal

```txt



1.
Here in Christ we gather, love of Christ our calling.
Christ, our love, is with us, gladness be His greeting.
Let us fear Him, yes, and love Him, God eternal.
Loving Him, let each love Christ in all his brethren.


Refrain:
God is love, and where true love is
God Himself is there.


2.
When we Christians gather, members of one body,
Let there be in us no discord but one spirit.
Banished now be anger, strife, and every quarrel.
Christ, our God, be always present here among us.


Refrain:
God is love, and where true love is
God Himself is there.

3.
Grant us love’s fulfillment, joy with all the blessed,
When we see Your face, O Savior, in its glory.
Shine on us, O purest Light of all creation,
Be our bliss while endless ages sing Your praises.

Refrain:
God is love, and where true love is
God Himself is there.




```

- |   -  |
-------------|------------|
Title | God is Love |
Key |  |
Titles | God is love, and where true love is |
First Line | Here in Christ we gather, love of Christ our calling. |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
