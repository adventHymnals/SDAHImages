---
title: 344. I Love Your Kingdom, Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 344. I Love Your Kingdom, Lord. 1. I love thy kingdom, Lord, the house of thine abode, the church our blest Redeemer saved with his own precious blood.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Love Your Kingdom, Lord, I love thy kingdom, Lord, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 344. I LOVE YOUR KINGDOM, LORD
#### Seventh Day Adventist Hymnal

```txt



1.
I love thy kingdom, Lord,
the house of thine abode,
the church our blest Redeemer saved
with his own precious blood.

2.
I love thy church, O God!
Her walls before thee stand
dear as the apple of thine eye,
and graven on thy hand.

3.
Beyond my highest joy
I prize her heavenly ways,
her sweet communion, solemn vows,
her hymns of love and praise.

4.
Sure as thy truth shall last,
to Zion shall be given
the brightest glories earth can yield,
and brighter bliss of heaven.



```

- |   -  |
-------------|------------|
Title | I Love Your Kingdom, Lord |
Key |  |
Titles | undefined |
First Line | I love thy kingdom, Lord, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
