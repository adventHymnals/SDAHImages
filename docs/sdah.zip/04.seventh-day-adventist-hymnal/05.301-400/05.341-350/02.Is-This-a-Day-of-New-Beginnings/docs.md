---
title: 342. Is This a Day of New Beginnings? - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 342. Is This a Day of New Beginnings?. 1. Is this a day of new beginnings, Time to remember and move on, Time too believe what love is bringing, Laying to rest the pain that’s gone?
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Is This a Day of New Beginnings?, Is this a day of new beginnings, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 342. IS THIS A DAY OF NEW BEGINNINGS?
#### Seventh Day Adventist Hymnal

```txt



1.
Is this a day of new beginnings,
Time to remember and move on,
Time too believe what love is bringing,
Laying to rest the pain that’s gone?

2.
How can the seasons of a planet
Mindlessly spinning round its sun
With just a human name and number
Say that some new thing has begun?

3.
Yet through the life and death of Jesus
Love’s mighty Spirit, now as then,
Can make for us a world of difference
As faith and hope are born again.

4.
Then let us, with the Spirit’s daring,
Step from the past and leave behind
Its disappointment, guilt, and grieving,
Seeking new paths, and sure to find.

5.
Christ is alive, and goes before us
To show and share what love can do.
This is a day of new beginnings;
Our God is making all things new.



```

- |   -  |
-------------|------------|
Title | Is This a Day of New Beginnings? |
Key |  |
Titles | undefined |
First Line | Is this a day of new beginnings, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
