---
title: 345. Christ Is the World`s True Light - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 345. Christ Is the World`s True Light. 1. Christ is the world’s true light, Its captain of salvation, The daystar clear and bright Of every man and nation; New life, new hope awakes Where’er men own His sway: Freedom her bondage breaks, And night is turned to day.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Christ Is the World`s True Light, Christ is the world’s true light, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 345. CHRIST IS THE WORLD`S TRUE LIGHT
#### Seventh Day Adventist Hymnal

```txt



1.
Christ is the world’s true light,
Its captain of salvation,
The daystar clear and bright
Of every man and nation;
New life, new hope awakes
Where’er men own His sway:
Freedom her bondage breaks,
And night is turned to day.

2.
In Christ all races meet,
Their ancient feuds forgeting,
The whole round world complete,
From sunrise to its setting:
When Christ is throned as Lord,
Men shall forsake their fear,
To plowshare beat the sword,
To pruning hook the spear.

3.
One Lord, in one great name
Unite us all who own Thee,
Cast out our pride and shame
That hinder to enthrone Thee;
The world has waited long,
Has travailed long in pain,
To heal its ancient wrong,
Come, Prince of Peace, and reign.



```

- |   -  |
-------------|------------|
Title | Christ Is the World`s True Light |
Key |  |
Titles | undefined |
First Line | Christ is the world’s true light, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
