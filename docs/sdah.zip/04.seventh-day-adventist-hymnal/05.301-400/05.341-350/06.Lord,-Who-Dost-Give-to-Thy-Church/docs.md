---
title: 346. Lord, Who Dost Give to Thy Church - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 346. Lord, Who Dost Give to Thy Church. 1. Lord, who dost give to Thy church for its healing Gifts, and the grace to sustain and renew, Hear as we pray that today and each morrow We to Thy purpose may show ourselves true.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord, Who Dost Give to Thy Church, Lord, who dost give to Thy church for its healing 
    author: Brian Onang'o
---

#### Advent Hymnals
## 346. LORD, WHO DOST GIVE TO THY CHURCH
#### Seventh Day Adventist Hymnal

```txt



1.
Lord, who dost give to Thy church for its healing
Gifts, and the grace to sustain and renew,
Hear as we pray that today and each morrow
We to Thy purpose may show ourselves true.

2.
Clear be the voices of preachers and prophets
Fearlessly speaking the word of the Lord,
Word of redemption thro‘ God’s Son incarnate,
Blessing for cursing, and peace for the sword.

3.
Tender and wise be the hearts of the pastors,
Guiding and guarding the souls in their care,
Firm with the wayward, a strength to the doubting,
Helping the needy their burdens to bear.

4.
May those who teach grow in knowledge and patience,
Guiding to wisdom the young and the old,
Training for worship and witness and service,
Foes to all falsehood, in truthfulness bold.

5.
Lord, ever give to us gifts in due measure,
Each needing other, and all having worth;
So to the Father, the Son, and the Spirit,
Glory be shown by the church here on earth.



```

- |   -  |
-------------|------------|
Title | Lord, Who Dost Give to Thy Church |
Key |  |
Titles | undefined |
First Line | Lord, who dost give to Thy church for its healing |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
