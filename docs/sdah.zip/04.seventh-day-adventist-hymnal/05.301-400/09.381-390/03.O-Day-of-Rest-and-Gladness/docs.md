---
title: 383. O Day of Rest and Gladness
metadata:
    description: 
    keywords: Seventh Day Adventist Hymnal, O Day of Rest and Gladness, , 
    author: Brian Onang'o
---


## 383. O DAY OF REST AND GLADNESS

```txt
1.
O day of rest and gladness,
O day of joy and light,
O balm of care and sadness,
Most beautiful, most bright,
On thee the high and lowly
Before th’ eternal throne
Sing, “Holy, holy, holy,”
To the great Three in One.

2.
Thou art a port protected
From storms that round us rise;
A garden intersected
With streams of paradise;
Thou art a cooling fountain
In life’s dry dreary sand;
From Thee, like Pisgah’s mountain,
We view our promised land.

3.
A day of sweet reflection
Thou art, a day of love,
A day to raise affection
From earth to things above.
New graces ever gaining
From this our day of rest,
We seek the rest remaining
To mansions of the blest.
```

- |   -  |
-------------|------------|
Title | O Day of Rest and Gladness |
Key |  |
Titles |  |
First Line |  |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas | 3 |
Chorus | No |
Chorus Type | - |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
