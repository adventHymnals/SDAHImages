---
title: 386. The Sacred Anthem - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 386. The Sacred Anthem. 1. The sacred anthem slowly rang Across the fields of praise, When earth’s first Sabbath made complete All creatures and all days.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The Sacred Anthem, The sacred anthem slowly rang 
    author: Brian Onang'o
---

#### Advent Hymnals
## 386. THE SACRED ANTHEM
#### Seventh Day Adventist Hymnal

```txt



1.
The sacred anthem slowly rang
Across the fields of praise,
When earth’s first Sabbath made complete
All creatures and all days.

2.
Walking with God, there,
Woman and man together share
The blessed Sabbath mood;
And in that green and golden world
Know all God’s works are good.

3.
But now in our diminished lives
We sing a blemished song;
The earth is worn and disarrayed
And all our work goes wrong.

4.
Still in our worship,
Joining in praise and fellowship,
By Sabbath radiance blessed,
We put our doubt and fear away
And rest within God’s rest.

5.
And arching over time and space
The Lord of Sabbaths wills
Renewal for the weary earth
And healing for our ills.

6.
Hearts will rejoice then;
There will be no more weeping, when
We know and shall be known.
With hosts of the redeemed we’ll sing
Around God’s shining throne.



```

- |   -  |
-------------|------------|
Title | The Sacred Anthem |
Key |  |
Titles | undefined |
First Line | The sacred anthem slowly rang |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
