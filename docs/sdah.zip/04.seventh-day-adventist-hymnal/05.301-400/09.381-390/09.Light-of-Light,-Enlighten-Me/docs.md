---
title: 389. Light of Light, Enlighten Me - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 389. Light of Light, Enlighten Me. 1. Light of light, enlighten me, Now anew the day is dawning; Sun of grace, the shadows flee; Brighten Thou my Sabbath morning; With Thy joyous sunshine blest, Happy is my day of rest.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Light of Light, Enlighten Me, Light of light, enlighten me, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 389. LIGHT OF LIGHT, ENLIGHTEN ME
#### Seventh Day Adventist Hymnal

```txt



1.
Light of light, enlighten me,
Now anew the day is dawning;
Sun of grace, the shadows flee;
Brighten Thou my Sabbath morning;
With Thy joyous sunshine blest,
Happy is my day of rest.

2.
Let me with my heart today,
Holy, holy, holy, singing,
Rapt awhile from earth away,
All my soul to Thee up springing,
Have a foretaste inward given
How they worship Thee in heaven.

3.
Hence all care, all vanity!
For the day to God is holy;
Come, Thou glorious Majesty,
Deign to fill this temple lowly;
Nought today my soul shall move,
Simply resting in Thy love.



```

- |   -  |
-------------|------------|
Title | Light of Light, Enlighten Me |
Key |  |
Titles | undefined |
First Line | Light of light, enlighten me, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
