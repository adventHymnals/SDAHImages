---
title: 384. Safely Through Another Week - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 384. Safely Through Another Week. 1. Safely through another week God has brought us on our way; Let us now a blessing seek, Waiting in His courts today; Day of all the week the best, Emblem of eternal rest: Day of all the week the best, Emblem of eternal rest.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Safely Through Another Week, Safely through another week 
    author: Brian Onang'o
---

#### Advent Hymnals
## 384. SAFELY THROUGH ANOTHER WEEK
#### Seventh Day Adventist Hymnal

```txt



1.
Safely through another week
God has brought us on our way;
Let us now a blessing seek,
Waiting in His courts today;
Day of all the week the best,
Emblem of eternal rest:
Day of all the week the best,
Emblem of eternal rest.

2.
While we seek supplies of grace,
Thro’ the dear Redeemer’s name,
Show Thy reconciling face;
Take away the sin and shame:
From our worldly cares set free,
May we rest this day in Thee:
From our worldly cares set free,
May we rest this day in Thee.

3.
When the more shall bid us rise,
May we feel Thy presence near;
May Thy glory meet our eyes,
While we in Thy house appear:
Here afford us, Lord, a taste
Of our everlasting feast:
Here afford us, Lord, a taste
Of our everlasting feast.

4.
May the gospel’s joyful sound
Conquer sinners, comfort saints;
Make the fruits of grace abound,
Bring relief to all complaints:
Thus may all our Sabbaths be,
Till we we rise to reign with Thee.
Thus may all our Sabbaths be,
Till we we rise to reign with Thee.



```

- |   -  |
-------------|------------|
Title | Safely Through Another Week |
Key |  |
Titles | undefined |
First Line | Safely through another week |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
