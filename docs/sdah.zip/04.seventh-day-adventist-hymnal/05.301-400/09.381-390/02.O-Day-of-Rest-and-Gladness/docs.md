---
title: 382. O Day of Rest and Gladness - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 382. O Day of Rest and Gladness. 1. O day of rest and gladness, O day of joy and light, O balm of care and sadness, most beautiful, most bright; on thee, the high and lowly, who bend before throne, sing, “Holy, holy, holy,” to the Eternal One.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Day of Rest and Gladness, O day of rest and gladness, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 382. O DAY OF REST AND GLADNESS
#### Seventh Day Adventist Hymnal

```txt



1.
O day of rest and gladness,
O day of joy and light,
O balm of care and sadness,
most beautiful, most bright;
on thee, the high and lowly,
who bend before throne,
sing, “Holy, holy, holy,”
to the Eternal One.

2.
Thou art a port protected
from storms that round us rise;
a garden intersected
with streams of paradise;
thou art a cooling fountain
in life’s dry, dreary sand;
from thee, like Pisgah’s mountain,
we view our promised land.

3.
A day of sweet reflection,
thou art a day of love,
A day to raise affection
from earth to things above.
New graces ever gaining
from this our day of rest,
We reach the rest remaining
in mansions of the blessed.



```

- |   -  |
-------------|------------|
Title | O Day of Rest and Gladness |
Key |  |
Titles | undefined |
First Line | O day of rest and gladness, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
