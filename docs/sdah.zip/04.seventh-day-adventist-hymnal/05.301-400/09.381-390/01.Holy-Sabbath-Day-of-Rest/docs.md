---
title: 381. Holy Sabbath Day of Rest - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 381. Holy Sabbath Day of Rest. 1. Holy Sabbath day of rest, By our Master richly blest, God created and divine, Set aside for holy time. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Holy Sabbath Day of Rest, Holy Sabbath day of rest, ,Yes, the holy Sabbath rest,
    author: Brian Onang'o
---

#### Advent Hymnals
## 381. HOLY SABBATH DAY OF REST
#### Seventh Day Adventist Hymnal

```txt



1.
Holy Sabbath day of rest,
By our Master richly blest,
God created and divine,
Set aside for holy time.


Refrain:
Yes, the holy Sabbath rest,
By our God divinely blest,
It to us a sign shall be
Throughout all eternity.


2.
Seek not pleasures of this earth,
With its folly, noise, and mirth,
There are better things in store,
Over on the other shore.


Refrain:
Yes, the holy Sabbath rest,
By our God divinely blest,
It to us a sign shall be
Throughout all eternity.

3.
As the Sabbath draweth on
Friday eve at set of sun,
Christian household then should meet,
Sing and pray at Jesus’feet.


Refrain:
Yes, the holy Sabbath rest,
By our God divinely blest,
It to us a sign shall be
Throughout all eternity.

4.
Asking Him for saving grace,
Also vict’ry in the race,
And to help us by His pow’r,
To keep holy every hour.

Refrain:
Yes, the holy Sabbath rest,
By our God divinely blest,
It to us a sign shall be
Throughout all eternity.




```

- |   -  |
-------------|------------|
Title | Holy Sabbath Day of Rest |
Key |  |
Titles | Yes, the holy Sabbath rest, |
First Line | Holy Sabbath day of rest, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
