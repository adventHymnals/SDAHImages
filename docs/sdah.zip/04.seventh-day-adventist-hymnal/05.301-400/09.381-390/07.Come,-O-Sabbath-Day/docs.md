---
title: 387. Come, O Sabbath Day - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 387. Come, O Sabbath Day. 1. Peace and healing on thy wing; And to every troubled breast Speak of the divine behest: Thou shalt rest, Thou shalt rest!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Come, O Sabbath Day, Peace and healing on thy wing; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 387. COME, O SABBATH DAY
#### Seventh Day Adventist Hymnal

```txt



1.
Peace and healing on thy wing;
And to every troubled breast
Speak of the divine behest:
Thou shalt rest, Thou shalt rest!

2.
Earthly longings bid retire,
Quench the passions’ hurtful fire;
To the wayward, sin oppressed,
Bring thou thy divine behest:
Thou shalt rest, Thou shalt rest!

3.
Wipe from every cheek the tear,
Banish care and silence fear;
All things working for the best,
Teach us the divine behest:
Thou shalt rest, Thou shalt rest!



```

- |   -  |
-------------|------------|
Title | Come, O Sabbath Day |
Key |  |
Titles | undefined |
First Line | Peace and healing on thy wing; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
