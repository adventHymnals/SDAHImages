---
title: 390. We Love Thy Sabbath, Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 390. We Love Thy Sabbath, Lord. 1. We love Thy Sabbath, Lord, And worship at Thy will; Oh may these hours sweet peace afford And deeper faith instill.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, We Love Thy Sabbath, Lord, We love Thy Sabbath, Lord, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 390. WE LOVE THY SABBATH, LORD
#### Seventh Day Adventist Hymnal

```txt



1.
We love Thy Sabbath, Lord,
And worship at Thy will;
Oh may these hours sweet peace afford
And deeper faith instill.

2.
Thine angels sang for joy
Cration’s work to see;
We too, this day, would raise our hearts
In grateful praise to Thee.

3.
Praise for Thy wondrous love,
That sealed this sacred day,
A sign that all may understand
We own Thy sovereign sway.

4.
O great Creator King,
Through Thy redeeming grace,
Renew and sanctify our hearts
That we may see Thy face.

5.
And with the white-robed throng,
Upon Mount Sion be,
And joyful sing our Sabbath song
Through all eternity.



```

- |   -  |
-------------|------------|
Title | We Love Thy Sabbath, Lord |
Key |  |
Titles | undefined |
First Line | We love Thy Sabbath, Lord, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
