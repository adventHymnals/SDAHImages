---
title: Seventh Day Adventist Hymnal - 381-390
metadata:
    description: |
      Seventh Day Adventist Hymnal - 381-390
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 381-390
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 381-390

# Index of Titles
# | Title                        
-- |-------------
381|[Holy Sabbath Day of Rest](/seventh-day-adventist-hymnal/301-400/381-390/Holy-Sabbath-Day-of-Rest)
382|[O Day of Rest and Gladness](/seventh-day-adventist-hymnal/301-400/381-390/O-Day-of-Rest-and-Gladness)
383|[O Day of Rest and Gladness](/seventh-day-adventist-hymnal/301-400/381-390/O-Day-of-Rest-and-Gladness_1)
384|[Safely Through Another Week](/seventh-day-adventist-hymnal/301-400/381-390/Safely-Through-Another-Week)
385|[Crowning Jewel of Creation](/seventh-day-adventist-hymnal/301-400/381-390/Crowning-Jewel-of-Creation)
386|[The Sacred Anthem](/seventh-day-adventist-hymnal/301-400/381-390/The-Sacred-Anthem)
387|[Come, O Sabbath Day](/seventh-day-adventist-hymnal/301-400/381-390/Come,-O-Sabbath-Day)
388|[Don\`t Forget the Sabbath](/seventh-day-adventist-hymnal/301-400/381-390/Don`t-Forget-the-Sabbath)
389|[Light of Light, Enlighten Me](/seventh-day-adventist-hymnal/301-400/381-390/Light-of-Light,-Enlighten-Me)
390|[We Love Thy Sabbath, Lord](/seventh-day-adventist-hymnal/301-400/381-390/We-Love-Thy-Sabbath,-Lord)