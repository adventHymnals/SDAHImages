---
title: 385. Crowning Jewel of Creation - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 385. Crowning Jewel of Creation. 1. Crowning jewel of creation, Blest and hallowed, sanctified; Time and changes all transcending, Shared forever, glorified. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Crowning Jewel of Creation, Crowning jewel of creation, ,Blessed Sabbath made for man,
    author: Brian Onang'o
---

#### Advent Hymnals
## 385. CROWNING JEWEL OF CREATION
#### Seventh Day Adventist Hymnal

```txt



1.
Crowning jewel of creation,
Blest and hallowed, sanctified;
Time and changes all transcending,
Shared forever, glorified.


Refrain:
Blessed Sabbath made for man,
Gift from the Creator’s hand.


2.
Sin and sickness, prayer and weeping
Cease at close of earthly days;
But Thy Sabbath is eternal,
Joyful thanks to Thee we raise!


Refrain:
Blessed Sabbath made for man,
Gift from the Creator’s hand.

3.
Teach us Lord, in storm or sunshine
How to truly rest in Thee,
May Thy Sabbath peace enfold us
And our shelter ever be.

Refrain:
Blessed Sabbath made for man,
Gift from the Creator’s hand.




```

- |   -  |
-------------|------------|
Title | Crowning Jewel of Creation |
Key |  |
Titles | Blessed Sabbath made for man, |
First Line | Crowning jewel of creation, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
