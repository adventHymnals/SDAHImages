---
title: 388. Don`t Forget the Sabbath - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 388. Don`t Forget the Sabbath. 1. Don’t forget the Sabbath, The Lord our God hath blest, Of all the week the brightest, Of all the week the best; It brings repose from labor, It tells of joy divine, Its beams of light descending, With heavenly beauty shine. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Don`t Forget the Sabbath, Don’t forget the Sabbath, ,Welcome, welcome, ever welcome,
    author: Brian Onang'o
---

#### Advent Hymnals
## 388. DON`T FORGET THE SABBATH
#### Seventh Day Adventist Hymnal

```txt



1.
Don’t forget the Sabbath,
The Lord our God hath blest,
Of all the week the brightest,
Of all the week the best;
It brings repose from labor,
It tells of joy divine,
Its beams of light descending,
With heavenly beauty shine.


Refrain:
Welcome, welcome, ever welcome,
Blessed Sabbath day,
Welcome, welcome, ever welcome,
Blessed Sabbath day.


2.
Keep the Sabbath holy,
And worship Him today,
Who said to His disciples,
“I am the living way;”
And if we meekly follow
Our Savior here below,
He’ll give us of the fountain
Whose streams eternal flow.


Refrain:
Welcome, welcome, ever welcome,
Blessed Sabbath day,
Welcome, welcome, ever welcome,
Blessed Sabbath day.

3.
Day of sacred pleasure!
Its golden hours we’ll spend
In thankful hymns to Jesus,
The children’s dearest Friend;
O gentle loving, Savior,
How good and kind Thou art,
How precious is Thy promise
To dwell in every heart!

Refrain:
Welcome, welcome, ever welcome,
Blessed Sabbath day,
Welcome, welcome, ever welcome,
Blessed Sabbath day.




```

- |   -  |
-------------|------------|
Title | Don`t Forget the Sabbath |
Key |  |
Titles | Welcome, welcome, ever welcome, |
First Line | Don’t forget the Sabbath, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
