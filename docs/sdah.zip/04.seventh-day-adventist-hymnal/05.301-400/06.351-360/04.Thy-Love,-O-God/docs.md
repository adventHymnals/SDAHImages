---
title: 354. Thy Love, O God - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 354. Thy Love, O God. 1. Thy love, O God, has all mankind created, And led Thy people to this present hour; In Christ we see life’s glory consummated; Thy Spirit manifests His living power.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Thy Love, O God, Thy love, O God, has all mankind created, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 354. THY LOVE, O GOD
#### Seventh Day Adventist Hymnal

```txt



1.
Thy love, O God, has all mankind created,
And led Thy people to this present hour;
In Christ we see life’s glory consummated;
Thy Spirit manifests His living power.

2.
From out the darkness of our hope’s frustration,
From all the broken idols of our pride,
We turn to seek Thy truth’s illumination,
And find Thy mercy waiting at our side.

3.
In pity look upon Thy children’s striving
For life and freedom, peace and brotherhood,
Till at the fullness of Thy truth arriving,
We find in Christ the crown of every good.

4.
Inspire Thy church, mid earth’s discordant voices,
To preach the gospel of her Lord above,
Until the day this warring world rejoices
To hear the mighty harmonies of love.



```

- |   -  |
-------------|------------|
Title | Thy Love, O God |
Key |  |
Titles | undefined |
First Line | Thy love, O God, has all mankind created, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
