---
title: 352. This Is My Will - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 352. This Is My Will. 1. This is My will, My one command, That love should dwell among you all. This is My will that you should love As I have shown that I love you.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, This Is My Will, This is My will, My one command, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 352. THIS IS MY WILL
#### Seventh Day Adventist Hymnal

```txt



1.
This is My will, My one command,
That love should dwell among you all.
This is My will that you should love
As I have shown that I love you.

2.
No greater love a man can have
Than that he die to save his friends.
You are My friends if you obey
What I command that you should do.

3.
You chose not Me, but I chose you
That you should go and bear much fruit.
I chose you out that you in Me
Should bear much fruit that will abide.

4.
All that I ask My Father, dear,
For My name’s sake you shall receive.
This is My will, My one command,
That love should dwell in each, in all.



```

- |   -  |
-------------|------------|
Title | This Is My Will |
Key |  |
Titles | undefined |
First Line | This is My will, My one command, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
