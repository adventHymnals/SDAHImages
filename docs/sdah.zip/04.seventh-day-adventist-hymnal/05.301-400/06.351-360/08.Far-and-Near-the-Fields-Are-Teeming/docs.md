---
title: 358. Far and Near the Fields Are Teeming - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 358. Far and Near the Fields Are Teeming. 1. Far and near the fields are teeming with the sheaves of ripened grain; Far and near their gold is gleaming O’er the summy slope and plain. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Far and Near the Fields Are Teeming, Far and near the fields are teeming ,Lord of harvest, send forth reapers!
    author: Brian Onang'o
---

#### Advent Hymnals
## 358. FAR AND NEAR THE FIELDS ARE TEEMING
#### Seventh Day Adventist Hymnal

```txt



1.
Far and near the fields are teeming
with the sheaves of ripened grain;
Far and near their gold is gleaming
O’er the summy slope and plain.


Refrain:
Lord of harvest, send forth reapers!
Hear us Lord,to Thee we cry;
Send them now the sheaves to gather,
Ere the harvest-time pass by.


2.
Send them forth with morn’s first beaming,
Send them in the noon-tides’s glare;
When the sun’s last rays are streaming,
bid them gather everywhere.


Refrain:
Lord of harvest, send forth reapers!
Hear us Lord,to Thee we cry;
Send them now the sheaves to gather,
Ere the harvest-time pass by.

3.
O thou, whom thy Lord is sending,
gather now the sheaves of gold;
Heavenward then at evening wending
Thou shalt come with joy untold.

Refrain:
Lord of harvest, send forth reapers!
Hear us Lord,to Thee we cry;
Send them now the sheaves to gather,
Ere the harvest-time pass by.




```

- |   -  |
-------------|------------|
Title | Far and Near the Fields Are Teeming |
Key |  |
Titles | Lord of harvest, send forth reapers! |
First Line | Far and near the fields are teeming |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
