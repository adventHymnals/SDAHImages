---
title: 355. Where Cross the Crowded Ways of Life - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 355. Where Cross the Crowded Ways of Life. 1. Where cross the crowded ways of life, where sound the cries of race and clan, above the noise of selfish strife, we hear your voice, O Son of Man.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Where Cross the Crowded Ways of Life, Where cross the crowded ways of life, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 355. WHERE CROSS THE CROWDED WAYS OF LIFE
#### Seventh Day Adventist Hymnal

```txt



1.
Where cross the crowded ways of life,
where sound the cries of race and clan,
above the noise of selfish strife,
we hear your voice, O Son of Man.

2.
From tender childhood’s helplessness,
from woman’s grief, man’s burdened toil,
from famished souls, from sorrow’s stress,
your heart has never known recoil.

3.
The cup of water given for you still
holds the freshness of your grace;
yet long these multitudes to view
the sweet compassion of your face.

4.
O Master, from the mountainside
make haste to heal these hearts of pain;
among these restless throngs abide;
O tread the city’s streets again.

5.
Till all the world shall learn your love
and follow where your feet have trod,
till, glorious from your heaven above,
shall come the city of our God.



```

- |   -  |
-------------|------------|
Title | Where Cross the Crowded Ways of Life |
Key |  |
Titles | undefined |
First Line | Where cross the crowded ways of life, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
