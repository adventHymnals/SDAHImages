---
title: 357. Come, Labor On - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 357. Come, Labor On. 1. Come, labor on. Who dares stand idle on the harvest plain While all around him waves the golden grain? And to each servant does the Master say, “Go work today.”
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Come, Labor On, Come, labor on. 
    author: Brian Onang'o
---

#### Advent Hymnals
## 357. COME, LABOR ON
#### Seventh Day Adventist Hymnal

```txt



1.
Come, labor on.
Who dares stand idle on the harvest plain
While all around him waves the golden grain?
And to each servant does the Master say,
“Go work today.”

2.
Come, labor on.
Claim the high calling angels cannot share;
To young and old the gospel gladness bear;
Redeem the time; its hours too swiftly fly.
The night draws nigh.

3.
Come, labor on.
No time for rest; till glows the western sky,
Till the long shadows oér our pathway lie,
And a glad sound comes with the setting sun,
“Well done, well done!”



```

- |   -  |
-------------|------------|
Title | Come, Labor On |
Key |  |
Titles | undefined |
First Line | Come, labor on. |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
