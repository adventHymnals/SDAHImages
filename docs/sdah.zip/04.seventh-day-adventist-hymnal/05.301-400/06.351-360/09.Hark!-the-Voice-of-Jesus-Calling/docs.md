---
title: 359. Hark! the Voice of Jesus Calling - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 359. Hark! the Voice of Jesus Calling. 1. Hark! the voice of Jesus calling, “Who will go and work today? Fields are white, the harvest waiting, Who will bear the sheaves away?” Loud and long the Master calleth, Rich reward He offers free; Who will answer, gladly saying, “Here am I, O Lord, send me”?
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Hark! the Voice of Jesus Calling, Hark! the voice of Jesus calling, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 359. HARK! THE VOICE OF JESUS CALLING
#### Seventh Day Adventist Hymnal

```txt



1.
Hark! the voice of Jesus calling,
“Who will go and work today?
Fields are white, the harvest waiting,
Who will bear the sheaves away?”
Loud and long the Master calleth,
Rich reward He offers free;
Who will answer, gladly saying,
“Here am I, O Lord, send me”?

2.
If you cannot cross the ocean
And the heathen lands explore,
You can find the heathen nearer,
You can help them at your door;
If you cannot speak like angels,
If you cannot preach like Paul,
You can tell the love of Jesus,
You can say He died for all.

3.
If you cannot be the watchman,
Standing high on Zion’s wall,
Pointing out the path to heaven,
Offering life and peace to all;
With your prayers and with your bounties
You can do what Heaven demands,
You can be like faithful Aaron,
Holding up the prophet’s hands.

4.
While the souls of men are dying,
And the Master calls for you,
Let none hear you idly saying,
“There is nothing I can do!”
Gladly take the task He gives you,
Let His work your pleasure be;
Answer quickly when He calleth,
“Here am I, O Lord, send me.”



```

- |   -  |
-------------|------------|
Title | Hark! the Voice of Jesus Calling |
Key |  |
Titles | undefined |
First Line | Hark! the voice of Jesus calling, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
