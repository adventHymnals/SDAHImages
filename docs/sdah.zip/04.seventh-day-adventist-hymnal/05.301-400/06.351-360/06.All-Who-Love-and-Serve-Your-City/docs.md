---
title: 356. All Who Love and Serve Your City - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 356. All Who Love and Serve Your City. 1. All who love and serve your city, All who bear its daily stress, All who cry for peace and justice, All who curse and all who bless.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, All Who Love and Serve Your City, All who love and serve your city, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 356. ALL WHO LOVE AND SERVE YOUR CITY
#### Seventh Day Adventist Hymnal

```txt



1.
All who love and serve your city,
All who bear its daily stress,
All who cry for peace and justice,
All who curse and all who bless.

2.
In your day of loss and sorrow,
In your day of helpless strife,
Honor, peace, and love retreating,
Seek the Lord, who is your life.

3.
For all days are days of judgment,
And the Lord is waiting still,
Drawing near His friends who spurn Him,
Off’ring peace from Calv’ry’s hill.

4.
Risen Lord, shall yet the city
Be the city of despair?
Come today, our judge, our glory;
Be its name “The Lord is there!”



```

- |   -  |
-------------|------------|
Title | All Who Love and Serve Your City |
Key |  |
Titles | undefined |
First Line | All who love and serve your city, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
