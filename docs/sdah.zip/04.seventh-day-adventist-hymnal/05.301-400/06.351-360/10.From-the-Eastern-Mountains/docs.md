---
title: 360. From the Eastern Mountains - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 360. From the Eastern Mountains. 1. From the eastern mountains Pressing on they come, Wise men in their wisdom, To His humble home; Stirred by deep devotion, Hasting from afar, Ever journeying onward, Guided by a star.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, From the Eastern Mountains, From the eastern mountains Pressing on they come, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 360. FROM THE EASTERN MOUNTAINS
#### Seventh Day Adventist Hymnal

```txt



1.
From the eastern mountains Pressing on they come,
Wise men in their wisdom, To His humble home;
Stirred by deep devotion, Hasting from afar,
Ever journeying onward, Guided by a star.

2.
There their Lord and Savior Meek and lowly,
Wondrous light that led them Onward on their way,
Ever now to lighten Nations from afar,
As they journey homeward By that guiding star.

3.
Gather in the outcasts All who’ve gone astray,
Throw Thy radiance o’er them, Guide them on their way;
Those who never knew Thee, Those who’ve wandered far,
Guide them by the brightness Of Thy guiding star.

4.
Until every nation, Whether bond or free,
‘Neath Thy starlit banner, Jesus follows thee.
O’er the distant mountains To that heavenly home,
Where no sin nor sorrow Evermore shall come.



```

- |   -  |
-------------|------------|
Title | From the Eastern Mountains |
Key |  |
Titles | undefined |
First Line | From the eastern mountains Pressing on they come, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
