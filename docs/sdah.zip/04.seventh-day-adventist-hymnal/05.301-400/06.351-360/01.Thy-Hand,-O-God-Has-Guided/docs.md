---
title: 351. Thy Hand, O God Has Guided - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 351. Thy Hand, O God Has Guided. 1. Thy hand, O God, has guided Thy flock from age to age; The wondrous tale is written Full clear on every page; Our fathers owned Thy goodness, And we their deeds record; And both of this bear witness, One church, one faith, one Lord.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Thy Hand, O God Has Guided, Thy hand, O God, has guided 
    author: Brian Onang'o
---

#### Advent Hymnals
## 351. THY HAND, O GOD HAS GUIDED
#### Seventh Day Adventist Hymnal

```txt



1.
Thy hand, O God, has guided
Thy flock from age to age;
The wondrous tale is written
Full clear on every page;
Our fathers owned Thy goodness,
And we their deeds record;
And both of this bear witness,
One church, one faith, one Lord.

2.
Thy heralds brought glad tidings
To greatest as to least;
They bade men rise and hasten
To share the great King’s feast:
And this was all their teaching,
In every deed and word,
To all alike proclaiming
One church, one faith, one Lord.

3.
When shadows thick were falling,
And all seemed sunk in night,
Thou, Lord, did send Thy servants,
Thy chosen sons of light.
On them and on Thy people
Thy plenteous grace was poured,
And this was still their message:
One church, one faith, one Lord.

4.
Thy mercy will not fail us,
Nor leave Thy work undone;
With Thy right hand to help us,
The vict’ry shall be won;
And then by men and angels
Thy name shall be adored,
And this shall be their anthem:
One church, one faith, one Lord.



```

- |   -  |
-------------|------------|
Title | Thy Hand, O God Has Guided |
Key |  |
Titles | undefined |
First Line | Thy hand, O God, has guided |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
