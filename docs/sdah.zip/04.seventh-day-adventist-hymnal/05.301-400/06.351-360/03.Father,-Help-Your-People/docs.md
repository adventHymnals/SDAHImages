---
title: 353. Father, Help Your People - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 353. Father, Help Your People. 1. Father, help Your people in this world to build Something of Your kingdom and to do Your will, Lead us to discover partnership in love; Bless our ways of sharing and our pride remove.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Father, Help Your People, Father, help Your people in this world to build 
    author: Brian Onang'o
---

#### Advent Hymnals
## 353. FATHER, HELP YOUR PEOPLE
#### Seventh Day Adventist Hymnal

```txt



1.
Father, help Your people in this world to build
Something of Your kingdom and to do Your will,
Lead us to discover partnership in love;
Bless our ways of sharing and our pride remove.

2.
Lord of desk and altar, bind our lives in one,
That in work and worship love may set the tone.
Give us grace to listen, clarity of speech;
Make us truly thankful for the gifts of each.

3.
Holy is the setting of each room and yard,
Lecture hall and kitchen, office, shop, and ward.
Holy is the rhythm of our working hours;
Hallow then our purpose, energy, and pow’rs.

4.
Strengthen, Lord, for service hand and heart and brain;
Help us good relations daily to maintain.
Let the living presence of the servant Christ
Heighten our devotion, make our life a feast.



```

- |   -  |
-------------|------------|
Title | Father, Help Your People |
Key |  |
Titles | undefined |
First Line | Father, help Your people in this world to build |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
