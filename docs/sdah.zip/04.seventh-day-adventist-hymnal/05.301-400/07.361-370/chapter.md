---
title: Seventh Day Adventist Hymnal - 361-370
metadata:
    description: |
      Seventh Day Adventist Hymnal - 361-370
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 361-370
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 361-370

# Index of Titles
# | Title                        
-- |-------------
361|[Hark! \`Tis the Shepherd\`s Voice I Hear](/seventh-day-adventist-hymnal/301-400/361-370/Hark!-`Tis-the-Shepherd`s-Voice-I-Hear)
362|[Lift High the Cross](/seventh-day-adventist-hymnal/301-400/361-370/Lift-High-the-Cross)
363|[Lord, Whose Love in Humble Service](/seventh-day-adventist-hymnal/301-400/361-370/Lord,-Whose-Love-in-Humble-Service)
364|[O Jesus Christ, to You](/seventh-day-adventist-hymnal/301-400/361-370/O-Jesus-Christ,-to-You)
365|[O Zion, Haste](/seventh-day-adventist-hymnal/301-400/361-370/O-Zion,-Haste)
366|[O Where Are the Reapers?](/seventh-day-adventist-hymnal/301-400/361-370/O-Where-Are-the-Reapers?)
367|[Rescue the Perishing](/seventh-day-adventist-hymnal/301-400/361-370/Rescue-the-Perishing)
368|[Watchman, Blow the Gospel Trumpet](/seventh-day-adventist-hymnal/301-400/361-370/Watchman,-Blow-the-Gospel-Trumpet)
369|[Bringing in the Sheaves](/seventh-day-adventist-hymnal/301-400/361-370/Bringing-in-the-Sheaves)
370|[Christ for the World](/seventh-day-adventist-hymnal/301-400/361-370/Christ-for-the-World)