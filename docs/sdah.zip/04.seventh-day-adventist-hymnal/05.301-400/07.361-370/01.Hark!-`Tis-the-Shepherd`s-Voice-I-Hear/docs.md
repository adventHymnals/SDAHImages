---
title: 361. Hark! `Tis the Shepherd`s Voice I Hear - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 361. Hark! `Tis the Shepherd`s Voice I Hear. 1. Hark! ’tis the Shepherd’s voice I hear, Out in the desert dark and drear, Calling the sheep who’ve gone astray, Far from the Shepherd’s fold away. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Hark! `Tis the Shepherd`s Voice I Hear, Hark! ’tis the Shepherd’s voice I hear, ,Bring them in, Bring them in,
    author: Brian Onang'o
---

#### Advent Hymnals
## 361. HARK! `TIS THE SHEPHERD`S VOICE I HEAR
#### Seventh Day Adventist Hymnal

```txt



1.
Hark! ’tis the Shepherd’s voice I hear,
Out in the desert dark and drear,
Calling the sheep who’ve gone astray,
Far from the Shepherd’s fold away.


Refrain:
Bring them in, Bring them in,
Bring them in from the fields of sin;
Bring them in, Bring them in,
Bring the wanderers to Jesus.


2.
Who’ll go and help the Shepherd kind,
Help Him the wandering ones to find?
Who’ll bring them back into the fold,
Where they’ll be sheltered from the cold?


Refrain:
Bring them in, Bring them in,
Bring them in from the fields of sin;
Bring them in, Bring them in,
Bring the wanderers to Jesus.

3.
Out in the desert hear their cry,
Out on the mountain wild and high,
Hark! ’tis the Master speaks to thee,
“Go, find My sheep where ‘er they be.”

Refrain:
Bring them in, Bring them in,
Bring them in from the fields of sin;
Bring them in, Bring them in,
Bring the wanderers to Jesus.




```

- |   -  |
-------------|------------|
Title | Hark! `Tis the Shepherd`s Voice I Hear |
Key |  |
Titles | Bring them in, Bring them in, |
First Line | Hark! ’tis the Shepherd’s voice I hear, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
