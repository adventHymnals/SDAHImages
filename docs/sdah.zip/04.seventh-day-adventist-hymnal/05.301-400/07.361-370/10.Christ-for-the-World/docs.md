---
title: 370. Christ for the World - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 370. Christ for the World. 1. Christ for the world we sing, the world to Christ we bring, with loving zeal; the poor, and them that mourn, the faint and overborne, sinsick and sorrow-worn, whom Christ doth heal.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Christ for the World, Christ for the world we sing, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 370. CHRIST FOR THE WORLD
#### Seventh Day Adventist Hymnal

```txt



1.
Christ for the world we sing,
the world to Christ we bring,
with loving zeal;
the poor, and them that mourn,
the faint and overborne,
sinsick and sorrow-worn,
whom Christ doth heal.

2.
Christ for the world we sing,
the world to Christ we bring,
with fervent prayer;
the wayward and the lost,
by restless passions tossed,
redeemed at countless cost,
from dark despair.

3.
Christ for the world we sing,
the world to Christ we bring,
with joyful song;
the newborn souls, whose days,
reclaimed from error’s ways,
inspired with hope and praise,
to Christ belong.



```

- |   -  |
-------------|------------|
Title | Christ for the World |
Key |  |
Titles | undefined |
First Line | Christ for the world we sing, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
