---
title: 362. Lift High the Cross - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 362. Lift High the Cross. 1. Come, Christians, follow where our Captain trod, Our King victorious, Christ, the Son of God.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lift High the Cross, Come, Christians, follow where our Captain trod, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 362. LIFT HIGH THE CROSS
#### Seventh Day Adventist Hymnal

```txt



1.
Come, Christians, follow where our Captain trod,
Our King victorious, Christ, the Son of God.

2.
Led on their way by this triumphant sign,
The hosts of God in conquering ranks combine.

3.
All newborn soldiers of the Crucified
Bear on their brows the seal of Him Who died.

4.
O Lord, once lifted on the glorious tree,
As Thou hast promised, draw us all to Thee.

5.
So shall our song of triumph ever be:
Praise to the Crucified for victory!



```

- |   -  |
-------------|------------|
Title | Lift High the Cross |
Key |  |
Titles | undefined |
First Line | Come, Christians, follow where our Captain trod, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
