---
title: 368. Watchman, Blow the Gospel Trumpet - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 368. Watchman, Blow the Gospel Trumpet. 1. Watchman, blow the gospel trumpet, Every soul a warning give; Whosoever hears the message May repent, and, turn and live. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Watchman, Blow the Gospel Trumpet, Watchman, blow the gospel trumpet, ,Blow the trumpet, trusty watchman,
    author: Brian Onang'o
---

#### Advent Hymnals
## 368. WATCHMAN, BLOW THE GOSPEL TRUMPET
#### Seventh Day Adventist Hymnal

```txt



1.
Watchman, blow the gospel trumpet,
Every soul a warning give;
Whosoever hears the message
May repent, and, turn and live.


Refrain:
Blow the trumpet, trusty watchman,
Blow it loud o’er land and sea;
God commissions, sound the message!
Every captive may be free.


2.
Sound it loud oér every hilltop,
Gloomy shade and sunny plain;
Ocean depths repeat the message,
Full salvation’s glad refrain.


Refrain:
Blow the trumpet, trusty watchman,
Blow it loud o’er land and sea;
God commissions, sound the message!
Every captive may be free.

3.
Sound it in the hedge and highway,
Earth’s dark spots where exiles roam;
Let it tell all things are ready,
Father waits to welcome home.


Refrain:
Blow the trumpet, trusty watchman,
Blow it loud o’er land and sea;
God commissions, sound the message!
Every captive may be free.

4.
Sound it for the heavy laden,
Weary, longing to be free;
Sound a Savior’s invitation,
Sweetly saying, “Come to me.”

Refrain:
Blow the trumpet, trusty watchman,
Blow it loud o’er land and sea;
God commissions, sound the message!
Every captive may be free.




```

- |   -  |
-------------|------------|
Title | Watchman, Blow the Gospel Trumpet |
Key |  |
Titles | Blow the trumpet, trusty watchman, |
First Line | Watchman, blow the gospel trumpet, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
