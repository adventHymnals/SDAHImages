---
title: 369. Bringing in the Sheaves - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 369. Bringing in the Sheaves. 1. Sowing in the morning, sowing seeds of kindness, Sowing in the noontide and the dewy eve, Waiting for the harvest and the time of reaping – We shall come rejoicing, bringing in the sheaves. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Bringing in the Sheaves, Sowing in the morning, sowing seeds of kindness, ,Bringing in the sheaves, bringing in the sheaves,
    author: Brian Onang'o
---

#### Advent Hymnals
## 369. BRINGING IN THE SHEAVES
#### Seventh Day Adventist Hymnal

```txt



1.
Sowing in the morning, sowing seeds of kindness,
Sowing in the noontide and the dewy eve,
Waiting for the harvest and the time of reaping –
We shall come rejoicing, bringing in the sheaves.


Refrain:
Bringing in the sheaves, bringing in the sheaves,
We shall come rejoicing, bringing in the sheaves.
Bringing in the sheaves, bringing in the sheaves,
We shall come rejoicing, bringing in the sheaves.


2.
Sowing in the sunshine, sowing in the shadows,
Fearing neither clouds nor winter’s chilling breeze;
By and by the harvest and the labor ended –
We shall come rejoicing, bringin in the sheaves.


Refrain:
Bringing in the sheaves, bringing in the sheaves,
We shall come rejoicing, bringing in the sheaves.
Bringing in the sheaves, bringing in the sheaves,
We shall come rejoicing, bringing in the sheaves.

3.
Going forth with weeping, sowing for the Master,
Tho the loss sustained our spirit often grieves;
When our weeping’s over He will bid us welcome –
We shall come rejoicing, bringing in the sheaves

Refrain:
Bringing in the sheaves, bringing in the sheaves,
We shall come rejoicing, bringing in the sheaves.
Bringing in the sheaves, bringing in the sheaves,
We shall come rejoicing, bringing in the sheaves.




```

- |   -  |
-------------|------------|
Title | Bringing in the Sheaves |
Key |  |
Titles | Bringing in the sheaves, bringing in the sheaves, |
First Line | Sowing in the morning, sowing seeds of kindness, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
