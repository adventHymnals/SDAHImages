---
title: 363. Lord, Whose Love in Humble Service - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 363. Lord, Whose Love in Humble Service. 1. Lord, whose love in humble service Bore the weight of human need, Who upon the cross, forsaken, Worked Your mercy’s perfect deed: We, Your servants, bring the worship Not of voice alone, but heart; Consecrating to Your purpose Every gift which You impart.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord, Whose Love in Humble Service, Lord, whose love in humble service 
    author: Brian Onang'o
---

#### Advent Hymnals
## 363. LORD, WHOSE LOVE IN HUMBLE SERVICE
#### Seventh Day Adventist Hymnal

```txt



1.
Lord, whose love in humble service
Bore the weight of human need,
Who upon the cross, forsaken,
Worked Your mercy’s perfect deed:
We, Your servants, bring the worship
Not of voice alone, but heart;
Consecrating to Your purpose
Every gift which You impart.

2.
Still Your children wander homeless;
Still the hungry cry for bread;
Still the captives long for freedom;
Still in grief we mourn our dead.
As you, Lord, in deep compassion
Healed the sick and freed the soul,
By Your Spirit send Your power
To our world to make it whole.

3.
As we worship, grant us vision,
Till your love’s revealing light
In its height and depth and greatness
Dawns upon our quickened sight,
Making known the needs and burdens
Your compassion bids us bear,
Stirring us to ardent service,
Your abundant life to share.



```

- |   -  |
-------------|------------|
Title | Lord, Whose Love in Humble Service |
Key |  |
Titles | undefined |
First Line | Lord, whose love in humble service |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
