---
title: 366. O Where Are the Reapers? - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 366. O Where Are the Reapers?. 1. O where are the reapers that garner in The sheaves of the good from the fields of sin? With sickles of truth must the work be done, And no one may rest till the “harvest home.” 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Where Are the Reapers?, O where are the reapers that garner in ,Where are the reapers? O who will come
    author: Brian Onang'o
---

#### Advent Hymnals
## 366. O WHERE ARE THE REAPERS?
#### Seventh Day Adventist Hymnal

```txt



1.
O where are the reapers that garner in
The sheaves of the good from the fields of sin?
With sickles of truth must the work be done,
And no one may rest till the “harvest home.”


Refrain:
Where are the reapers? O who will come
And share in the glory of the “harvest home”?
O who will help us to garner in
The sheaves of good from the fields of sin?


2.
The fields all are ripening, and far and wide
The world now is waiting the harvest tide:
But reapers are few, and the work is great,
And much will be lost should the harvest wait.


Refrain:
Where are the reapers? O who will come
And share in the glory of the “harvest home”?
O who will help us to garner in
The sheaves of good from the fields of sin?

3.
So come with your sickles, ye sons of men,
And gather together the golden grain;
Toil on till the Lord of the harvest come,
Then share ye His joy in the “harvest home.”

Refrain:
Where are the reapers? O who will come
And share in the glory of the “harvest home”?
O who will help us to garner in
The sheaves of good from the fields of sin?




```

- |   -  |
-------------|------------|
Title | O Where Are the Reapers? |
Key |  |
Titles | Where are the reapers? O who will come |
First Line | O where are the reapers that garner in |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
