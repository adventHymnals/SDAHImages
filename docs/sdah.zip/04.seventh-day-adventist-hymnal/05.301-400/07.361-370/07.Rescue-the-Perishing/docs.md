---
title: 367. Rescue the Perishing - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 367. Rescue the Perishing. 1. Rescue the perishing, care for the dying, snatch them in pity from sin and the grave; weep o’er the erring one, lift up the fallen, tell them of Jesus, the mighty to save. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Rescue the Perishing, Rescue the perishing, care for the dying, ,Rescue the perishing, care for the dying;
    author: Brian Onang'o
---

#### Advent Hymnals
## 367. RESCUE THE PERISHING
#### Seventh Day Adventist Hymnal

```txt



1.
Rescue the perishing, care for the dying,
snatch them in pity from sin and the grave;
weep o’er the erring one, lift up the fallen,
tell them of Jesus, the mighty to save.


Refrain:
Rescue the perishing, care for the dying;
Jesus is merciful, Jesus will save.


2.
Though they are slighting him, still he is waiting,
waiting the penitent child to receive;
plead with them earnestly, plead with them gently;
he will forgive if they only believe.


Refrain:
Rescue the perishing, care for the dying;
Jesus is merciful, Jesus will save.

3.
Rescue the perishing, duty demands it;
strength for thy labor the Lord will provide;
back to the narrow way patiently win them;
tell the poor wanderer a Savior has died.

Refrain:
Rescue the perishing, care for the dying;
Jesus is merciful, Jesus will save.




```

- |   -  |
-------------|------------|
Title | Rescue the Perishing |
Key |  |
Titles | Rescue the perishing, care for the dying; |
First Line | Rescue the perishing, care for the dying, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
