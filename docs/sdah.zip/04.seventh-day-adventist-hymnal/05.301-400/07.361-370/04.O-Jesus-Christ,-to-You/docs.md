---
title: 364. O Jesus Christ, to You - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 364. O Jesus Christ, to You. 1. O Jesus Christ, to You may hymns be rising In every city for Your love and care; Inspire our worship, grant the glad surprising That Your blest Spirit brings men everywhere.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Jesus Christ, to You, O Jesus Christ, to You may hymns be rising 
    author: Brian Onang'o
---

#### Advent Hymnals
## 364. O JESUS CHRIST, TO YOU
#### Seventh Day Adventist Hymnal

```txt



1.
O Jesus Christ, to You may hymns be rising
In every city for Your love and care;
Inspire our worship, grant the glad surprising
That Your blest Spirit brings men everywhere.

2.
Grant us new courage sacrificial humble
Strong in Your strength to venture and to dare,
To lift the fallen, guide the feet that stumble,
Seek out the lonely &amp;God’s mercy share

3.
Show us Your Spirit, brooding oér each city,
As You did weep above Jerusalem,
Seeking to gather all in love and pity,
And healing those who touch Your garment’s hem.



```

- |   -  |
-------------|------------|
Title | O Jesus Christ, to You |
Key |  |
Titles | undefined |
First Line | O Jesus Christ, to You may hymns be rising |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
