---
title: 321. My Jesus, I Love Thee - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 321. My Jesus, I Love Thee. 1. My Jesus, I love thee, I know thou art mine; for thee all the follies of sin I resign. My gracious Redeemer, my Savior art thou; if ever I loved thee, my Jesus, ’tis now.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, My Jesus, I Love Thee, My Jesus, I love thee, I know thou art mine; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 321. MY JESUS, I LOVE THEE
#### Seventh Day Adventist Hymnal

```txt



1.
My Jesus, I love thee, I know thou art mine;
for thee all the follies of sin I resign.
My gracious Redeemer, my Savior art thou;
if ever I loved thee, my Jesus, ’tis now.

2.
I love thee because thou hast first loved me,
and purchased my pardon on Calvary’s tree;
I love thee for wearing the thorns on thy brow;
if ever I loved thee, my Jesus, ’tis now.

3.
I’ll love Thee in life, I will love Thee ’til death,
And praise Thee as long as Thou lendest me breath;
And say when the death dew lies cold on my brow,
if ever I loved thee, my Jesus, ’tis now.

4.
In mansions of glory and endless delight;
I’ll ever adore thee in heaven so bright;
I’ll sing with the glittering crown on my brow;
if ever I loved thee, my Jesus, ’tis now.



```

- |   -  |
-------------|------------|
Title | My Jesus, I Love Thee |
Key |  |
Titles | undefined |
First Line | My Jesus, I love thee, I know thou art mine; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
