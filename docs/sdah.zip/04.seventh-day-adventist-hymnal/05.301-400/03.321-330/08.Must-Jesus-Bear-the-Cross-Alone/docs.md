---
title: 328. Must Jesus Bear the Cross Alone - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 328. Must Jesus Bear the Cross Alone. 1. Must Jesus bear the cross alone, and all the world go free? No, there’s a cross for everyone, and there’s a cross for me.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Must Jesus Bear the Cross Alone, Must Jesus bear the cross alone, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 328. MUST JESUS BEAR THE CROSS ALONE
#### Seventh Day Adventist Hymnal

```txt



1.
Must Jesus bear the cross alone,
and all the world go free?
No, there’s a cross for everyone,
and there’s a cross for me.

2.
The consecrated cross I’ll bear
till He shall set me free;
and then go home my crown to wear,
for there’s a crown for me.

3.
Upon the crystal pavement, down
at Jesus’ pierced feet,
with joy I’ll cast my golden crown,
and His dear name repeat.



```

- |   -  |
-------------|------------|
Title | Must Jesus Bear the Cross Alone |
Key |  |
Titles | undefined |
First Line | Must Jesus bear the cross alone, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
