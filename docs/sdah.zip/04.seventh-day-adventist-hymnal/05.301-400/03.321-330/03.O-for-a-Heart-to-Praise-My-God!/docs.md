---
title: 323. O for a Heart to Praise My God! - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 323. O for a Heart to Praise My God!. 1. O for a heart to praise my God, A heart from sin set free, A heart that always feels Thy blood So freely shed for me.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O for a Heart to Praise My God!, O for a heart to praise my God, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 323. O FOR A HEART TO PRAISE MY GOD!
#### Seventh Day Adventist Hymnal

```txt



1.
O for a heart to praise my God,
A heart from sin set free,
A heart that always feels Thy blood
So freely shed for me.

2.
A heart resigned, submissive, meek,
My dear Redeemer’s throne,
Where only Christ is heard to speak,
Where Jesus reigns alone.

3.
A heart in every thought renewed
And full of love divine,
Perfect and right and pure and good,
A copy, Lord, of Thine.

4.
Thy nature, gracious Lord, impart;
Come quickly from above;
Write Thy new name upon my heart,
Thy new, best name of Love.



```

- |   -  |
-------------|------------|
Title | O for a Heart to Praise My God! |
Key |  |
Titles | undefined |
First Line | O for a heart to praise my God, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
