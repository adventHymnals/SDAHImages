---
title: 324. Just as I Am, Thine Own to Be - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 324. Just as I Am, Thine Own to Be. 1. Just as I am, Thine own to be, Friend of the young, who lovest me, To consecrate myself to Thee, O Jesus Christ, I come.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Just as I Am, Thine Own to Be, Just as I am, Thine own to be, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 324. JUST AS I AM, THINE OWN TO BE
#### Seventh Day Adventist Hymnal

```txt



1.
Just as I am, Thine own to be,
Friend of the young, who lovest me,
To consecrate myself to Thee,
O Jesus Christ, I come.

2.
In the glad morning of my day,
My life to give, my vows to pay,
With no reserve and no delay,
With all my heart I come.

3.
I would live ever in the light,
I would work ever for the right;
I would serve Thee with all my might;
Therefore, to Thee I come.

4.
Just as I am, young, strong, and free,
To be the best that I can be
For truth, and righteousness, and Thee,
Lord of my life, I come.



```

- |   -  |
-------------|------------|
Title | Just as I Am, Thine Own to Be |
Key |  |
Titles | undefined |
First Line | Just as I am, Thine own to be, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
