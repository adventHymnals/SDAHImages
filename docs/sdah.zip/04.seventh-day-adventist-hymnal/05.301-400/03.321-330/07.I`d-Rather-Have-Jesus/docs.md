---
title: 327. I`d Rather Have Jesus - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 327. I`d Rather Have Jesus. 1. I’d rather have Jesus than silver or gold; I’d rather be His than have riches untold; I’d rather have Jesus than houses or land; I’d rather be led by His nail-pierced hand: 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I`d Rather Have Jesus, I’d rather have Jesus than silver or gold; ,Than to be the king of a vast domain or be held in sin’s dread sway!
    author: Brian Onang'o
---

#### Advent Hymnals
## 327. I`D RATHER HAVE JESUS
#### Seventh Day Adventist Hymnal

```txt



1.
I’d rather have Jesus than silver or gold;
I’d rather be His than have riches untold;
I’d rather have Jesus than houses or land;
I’d rather be led by His nail-pierced hand:


Refrain:
Than to be the king of a vast domain or be held in sin’s dread sway!
I’d rather have Jesus than anything this world affords today.


2.
I’d rather have Jesus than men’s applause;
I’d rather be faithful to His dear cause;
I’d rather have Jesus than world-wide fame;
I’d rather be true to His holy name:


Refrain:
Than to be the king of a vast domain or be held in sin’s dread sway!
I’d rather have Jesus than anything this world affords today.

3.
He’s fairer than lilies of rarest bloom;
He’s sweeter than honey from out the comb;
He’s all that my hungering spirit needs –
I’d rather have Jesus and let Him lead:

Refrain:
Than to be the king of a vast domain or be held in sin’s dread sway!
I’d rather have Jesus than anything this world affords today.




```

- |   -  |
-------------|------------|
Title | I`d Rather Have Jesus |
Key |  |
Titles | Than to be the king of a vast domain or be held in sin’s dread sway! |
First Line | I’d rather have Jesus than silver or gold; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
