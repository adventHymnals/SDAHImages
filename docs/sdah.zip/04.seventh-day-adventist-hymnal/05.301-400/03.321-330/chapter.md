---
title: Seventh Day Adventist Hymnal - 321-330
metadata:
    description: |
      Seventh Day Adventist Hymnal - 321-330
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 321-330
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 321-330

# Index of Titles
# | Title                        
-- |-------------
321|[My Jesus, I Love Thee](/seventh-day-adventist-hymnal/301-400/321-330/My-Jesus,-I-Love-Thee)
322|[Nothing Between](/seventh-day-adventist-hymnal/301-400/321-330/Nothing-Between)
323|[O for a Heart to Praise My God!](/seventh-day-adventist-hymnal/301-400/321-330/O-for-a-Heart-to-Praise-My-God!)
324|[Just as I Am, Thine Own to Be](/seventh-day-adventist-hymnal/301-400/321-330/Just-as-I-Am,-Thine-Own-to-Be)
325|[Jesus, I My Cross Have Taken](/seventh-day-adventist-hymnal/301-400/321-330/Jesus,-I-My-Cross-Have-Taken)
326|[Open My Eyes That I May See](/seventh-day-adventist-hymnal/301-400/321-330/Open-My-Eyes-That-I-May-See)
327|[I\`d Rather Have Jesus](/seventh-day-adventist-hymnal/301-400/321-330/I`d-Rather-Have-Jesus)
328|[Must Jesus Bear the Cross Alone](/seventh-day-adventist-hymnal/301-400/321-330/Must-Jesus-Bear-the-Cross-Alone)
329|[Take the World, but Give Me Jesus](/seventh-day-adventist-hymnal/301-400/321-330/Take-the-World,-but-Give-Me-Jesus)
330|[Take My Life and Let It Be](/seventh-day-adventist-hymnal/301-400/321-330/Take-My-Life-and-Let-It-Be)