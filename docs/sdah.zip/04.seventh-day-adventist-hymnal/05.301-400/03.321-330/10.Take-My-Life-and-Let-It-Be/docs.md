---
title: 330. Take My Life and Let It Be - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 330. Take My Life and Let It Be. 1. Take my life, and let it be Consecrated, Lord, to Thee; Take my hands, and let them move At the impulse of Thy love; At the impulse of Thy love.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Take My Life and Let It Be, Take my life, and let it be 
    author: Brian Onang'o
---

#### Advent Hymnals
## 330. TAKE MY LIFE AND LET IT BE
#### Seventh Day Adventist Hymnal

```txt



1.
Take my life, and let it be
Consecrated, Lord, to Thee;
Take my hands, and let them move
At the impulse of Thy love;
At the impulse of Thy love.

2.
Take my feet, and let them be
Swift and beautiful for Thee.
Take my voice, and let me sing
Always, only, for my King;
Always, only, for my King.

3.
Take my lips, and let them be
Filled with messages from Thee.
Take my silver and my gold:
Not a mite would I withhold;
Not a mite would I withhold.

4.
Take my will, and make it Thine,
It shall be no longer mine;
Take my heart, it is Thine own,
It shall be Thy royal throne.
It shall be Thy royal throne.

5.
Take my love, my Lord, I pour
At Thy feet its treasure store;
Take myself, and I will be,
Ever, only, all for Thee.
Ever, only, all for Thee.



```

- |   -  |
-------------|------------|
Title | Take My Life and Let It Be |
Key |  |
Titles | undefined |
First Line | Take my life, and let it be |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
