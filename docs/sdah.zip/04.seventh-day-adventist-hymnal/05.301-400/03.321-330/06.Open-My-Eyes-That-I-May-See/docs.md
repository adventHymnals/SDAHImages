---
title: 326. Open My Eyes That I May See - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 326. Open My Eyes That I May See. 1. Open my eyes, that I may see Glimpses of truth Thou hast for me; Place in my hands the wonderful key That shall unclasp and set me free. Silently now I wait for Thee, Ready, my God, Thy will to see; Open my eyes, illumine me, Spirit Divine!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Open My Eyes That I May See, Open my eyes, that I may see 
    author: Brian Onang'o
---

#### Advent Hymnals
## 326. OPEN MY EYES THAT I MAY SEE
#### Seventh Day Adventist Hymnal

```txt



1.
Open my eyes, that I may see
Glimpses of truth Thou hast for me;
Place in my hands the wonderful key
That shall unclasp and set me free.
Silently now I wait for Thee,
Ready, my God, Thy will to see;
Open my eyes,
illumine me, Spirit Divine!

2.
Open my ears that I may hear
Voices of truth Thou sendest clear;
and while the wavenotes fall on my ear,
Everything false will disappear.
Silently now I wait for Thee,
Ready, my God, Thy will to see;
Open my ears, illumine me, Spirit Divine!

3.
Open my mouth, and let me bear
Gladly the warm truth everywhere;
Open my heart, and let me prepare
Love with Thy children thus to share.
Silently now I wait for Thee,
Ready, my God, Thy will to see;
Open my heart, illumine me, Spirit Divine!



```

- |   -  |
-------------|------------|
Title | Open My Eyes That I May See |
Key |  |
Titles | undefined |
First Line | Open my eyes, that I may see |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
