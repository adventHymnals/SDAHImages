---
title: 329. Take the World, but Give Me Jesus - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 329. Take the World, but Give Me Jesus. 1. Take the world, but give me Jesus; All its Joys are but a name, But His love abideth ever, Through eternal years the same. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Take the World, but Give Me Jesus, Take the world, but give me Jesus; ,Oh, the height and depth of mercy!
    author: Brian Onang'o
---

#### Advent Hymnals
## 329. TAKE THE WORLD, BUT GIVE ME JESUS
#### Seventh Day Adventist Hymnal

```txt



1.
Take the world, but give me Jesus;
All its Joys are but a name,
But His love abideth ever,
Through eternal years the same.


Refrain:
Oh, the height and depth of mercy!
Oh, the length and breadth of love!
Oh, the fullness of redemption,
Pledge of endless life above.


2.
Take the world, but give me Jesus,
Sweetest comfort of my soul;
With my Savior watching o’er me,
I can sing, though billows roll.


Refrain:
Oh, the height and depth of mercy!
Oh, the length and breadth of love!
Oh, the fullness of redemption,
Pledge of endless life above.

3.
Take the world, but give me Jesus;
Let me view his constant smile;
Then throughout my pilgrim journey
Light will cheer me all the while.


Refrain:
Oh, the height and depth of mercy!
Oh, the length and breadth of love!
Oh, the fullness of redemption,
Pledge of endless life above.

4.
Take the world, but give me Jesus;
In His cross my trust shall be,
Till, with clearer, brighter vision
Face to face my Lord I see.

Refrain:
Oh, the height and depth of mercy!
Oh, the length and breadth of love!
Oh, the fullness of redemption,
Pledge of endless life above.




```

- |   -  |
-------------|------------|
Title | Take the World, but Give Me Jesus |
Key |  |
Titles | Oh, the height and depth of mercy! |
First Line | Take the world, but give me Jesus; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
