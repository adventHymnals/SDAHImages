---
title: 322. Nothing Between - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 322. Nothing Between. 1. Nothing between my soul and my Savior, naught of this world’s delusive dream; I have renounced all sinful pleasure; Jesus is mine, there’s nothing between. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Nothing Between, Nothing between my soul and my Savior, ,Nothing between my soul and my Savior,
    author: Brian Onang'o
---

#### Advent Hymnals
## 322. NOTHING BETWEEN
#### Seventh Day Adventist Hymnal

```txt



1.
Nothing between my soul and my Savior,
naught of this world’s delusive dream;
I have renounced all sinful pleasure;
Jesus is mine, there’s nothing between.


Refrain:
Nothing between my soul and my Savior,
so that his blessed face may be seen;
nothing preventing the least of his favor;
keep the way clear! let nothing between.


2.
Nothing between, like worldly pleasure;
habits of life, though harmless they seem,
must not my heart from him ever sever;
he is my all, there’s nothing between.


Refrain:
Nothing between my soul and my Savior,
so that his blessed face may be seen;
nothing preventing the least of his favor;
keep the way clear! let nothing between.

3.
Nothing between, e’en many hard trials,
though the whole world against me convene;
watching with prayer and much self denial,
I’ll triumph at last, there’s nothing between.

Refrain:
Nothing between my soul and my Savior,
so that his blessed face may be seen;
nothing preventing the least of his favor;
keep the way clear! let nothing between.




```

- |   -  |
-------------|------------|
Title | Nothing Between |
Key |  |
Titles | Nothing between my soul and my Savior, |
First Line | Nothing between my soul and my Savior, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
