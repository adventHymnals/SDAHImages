---
title: 377. Go Forth, Go Forth With Christ - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 377. Go Forth, Go Forth With Christ. 1. Go forth, go forth with Christ, Who called you to this day, He who has led, will lead And keep you in His way: His word is fast, His promise sure To all who serve Him and endure.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Go Forth, Go Forth With Christ, Go forth, go forth with Christ, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 377. GO FORTH, GO FORTH WITH CHRIST
#### Seventh Day Adventist Hymnal

```txt



1.
Go forth, go forth with Christ,
Who called you to this day,
He who has led, will lead
And keep you in His way:
His word is fast, His promise sure
To all who serve Him and endure.

2.
Go forth, go forth with Christ,
With purpose not your own,
Each vict’ry you shall gain
Through Him your Lord alone:
To guard you in fidelity
His Spirit shall your strength’ner be.

3.
Go forth, go forth with Christ,
His Priesthood you shall share,
Who bought us by His blood
To be His servants here:
Walk in the way your Savior trod,
Go forth with Him, go forth with God.



```

- |   -  |
-------------|------------|
Title | Go Forth, Go Forth With Christ |
Key |  |
Titles | undefined |
First Line | Go forth, go forth with Christ, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
