---
title: 380. Welcome, Day of Sweet Repose - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 380. Welcome, Day of Sweet Repose. 1. Welcome, day of sweet repose! Blessed be thy sacred hours! We would trust the One who knows All our weak and failing powers.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Welcome, Day of Sweet Repose, Welcome, day of sweet repose! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 380. WELCOME, DAY OF SWEET REPOSE
#### Seventh Day Adventist Hymnal

```txt



1.
Welcome, day of sweet repose!
Blessed be thy sacred hours!
We would trust the One who knows
All our weak and failing powers.

2.
Welcome, day in Eden born!
Holy rest for sinless man!
Like the dawning of fair morn
Come thy hours to us again.

3.
Welcome, day blessed by our Lord!
Toil shall cease and anxious care.
Day commanded by His word,
Day for song and praise and prayer.

4.
Welcome, day our Savior kept!
Keeping, wrought our righteousness,
Day God bids us ne’er forget,
Day of days His name to bless.



```

- |   -  |
-------------|------------|
Title | Welcome, Day of Sweet Repose |
Key |  |
Titles | undefined |
First Line | Welcome, day of sweet repose! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
