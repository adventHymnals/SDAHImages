---
title: Seventh Day Adventist Hymnal - 371-380
metadata:
    description: |
      Seventh Day Adventist Hymnal - 371-380
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 371-380
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 371-380

# Index of Titles
# | Title                        
-- |-------------
371|[Lift Him Up](/seventh-day-adventist-hymnal/301-400/371-380/Lift-Him-Up)
372|[How Beauteous Are Their Feet](/seventh-day-adventist-hymnal/301-400/371-380/How-Beauteous-Are-Their-Feet)
373|[Seeking the Lost](/seventh-day-adventist-hymnal/301-400/371-380/Seeking-the-Lost)
374|[Jesus, With Thy Church Abide](/seventh-day-adventist-hymnal/301-400/371-380/Jesus,-With-Thy-Church-Abide)
375|[Work, for the Night Is Coming](/seventh-day-adventist-hymnal/301-400/371-380/Work,-for-the-Night-Is-Coming)
376|[All Things Are Thine](/seventh-day-adventist-hymnal/301-400/371-380/All-Things-Are-Thine)
377|[Go Forth, Go Forth With Christ](/seventh-day-adventist-hymnal/301-400/371-380/Go-Forth,-Go-Forth-With-Christ)
378|[Go, Preach My Gospel](/seventh-day-adventist-hymnal/301-400/371-380/Go,-Preach-My-Gospel)
379|[We Give This Child to You](/seventh-day-adventist-hymnal/301-400/371-380/We-Give-This-Child-to-You)
380|[Welcome, Day of Sweet Repose](/seventh-day-adventist-hymnal/301-400/371-380/Welcome,-Day-of-Sweet-Repose)