---
title: 376. All Things Are Thine - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 376. All Things Are Thine. 1. All things are Thine; no gift have we, Lord of all gifts, to offer Thee; And hence with grateful hearts today, Thine own before Thy feet we lay.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, All Things Are Thine, All things are Thine; no gift have we, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 376. ALL THINGS ARE THINE
#### Seventh Day Adventist Hymnal

```txt



1.
All things are Thine; no gift have we,
Lord of all gifts, to offer Thee;
And hence with grateful hearts today,
Thine own before Thy feet we lay.

2.
Thy will was in the builder’s thought;
Thy hand unseen amidst us wrought;
Thro’ mortal motive, scheme and plan,
Thy wise, eternal purpose ran.

3.
No lack Thy perfect fullness knew;
For human needs and longings grew
This house of prayer- this home of rest.
Here may Thy saints be often blessed.

4.
In weakness and in want we call
On Thee, for whom the heav’ns are small;
Thy glory is Thy children’s good,
Thy joy Thy tender Fatherhood.

5.
O Father! deign these walls to bless;
Make this the abode of righteousness,
And let these doors a gateway be
To lead us from ourselves to Thee!



```

- |   -  |
-------------|------------|
Title | All Things Are Thine |
Key |  |
Titles | undefined |
First Line | All things are Thine; no gift have we, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
