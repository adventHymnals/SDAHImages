---
title: 372. How Beauteous Are Their Feet - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 372. How Beauteous Are Their Feet. 1. How beauteous are their feet Who stand on Zion’s hill; Who bring salvation on their tongues, And words of peace reveal!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, How Beauteous Are Their Feet, How beauteous are their feet 
    author: Brian Onang'o
---

#### Advent Hymnals
## 372. HOW BEAUTEOUS ARE THEIR FEET
#### Seventh Day Adventist Hymnal

```txt



1.
How beauteous are their feet
Who stand on Zion’s hill;
Who bring salvation on their tongues,
And words of peace reveal!

2.
How charming is their voice,
So sweet the tidings are:
“Zion, behold thy Savior King;
He reigns and triumphs here!”

3.
How happy are our ears,
That hear the joyful sound
Which kings and prophets waited for,
And sought, but never found!

4.
How blessed are our eyes,
That see this heavenly light;
Prophets and kings desired it long,
But died without the sight!

5.
The watchmen join their voice,
And tuneful notes employ;
Jerusalem breaks forth in songs,
And deserts learn the joy.



```

- |   -  |
-------------|------------|
Title | How Beauteous Are Their Feet |
Key |  |
Titles | undefined |
First Line | How beauteous are their feet |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
