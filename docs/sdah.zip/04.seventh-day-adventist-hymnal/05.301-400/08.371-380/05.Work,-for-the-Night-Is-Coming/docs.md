---
title: 375. Work, for the Night Is Coming - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 375. Work, for the Night Is Coming. 1. Work for the night is coming, Work through the morning hours; Work while the dew is sparkling; Work ‘mid springing flow’rs. Work when the day grows brighter, Work in the glowing sun; Work for the night is coming, When man’s work is done.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Work, for the Night Is Coming, Work for the night is coming, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 375. WORK, FOR THE NIGHT IS COMING
#### Seventh Day Adventist Hymnal

```txt



1.
Work for the night is coming,
Work through the morning hours;
Work while the dew is sparkling;
Work ‘mid springing flow’rs.
Work when the day grows brighter,
Work in the glowing sun;
Work for the night is coming,
When man’s work is done.

2.
Work for the night is coming,
Work thro’ the sunny noon;
Fill brightest hours with labor,
Rest comes sure and soon.
Give every flying minute
Something to keep in store;
Work for the night is coming,
When man works no more.

3.
Work for the night is coming,
Under the sunset skies;
While their bright tints are glowing,
Work for daylight flies.
Work till the last beam fadeth,
Fadeth to shine no more;
Work while the night is dark’ning,
When man’s work is o’er.



```

- |   -  |
-------------|------------|
Title | Work, for the Night Is Coming |
Key |  |
Titles | undefined |
First Line | Work for the night is coming, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
