---
title: 371. Lift Him Up - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 371. Lift Him Up. 1. Lift Him up, ’tis He that bids you, Let the dying look and live; To all weary, thirsting sinners, Living waters will He give; And though once so meek and lowly, Yet the Prince of heaven was He; And the blind, who grope in darkness, Through the blood of Christ shall see. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lift Him Up, Lift Him up, ’tis He that bids you, ,Lift Him up, the risen Savior,
    author: Brian Onang'o
---

#### Advent Hymnals
## 371. LIFT HIM UP
#### Seventh Day Adventist Hymnal

```txt



1.
Lift Him up, ’tis He that bids you,
Let the dying look and live;
To all weary, thirsting sinners,
Living waters will He give;
And though once so meek and lowly,
Yet the Prince of heaven was He;
And the blind, who grope in darkness,
Through the blood of Christ shall see.


Refrain:
Lift Him up, the risen Savior,
High amid the waiting throng;
Lift Him up, ’tis He that speaketh,
Now He bids you flee from wrong.


2.
Lift Him up, this precious Savior,
Let the multitude behold;
They with willing hearts shall seek Him,
He will draw them to His fold;
They shall gather from the wayside,
Hastening on with joyous feet,
They shall bear the cross of Jesus,
And shall find salvation sweet.


Refrain:
Lift Him up, the risen Savior,
High amid the waiting throng;
Lift Him up, ’tis He that speaketh,
Now He bids you flee from wrong.

3.
Lift Him up in all His glory,
‘Tis the Son of God on high;
Lift Him up, His love shall draw them,
Eén the careless shall draw nigh;
Let them hear again the story
Of the cross, the death of shame;
And from tongue to tongue repeat it;
Mighty throngs shall bless His name.


Refrain:
Lift Him up, the risen Savior,
High amid the waiting throng;
Lift Him up, ’tis He that speaketh,
Now He bids you flee from wrong.

4.
O then lift Him up in singing,
Lift the Savior up in prayer;
He, the glorious Redeemer,
All the sins of men did bear;
Yes, the young shall bow before Him,
And the old their voices raise;
All the deaf shall hear hosannah;
And the dumb shall shout His praise.

Refrain:
Lift Him up, the risen Savior,
High amid the waiting throng;
Lift Him up, ’tis He that speaketh,
Now He bids you flee from wrong.




```

- |   -  |
-------------|------------|
Title | Lift Him Up |
Key |  |
Titles | Lift Him up, the risen Savior, |
First Line | Lift Him up, ’tis He that bids you, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
