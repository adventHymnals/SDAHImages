---
title: 378. Go, Preach My Gospel - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 378. Go, Preach My Gospel. 1. “Go, preach My gospel,” saith the Lord; “Bid the whole world My grace receive; He shall be saved who trusts My word, And they condemned who disbelieve.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Go, Preach My Gospel, “Go, preach My gospel,” saith the Lord; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 378. GO, PREACH MY GOSPEL
#### Seventh Day Adventist Hymnal

```txt



1.
“Go, preach My gospel,” saith the Lord;
“Bid the whole world My grace receive;
He shall be saved who trusts My word,
And they condemned who disbelieve.

2.
“I’ll make your great commission known,
And ye shall prove My gospel true
By all the works that I have done,
By all the wonders ye shall do.

3.
“Teach all the nations My commands;
I’m with you till the world shall end;
All power is vested in My hands;
I can destroy, and I defend.”

4.
He spake, and light shone round His head;
On a bright cloud to heaven He rode;
They to the farthest nations spread
The grace of their ascended Lord.



```

- |   -  |
-------------|------------|
Title | Go, Preach My Gospel |
Key |  |
Titles | undefined |
First Line | “Go, preach My gospel,” saith the Lord; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
