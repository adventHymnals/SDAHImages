---
title: 373. Seeking the Lost - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 373. Seeking the Lost. 1. Seeking the lost, yes, kindly entreating Wanderers on the mountain astray; “Come unto Me,” His message repeating, Words of the Master speaking today. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Seeking the Lost, Seeking the lost, yes, kindly entreating ,Going afar (going afar)
    author: Brian Onang'o
---

#### Advent Hymnals
## 373. SEEKING THE LOST
#### Seventh Day Adventist Hymnal

```txt



1.
Seeking the lost, yes, kindly entreating
Wanderers on the mountain astray;
“Come unto Me,” His message repeating,
Words of the Master speaking today.


Refrain:
Going afar (going afar)
Upon the mountain (upon the mountain)
Bringing the wanderer back again, back again,
Into the fold (into the fold)
Of my Redeemer (of my Redeemer)
Jesus the Lamb for sinners slain, for sinners slain.


2.
Seeking the lost and pointing to Jesus
Souls that are weak and hearts that are sore,
Leading them forth in ways of salvation,
Showing the path to life evermore.


Refrain:
Going afar (going afar)
Upon the mountain (upon the mountain)
Bringing the wanderer back again, back again,
Into the fold (into the fold)
Of my Redeemer (of my Redeemer)
Jesus the Lamb for sinners slain, for sinners slain.

3.
Thus would I go on missions of mercy,
Following Christ from day unto day,
Cheering the faint and raising the fallen,
Pointing the lost to Jesus, the Way.

Refrain:
Going afar (going afar)
Upon the mountain (upon the mountain)
Bringing the wanderer back again, back again,
Into the fold (into the fold)
Of my Redeemer (of my Redeemer)
Jesus the Lamb for sinners slain, for sinners slain.




```

- |   -  |
-------------|------------|
Title | Seeking the Lost |
Key |  |
Titles | Going afar (going afar) |
First Line | Seeking the lost, yes, kindly entreating |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
