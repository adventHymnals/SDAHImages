---
title: 379. We Give This Child to You - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 379. We Give This Child to You. 1. We give this child to You, Our precious gift of love. Help us to lead each step aright With guidance from above.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, We Give This Child to You, We give this child to You, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 379. WE GIVE THIS CHILD TO YOU
#### Seventh Day Adventist Hymnal

```txt



1.
We give this child to You,
Our precious gift of love.
Help us to lead each step aright
With guidance from above.

2.
O bless each child of Yours,
And grant when they are grown,
They will have learned to love Your way,
And choose it for their own.

3.
We give ourselves to You,
And may Your Spirit fill
Our hearts and home, that all we do
Be subject to Your will.



```

- |   -  |
-------------|------------|
Title | We Give This Child to You |
Key |  |
Titles | undefined |
First Line | We give this child to You, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
