---
title: 374. Jesus, With Thy Church Abide - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 374. Jesus, With Thy Church Abide. 1. Jesus, with Thy church abide; Be her Savior, Lord, and Guide, While on earth her faith is tried: We beseech Thee, hear us.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Jesus, With Thy Church Abide, Jesus, with Thy church abide; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 374. JESUS, WITH THY CHURCH ABIDE
#### Seventh Day Adventist Hymnal

```txt



1.
Jesus, with Thy church abide;
Be her Savior, Lord, and Guide,
While on earth her faith is tried:
We beseech Thee, hear us.

2.
May her voice be ever clear,
Warning of a judgment near,
Telling of a Savior dear:
We beseech Thee, hear us.

3.
May she guide the poor and blind,
Seek the lost until she find,
And the broken hearted bind:
We beseech Thee, hear us.

4.
May she holy triumps win,
Overthrow the hosts of sin,
Gather all the nations in:
We beseech Thee, hear us.



```

- |   -  |
-------------|------------|
Title | Jesus, With Thy Church Abide |
Key |  |
Titles | undefined |
First Line | Jesus, with Thy church abide; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
