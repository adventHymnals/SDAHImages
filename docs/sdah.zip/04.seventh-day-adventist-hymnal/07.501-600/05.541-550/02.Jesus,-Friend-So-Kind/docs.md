---
title: 542. Jesus, Friend So Kind - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 542. Jesus, Friend So Kind. 1. Jesus, Friend, so kind and gentle, Little ones we bring to Thee: Grant to them Thy dearest blessing, Let Thine arms around them be; Now enfold them in Thy goodness, From all danger keep them free.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Jesus, Friend So Kind, Jesus, Friend, so kind and gentle, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 542. JESUS, FRIEND SO KIND
#### Seventh Day Adventist Hymnal

```txt



1.
Jesus, Friend, so kind and gentle,
Little ones we bring to Thee:
Grant to them Thy dearest blessing,
Let Thine arms around them be;
Now enfold them in Thy goodness,
From all danger keep them free.

2.
Thou who did receive the children
To Thyself so tenderly,
Give to all who teach and guide them
Wisdom and humility.
Vision true to keep them noble,
Love to serve them faithfully.



```

- |   -  |
-------------|------------|
Title | Jesus, Friend So Kind |
Key |  |
Titles | undefined |
First Line | Jesus, Friend, so kind and gentle, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
