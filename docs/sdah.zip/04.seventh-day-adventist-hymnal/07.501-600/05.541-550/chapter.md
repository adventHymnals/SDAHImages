---
title: Seventh Day Adventist Hymnal - 541-550
metadata:
    description: |
      Seventh Day Adventist Hymnal - 541-550
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 541-550
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 541-550

# Index of Titles
# | Title                        
-- |-------------
541|[Lord, Speak to Me](/seventh-day-adventist-hymnal/501-600/541-550/Lord,-Speak-to-Me)
542|[Jesus, Friend So Kind](/seventh-day-adventist-hymnal/501-600/541-550/Jesus,-Friend-So-Kind)
543|[Jesus, Friend of Little Children](/seventh-day-adventist-hymnal/501-600/541-550/Jesus,-Friend-of-Little-Children)
544|[Jesus, Son of Blessed Mary](/seventh-day-adventist-hymnal/501-600/541-550/Jesus,-Son-of-Blessed-Mary)
545|[Savior, Like a Shepherd](/seventh-day-adventist-hymnal/501-600/541-550/Savior,-Like-a-Shepherd)
546|[The Lord\`s My Shepherd](/seventh-day-adventist-hymnal/501-600/541-550/The-Lord`s-My-Shepherd)
547|[Be Thou My Vision](/seventh-day-adventist-hymnal/501-600/541-550/Be-Thou-My-Vision)
548|[Now Praise the Hidden God of Love](/seventh-day-adventist-hymnal/501-600/541-550/Now-Praise-the-Hidden-God-of-Love)
549|[Loving Shepherd of Thy Sheep](/seventh-day-adventist-hymnal/501-600/541-550/Loving-Shepherd-of-Thy-Sheep)
550|[Every Flower That Grows](/seventh-day-adventist-hymnal/501-600/541-550/Every-Flower-That-Grows)