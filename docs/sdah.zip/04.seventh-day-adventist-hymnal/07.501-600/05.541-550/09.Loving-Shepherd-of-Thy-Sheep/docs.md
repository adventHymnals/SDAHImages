---
title: 549. Loving Shepherd of Thy Sheep - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 549. Loving Shepherd of Thy Sheep. 1. Loving Shepherd of Thy sheep, Keep Thy lamb, in safety keep; Nothing can Thy power withstand; None can pluck me from Thy hand.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Loving Shepherd of Thy Sheep, Loving Shepherd of Thy sheep, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 549. LOVING SHEPHERD OF THY SHEEP
#### Seventh Day Adventist Hymnal

```txt



1.
Loving Shepherd of Thy sheep,
Keep Thy lamb, in safety keep;
Nothing can Thy power withstand;
None can pluck me from Thy hand.

2.
Loving Shepherd, ever near,
Teach Thy lamb Thy voice to hear;
Suffer not my steps to stray
From the straight and narrow way.

3.
Where Thou leadest I would go,
Walking in Thy steps below,
Till within the heavenly fold
I my Shepherd shall behold.



```

- |   -  |
-------------|------------|
Title | Loving Shepherd of Thy Sheep |
Key |  |
Titles | undefined |
First Line | Loving Shepherd of Thy sheep, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
