---
title: 550. Every Flower That Grows - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 550. Every Flower That Grows. 1. Every flow’r that grows, Every brook that flows, Tell of beauty God has giv’n for me: Throughout my life may beauty be Deep within a heart from sin set free.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Every Flower That Grows, Every flow’r that grows, Every brook that flows, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 550. EVERY FLOWER THAT GROWS
#### Seventh Day Adventist Hymnal

```txt



1.
Every flow’r that grows, Every brook that flows,
Tell of beauty God has giv’n for me:
Throughout my life may beauty be
Deep within a heart from sin set free.

2.
Gracious Lord above, Looking down in love,
Guide my thoughts, my life, in my walk with Thee,
That day by day the world may see
Christ, the Lord and Savior, lives in me.

3.
All my earthly days, I shall sing and praise
God the Father, Spirit, and Christ with the Son.
Grant faith when life on earth is done,
I shall sing with those whose rest is won.



```

- |   -  |
-------------|------------|
Title | Every Flower That Grows |
Key |  |
Titles | undefined |
First Line | Every flow’r that grows, Every brook that flows, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
