---
title: 545. Savior, Like a Shepherd - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 545. Savior, Like a Shepherd. 1. Savior, like a shepherd lead us, much we need thy tenderest care; in thy pleasant pastures feed us, for our use thy folds prepare. Blessed Jesus, blessed Jesus! Thou hast bought us, thine we are. Blessed Jesus, blessed Jesus! Thou hast bought us, thine we are.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Savior, Like a Shepherd, Savior, like a shepherd lead us, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 545. SAVIOR, LIKE A SHEPHERD
#### Seventh Day Adventist Hymnal

```txt



1.
Savior, like a shepherd lead us,
much we need thy tenderest care;
in thy pleasant pastures feed us,
for our use thy folds prepare.
Blessed Jesus, blessed Jesus!
Thou hast bought us, thine we are.
Blessed Jesus, blessed Jesus!
Thou hast bought us, thine we are.

2.
We are thine, thou dost befriend us,
be the guardian of our way;
keep thy flock, from sin defend us,
seek us when we go astray.
Blessed Jesus, blessed Jesus!
Hear, O hear us when we pray.
Blessed Jesus, blessed Jesus!
Hear, O hear us when we pray.

3.
Thou hast promised to receive us,
poor and sinful though we be;
thou hast mercy to relieve us,
grace to cleanse and power to free.
Blessed Jesus, blessed Jesus!
We will early turn to thee.
Blessed Jesus, blessed Jesus!
We will early turn to thee.



```

- |   -  |
-------------|------------|
Title | Savior, Like a Shepherd |
Key |  |
Titles | undefined |
First Line | Savior, like a shepherd lead us, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
