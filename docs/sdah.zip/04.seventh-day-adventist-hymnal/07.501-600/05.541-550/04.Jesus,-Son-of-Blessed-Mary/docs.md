---
title: 544. Jesus, Son of Blessed Mary - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 544. Jesus, Son of Blessed Mary. 1. Jesus, Son of blessed Mary, Once on earth a little child, Pattern fair of holy living, Gracious, loving, undefiled;
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Jesus, Son of Blessed Mary, Jesus, Son of blessed Mary, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 544. JESUS, SON OF BLESSED MARY
#### Seventh Day Adventist Hymnal

```txt



1.
Jesus, Son of blessed Mary,
Once on earth a little child,
Pattern fair of holy living,
Gracious, loving, undefiled;

2.
Though Thy eager heart was yearning
Heavy laden souls to free,
Yet Thou calledst little children
In their happiness to Thee.

3.
Grant that we, like little children,
Free from pride and guile my be;
Cheerful, trusting, safe, protected
By the blessed Trinity.



```

- |   -  |
-------------|------------|
Title | Jesus, Son of Blessed Mary |
Key |  |
Titles | undefined |
First Line | Jesus, Son of blessed Mary, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
