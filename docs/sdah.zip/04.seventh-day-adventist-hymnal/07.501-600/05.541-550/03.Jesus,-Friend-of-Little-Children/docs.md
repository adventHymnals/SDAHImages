---
title: 543. Jesus, Friend of Little Children - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 543. Jesus, Friend of Little Children. 1. Jesus, Friend of little children, Be a friend to me; Take my hand and ever keep me Close to Thee.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Jesus, Friend of Little Children, Jesus, Friend of little children, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 543. JESUS, FRIEND OF LITTLE CHILDREN
#### Seventh Day Adventist Hymnal

```txt



1.
Jesus, Friend of little children,
Be a friend to me;
Take my hand and ever keep me
Close to Thee.

2.
Teach me how to grow in goodness,
Daily as I grow;
Thou hast been a child, and surely
Thou dost know.

3.
Step by step, O, lead me onward,
Upward into youth;
Wiser, stronger, still becoming
In Thy truth.

4.
Never leave me, nor forsake me;
Ever be my friend;
For I need Thee from life’s dawning
To its end.



```

- |   -  |
-------------|------------|
Title | Jesus, Friend of Little Children |
Key |  |
Titles | undefined |
First Line | Jesus, Friend of little children, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
