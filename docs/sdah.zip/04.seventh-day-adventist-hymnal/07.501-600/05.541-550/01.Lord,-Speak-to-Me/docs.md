---
title: 541. Lord, Speak to Me - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 541. Lord, Speak to Me. 1. Lord, speak to me, that I may speak in living echoes of thy tone; as thou has sought, so let me seek thine erring children lost and lone.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord, Speak to Me, Lord, speak to me, that I may speak 
    author: Brian Onang'o
---

#### Advent Hymnals
## 541. LORD, SPEAK TO ME
#### Seventh Day Adventist Hymnal

```txt



1.
Lord, speak to me, that I may speak
in living echoes of thy tone;
as thou has sought, so let me seek
thine erring children lost and lone.

2.
O lead me, Lord, that I may lead
the wandering and the wavering feet;
O feed me, Lord, that I may feed
thy hungering ones with manna sweet.

3.
O strengthen me, that while I stand
firm on the rock, and strong in thee,
I may stretch out a loving land
to wrestlers with the troubled sea.



```

- |   -  |
-------------|------------|
Title | Lord, Speak to Me |
Key |  |
Titles | undefined |
First Line | Lord, speak to me, that I may speak |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
