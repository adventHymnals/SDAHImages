---
title: 548. Now Praise the Hidden God of Love - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 548. Now Praise the Hidden God of Love. 1. Now praise the hidden God of love In whom we all must live and move, Who shepherds us, at every stage Thro’ youth, maturity, and age.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Now Praise the Hidden God of Love, Now praise the hidden God of love 
    author: Brian Onang'o
---

#### Advent Hymnals
## 548. NOW PRAISE THE HIDDEN GOD OF LOVE
#### Seventh Day Adventist Hymnal

```txt



1.
Now praise the hidden God of love
In whom we all must live and move,
Who shepherds us, at every stage
Thro’ youth, maturity, and age.

2.
Who challenged us, when were young
To storm the citadels of wrong;
In care for others taught us how
God’s true community must grow.

3.
Who bids us never lose our zest,
Tho’ age is urging us to rest,
But proves to us that we have still
A work to do, a place to fill.

4.
Then talk no more of wasted time,
But Godward look, and upward climb,
Content to sleep, when day is done,
And rise refreshed, and travel on.



```

- |   -  |
-------------|------------|
Title | Now Praise the Hidden God of Love |
Key |  |
Titles | undefined |
First Line | Now praise the hidden God of love |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
