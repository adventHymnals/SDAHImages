---
title: 547. Be Thou My Vision - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 547. Be Thou My Vision. 1. Be Thou my Vision, O Lord of my heart; Naught be all else to me, save that Thou art Thou my best Thought, by day or by night, Waking or sleeping, Thy presence my light.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Be Thou My Vision, Be Thou my Vision, O Lord of my heart; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 547. BE THOU MY VISION
#### Seventh Day Adventist Hymnal

```txt



1.
Be Thou my Vision, O Lord of my heart;
Naught be all else to me, save that Thou art
Thou my best Thought, by day or by night,
Waking or sleeping, Thy presence my light.

2.
Be Thou my Wisdom, and Thou my true Word;
I ever with Thee and Thou with me, Lord;
Thou my great Father, I Thy true son;
Thou in me dwelling, and I with Thee one.

3.
Riches I heed not, nor man’s empty praise,
Thou mine Inheritance, now and always:
Thou and Thou only, first in my heart,
High King of Heaven, my Treasure Thou art.

4.
High King of Heaven, my victory won,
May I reach Heaven’s joys, O bright Heaven’s Sun!
Heart of my own heart, whatever befall,
Still be my Vision, O Ruler of all.



```

- |   -  |
-------------|------------|
Title | Be Thou My Vision |
Key |  |
Titles | undefined |
First Line | Be Thou my Vision, O Lord of my heart; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
