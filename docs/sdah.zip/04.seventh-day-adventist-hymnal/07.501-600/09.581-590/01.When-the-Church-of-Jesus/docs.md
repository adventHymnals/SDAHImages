---
title: 581. When the Church of Jesus - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 581. When the Church of Jesus. 1. When the church of Jesus shuts its outer door, Lest the roar of traffic drown the voice of prayer: May our prayers, Lord make up ten times more aware That the world we banish is our Christian care.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, When the Church of Jesus, When the church of Jesus shuts its outer door, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 581. WHEN THE CHURCH OF JESUS
#### Seventh Day Adventist Hymnal

```txt



1.
When the church of Jesus shuts its outer door,
Lest the roar of traffic drown the voice of prayer:
May our prayers, Lord make up ten times more aware
That the world we banish is our Christian care.

2.
If our hearts are lifted where devotion soars
High above this hungry suffering world of ours:
Lest our hymns should drug us to forget its needs,
Forge our Christian worship into Christian deeds.

3.
Lest the gifts we offer, money, talents, time,
Serve to salve our conscience to our secret shame:
Lord, reprove, inspire us by the way you give;
Teach us, dying Savior, how true Christians live.



```

- |   -  |
-------------|------------|
Title | When the Church of Jesus |
Key |  |
Titles | undefined |
First Line | When the church of Jesus shuts its outer door, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
