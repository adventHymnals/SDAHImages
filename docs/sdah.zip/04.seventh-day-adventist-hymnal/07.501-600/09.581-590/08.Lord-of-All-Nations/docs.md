---
title: 588. Lord of All Nations - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 588. Lord of All Nations. 1. Lord of all nations, grant me grace To love all people, every race, And in each person may I see My kindred loved, redeemed by Thee.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord of All Nations, Lord of all nations, grant me grace 
    author: Brian Onang'o
---

#### Advent Hymnals
## 588. LORD OF ALL NATIONS
#### Seventh Day Adventist Hymnal

```txt



1.
Lord of all nations, grant me grace
To love all people, every race,
And in each person may I see
My kindred loved, redeemed by Thee.

2.
Break down the wall that would divide
Thy children, Lord, on every side.
My neighbor’s good let me pursue;
Let Christian love bind warm and true.

3.
Forgive me, Lord, where I have erred
By loveless act and thoughtless word.
Make me to see the wrong I do
Will crucify my Lord anew.

4.
Give me Thy courage, Lord, to speak
Whenever strong oppress the weak.
Should I myself the victim be,
Help me forgive, remembering Thee.

5.
With Thine own love may I be filled
And by Thy Holy Spirit willed,
That all I touch, where’er I be,
May be divinely touched by Thee.



```

- |   -  |
-------------|------------|
Title | Lord of All Nations |
Key |  |
Titles | undefined |
First Line | Lord of all nations, grant me grace |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
