---
title: 589. Holy Spirit, Gracious Guest - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 589. Holy Spirit, Gracious Guest. 1. Holy Spirit, gracious guest, Hear and grant our heart’s request For that gift supreme and best: Holy heav’nly love.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Holy Spirit, Gracious Guest, Holy Spirit, gracious guest, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 589. HOLY SPIRIT, GRACIOUS GUEST
#### Seventh Day Adventist Hymnal

```txt



1.
Holy Spirit, gracious guest,
Hear and grant our heart’s request
For that gift supreme and best:
Holy heav’nly love.

2.
Faith that mountains could remove,
Tongues of earth or heaven above,
Knowledge, all things, empty prove
If I have no love.

3.
Though I as a martyr bleed,
Give my goods the poor to feed,
All is vain if love I need:
Therefore give me love.

4.
Love is kind and suffers long,
Love is pure and thinks no wrong,
Love than death it self more strong:
Therefore give us love.

5.
Prophecy will fade away,
Melting in the light of day;
Love will ever with us stay:
Therefore give us love.

6.
Faith and hope and love we see
Joining hand in hand agree-
But the greatest of the three,
And the best is love.



```

- |   -  |
-------------|------------|
Title | Holy Spirit, Gracious Guest |
Key |  |
Titles | undefined |
First Line | Holy Spirit, gracious guest, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
