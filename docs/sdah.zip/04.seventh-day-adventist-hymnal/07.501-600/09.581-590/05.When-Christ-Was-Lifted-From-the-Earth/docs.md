---
title: 585. When Christ Was Lifted From the Earth - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 585. When Christ Was Lifted From the Earth. 1. When Christ was lifted from the earth His arms stretched out above Through every culture, every birth, to draw an answering love.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, When Christ Was Lifted From the Earth, When Christ was lifted from the earth His arms stretched out above 
    author: Brian Onang'o
---

#### Advent Hymnals
## 585. WHEN CHRIST WAS LIFTED FROM THE EARTH
#### Seventh Day Adventist Hymnal

```txt



1.
When Christ was lifted from the earth His arms stretched out above
Through every culture, every birth, to draw an answering love.

2.
Still east and west His love extends and always, near or far,
He calls and claims us as His friends and loves us as we are.

3.
Where generation, class, or race divides us to our shame,
He sees not labels but a face, a person and a name.

4.
Thus freely loved, tho’ fully known, may I in Christ be free
To welcome and accept His own as Christ accepted me.



```

- |   -  |
-------------|------------|
Title | When Christ Was Lifted From the Earth |
Key |  |
Titles | undefined |
First Line | When Christ was lifted from the earth His arms stretched out above |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
