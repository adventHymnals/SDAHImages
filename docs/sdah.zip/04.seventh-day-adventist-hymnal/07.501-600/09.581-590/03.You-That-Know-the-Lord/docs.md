---
title: 583. You That Know the Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 583. You That Know the Lord. 1. You that know the Lord is gracious, You for whom a cornerstone Stands, of God elect and precious, Laid that you may build there-on, See that on that sure foundation You a living temple raise. Towers that may tell forth salvation, Walls that may reech-o praise.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, You That Know the Lord, You that know the Lord is gracious, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 583. YOU THAT KNOW THE LORD
#### Seventh Day Adventist Hymnal

```txt



1.
You that know the Lord is gracious,
You for whom a cornerstone
Stands, of God elect and precious,
Laid that you may build there-on,
See that on that sure foundation
You a living temple raise.
Towers that may tell forth salvation,
Walls that may reech-o praise.

2.
Living stones by God appointed
Each to his allotted place,
Kings and priests, by God anointed,
Shall you not declare His grace?
You, a royal generation,
Tell the tidings of your birth,
Tidings of a new creation
To an old and weary earth.

3.
Tell the praise of Him who called you
Out of darkness into light,
Broke the fetters that enthralled you,
Gave you freedom, peace, and sight:
Tell the tale of sins forgiven,
Strength renewed and hope restored,
Till the earth, in tune with heaven,
Praise and magnify the Lord.



```

- |   -  |
-------------|------------|
Title | You That Know the Lord |
Key |  |
Titles | undefined |
First Line | You that know the Lord is gracious, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
