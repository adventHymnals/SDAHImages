---
title: 582. Working, O Christ, With Thee - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 582. Working, O Christ, With Thee. 1. Working, O Christ, with Thee, working with Thee, Unworthy, sinful, weak, though we may be; Our all to Thee we give, for Thee alone we live, And by Thy grace achieve, working with Thee.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Working, O Christ, With Thee, Working, O Christ, with Thee, working with Thee, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 582. WORKING, O CHRIST, WITH THEE
#### Seventh Day Adventist Hymnal

```txt



1.
Working, O Christ, with Thee, working with Thee,
Unworthy, sinful, weak, though we may be;
Our all to Thee we give, for Thee alone we live,
And by Thy grace achieve, working with Thee.

2.
Along the city’s waste, working with Thee,
Our eager footsteps haste, like Thee to be;
The poor we gather in, the outcasts raise from sin,
And labor souls to win, working with Thee.

3.
Savior, we weary not, working with Thee,
As hard as Thine our lot can never be;
Our joy and comfort this, “Thy grace sufficent is;”
This changes toil to bliss, working with Thee.

4.
So let us labor on, working with Thee,
Till earth to Thee is won, from sin set free;
Till men, from shore to shore, receive Thee, and adore,
And join us evermore, working with Thee.



```

- |   -  |
-------------|------------|
Title | Working, O Christ, With Thee |
Key |  |
Titles | undefined |
First Line | Working, O Christ, with Thee, working with Thee, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
