---
title: 586. What Joy It Is to Worship Here - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 586. What Joy It Is to Worship Here. 1. What joy it is to worship here, And find ourselves at home, Where God, who uses every gift, Has room for all who come!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, What Joy It Is to Worship Here, What joy it is to worship here, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 586. WHAT JOY IT IS TO WORSHIP HERE
#### Seventh Day Adventist Hymnal

```txt



1.
What joy it is to worship here,
And find ourselves at home,
Where God, who uses every gift,
Has room for all who come!

2.
Yet are no two of us alike
Of all the human race,
And we must seek a common ground
If we would share His grace.



```

- |   -  |
-------------|------------|
Title | What Joy It Is to Worship Here |
Key |  |
Titles | undefined |
First Line | What joy it is to worship here, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
