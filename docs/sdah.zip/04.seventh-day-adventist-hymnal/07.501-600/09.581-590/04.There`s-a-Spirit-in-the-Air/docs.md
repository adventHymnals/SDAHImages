---
title: 584. There`s a Spirit in the Air - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 584. There`s a Spirit in the Air. 1. There’s a Spirit in the air, telling Christians everywhere “Praise the love that Christ revealed, living, working in our world.”
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, There`s a Spirit in the Air, There’s a Spirit in the air, telling Christians everywhere 
    author: Brian Onang'o
---

#### Advent Hymnals
## 584. THERE`S A SPIRIT IN THE AIR
#### Seventh Day Adventist Hymnal

```txt



1.
There’s a Spirit in the air, telling Christians everywhere
“Praise the love that Christ revealed, living, working in our world.”

2.
Lose your shyness, find your tongue; tell the world what God has done:
God in Christ has come to stay, we can see His pow’r today.

3.
When believers break the bread, when a hungry child is fed:
Praise the love that Christ revealed, living, working in our world.

4.
Still His Spirit leads the fight, seeing wrong and setting right:
God in Christ has come to stay, we can see His pow’r today.

5.
When a stranger’s not alone, where the homeless find a home,
Praise the love that Christ revealed, living, working in our world.

6.
May His Spirit fill our praise, guide our thoughts and change our ways.
God in Christ has come to stay, we can see His power today.

7.
There’s a Spirit in the air, calling people everywhere;
Praise the love that Christ revealed: living, working in our world.



```

- |   -  |
-------------|------------|
Title | There`s a Spirit in the Air |
Key |  |
Titles | undefined |
First Line | There’s a Spirit in the air, telling Christians everywhere |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
