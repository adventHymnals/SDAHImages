---
title: 587. In Christ There Is No East nor West - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 587. In Christ There Is No East nor West. 1. In Christ there is no east nor west, In Him no south or north; But one great fellowship of love Throughout the whole wide earth.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, In Christ There Is No East nor West, In Christ there is no east nor west, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 587. IN CHRIST THERE IS NO EAST NOR WEST
#### Seventh Day Adventist Hymnal

```txt



1.
In Christ there is no east nor west,
In Him no south or north;
But one great fellowship of love
Throughout the whole wide earth.

2.
In Him shall true heart everywhere
Their high communion find;
His service is the golden cord
Close binding all mankind.

3.
Join hands, then, brothers of the faith,
Whate’er your race may be.
Who serves my Father as a son
Is surely kin to me.

4.
In Christ now meet both east and west,
In Him meet south and north;
All Christly souls are one in Him
Throughout the whole wide earth.



```

- |   -  |
-------------|------------|
Title | In Christ There Is No East nor West |
Key |  |
Titles | undefined |
First Line | In Christ there is no east nor west, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
