---
title: Seventh Day Adventist Hymnal - 581-590
metadata:
    description: |
      Seventh Day Adventist Hymnal - 581-590
    keywords: |
      Seventh Day Adventist Hymnal, adventhymnals, advent hymnals 581-590
    author: Brian Onang'o
---

#### Advent Hymnals
## Seventh Day Adventist Hymnal - 581-590

# Index of Titles
# | Title                        
-- |-------------
581|[When the Church of Jesus](/seventh-day-adventist-hymnal/501-600/581-590/When-the-Church-of-Jesus)
582|[Working, O Christ, With Thee](/seventh-day-adventist-hymnal/501-600/581-590/Working,-O-Christ,-With-Thee)
583|[You That Know the Lord](/seventh-day-adventist-hymnal/501-600/581-590/You-That-Know-the-Lord)
584|[There\`s a Spirit in the Air](/seventh-day-adventist-hymnal/501-600/581-590/There`s-a-Spirit-in-the-Air)
585|[When Christ Was Lifted From the Earth](/seventh-day-adventist-hymnal/501-600/581-590/When-Christ-Was-Lifted-From-the-Earth)
586|[What Joy It Is to Worship Here](/seventh-day-adventist-hymnal/501-600/581-590/What-Joy-It-Is-to-Worship-Here)
587|[In Christ There Is No East nor West](/seventh-day-adventist-hymnal/501-600/581-590/In-Christ-There-Is-No-East-nor-West)
588|[Lord of All Nations](/seventh-day-adventist-hymnal/501-600/581-590/Lord-of-All-Nations)
589|[Holy Spirit, Gracious Guest](/seventh-day-adventist-hymnal/501-600/581-590/Holy-Spirit,-Gracious-Guest)
590|[Trust and Obey](/seventh-day-adventist-hymnal/501-600/581-590/Trust-and-Obey)