---
title: 518. Standing on the Promises - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 518. Standing on the Promises. 1. Standing on the promises of Christ my King, Thru eternal ages let His praises ring; Glory in the highest I will shout and sing, Standing on the promises of God. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Standing on the Promises, Standing on the promises of Christ my King, ,Standing, standing,
    author: Brian Onang'o
---

#### Advent Hymnals
## 518. STANDING ON THE PROMISES
#### Seventh Day Adventist Hymnal

```txt



1.
Standing on the promises of Christ my King,
Thru eternal ages let His praises ring;
Glory in the highest I will shout and sing,
Standing on the promises of God.


Refrain:
Standing, standing,
Standing on the promises
of God my Savior;
Standing, standing,
I’m standing on the promises of God.


2.
Standing on the promises that cannot fail,
When the howling storms of doubt and fear assail,
By the living word of God I shall prevail,
Standing on the promises of God.


Refrain:
Standing, standing,
Standing on the promises
of God my Savior;
Standing, standing,
I’m standing on the promises of God.

3.
Standing on the promises of Christ the Lord,
Bound to Him eternally by love’s strong cord,
Overcoming daily with the Spirit’s sword,
Standing on the promises of God.

Refrain:
Standing, standing,
Standing on the promises
of God my Savior;
Standing, standing,
I’m standing on the promises of God.




```

- |   -  |
-------------|------------|
Title | Standing on the Promises |
Key |  |
Titles | Standing, standing, |
First Line | Standing on the promises of Christ my King, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
