---
title: 511. I Know Whom I Have Believed - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 511. I Know Whom I Have Believed. 1. I know not why God’s wondrous grace To me He hath made known, Nor why, unworthy, Christ in love Redeemed me for His own. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Know Whom I Have Believed, I know not why God’s wondrous grace To me He hath made known, ,But “I know whom I have believed, and am persuaded that His is able
    author: Brian Onang'o
---

#### Advent Hymnals
## 511. I KNOW WHOM I HAVE BELIEVED
#### Seventh Day Adventist Hymnal

```txt



1.
I know not why God’s wondrous grace To me He hath made known,
Nor why, unworthy, Christ in love Redeemed me for His own.


Refrain:
But “I know whom I have believed, and am persuaded that His is able
To keep that which I’ve committed Unto Him against that day.”


2.
I know not how this saving faith To me He did impart,
Nor how believing in His word Wrought peace within my heart.


Refrain:
But “I know whom I have believed, and am persuaded that His is able
To keep that which I’ve committed Unto Him against that day.”

3.
I know not how the Spirit moves, Convincing men of sin,
Revealing Jesus through the word, Creating faith in Him.


Refrain:
But “I know whom I have believed, and am persuaded that His is able
To keep that which I’ve committed Unto Him against that day.”

4.
I know not when my Lord may come, At night or noonday fair,
Nor if I walk the vale with Him, Or meet Him in the air.

Refrain:
But “I know whom I have believed, and am persuaded that His is able
To keep that which I’ve committed Unto Him against that day.”




```

- |   -  |
-------------|------------|
Title | I Know Whom I Have Believed |
Key |  |
Titles | But “I know whom I have believed, and am persuaded that His is able |
First Line | I know not why God’s wondrous grace To me He hath made known, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
