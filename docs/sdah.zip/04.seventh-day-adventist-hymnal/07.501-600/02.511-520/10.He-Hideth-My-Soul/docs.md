---
title: 520. He Hideth My Soul - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 520. He Hideth My Soul. 1. A wonderful Savior is Jesus my Lord, A wonderful Savior to me, He hideth my soul in the cleft of the rock, Where rivers of pleasure I see. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, He Hideth My Soul, A wonderful Savior is Jesus my Lord, ,He hideth my soul in the cleft of the rock
    author: Brian Onang'o
---

#### Advent Hymnals
## 520. HE HIDETH MY SOUL
#### Seventh Day Adventist Hymnal

```txt



1.
A wonderful Savior is Jesus my Lord,
A wonderful Savior to me,
He hideth my soul in the cleft of the rock,
Where rivers of pleasure I see.


Refrain:
He hideth my soul in the cleft of the rock
That shadows a dry, thirsty land;
he hideth my life in the depths of His love,
And covers me there with His hand,
And covers me there with His hand.


2.
A wonderful Savior is Jesus my Lord,
He taketh my burden away,
He holdeth me up, and I shall not be moved,
He giveth me strength as my day.


Refrain:
He hideth my soul in the cleft of the rock
That shadows a dry, thirsty land;
he hideth my life in the depths of His love,
And covers me there with His hand,
And covers me there with His hand.

3.
With numberless blessings each moment He crowns,
And filled with His fullness divine,
I sing in my rapture, Oh, Glory to God
For such a Redeemer as mine.


Refrain:
He hideth my soul in the cleft of the rock
That shadows a dry, thirsty land;
he hideth my life in the depths of His love,
And covers me there with His hand,
And covers me there with His hand.

4.
When clothed in His brightness, transported I rise
To meet Him in clouds of the sky,
His perfect salvation, His wonderful love,
I’ll shout with the millions on high.

Refrain:
He hideth my soul in the cleft of the rock
That shadows a dry, thirsty land;
he hideth my life in the depths of His love,
And covers me there with His hand,
And covers me there with His hand.




```

- |   -  |
-------------|------------|
Title | He Hideth My Soul |
Key |  |
Titles | He hideth my soul in the cleft of the rock |
First Line | A wonderful Savior is Jesus my Lord, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
