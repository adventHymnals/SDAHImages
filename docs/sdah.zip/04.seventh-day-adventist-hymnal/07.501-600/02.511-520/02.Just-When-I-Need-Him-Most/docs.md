---
title: 512. Just When I Need Him Most - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 512. Just When I Need Him Most. 1. Just when I need Him, Jesus is near, Just when I falter, just when I fear; Ready to help me, ready to cheer, Just when I need Him most. Just when I need Him most, Just when I need Him most, Jesus is near to comfort and cheer, Just when I need Him most.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Just When I Need Him Most, Just when I need Him, Jesus is near, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 512. JUST WHEN I NEED HIM MOST
#### Seventh Day Adventist Hymnal

```txt



1.
Just when I need Him, Jesus is near,
Just when I falter, just when I fear;
Ready to help me, ready to cheer,
Just when I need Him most.
Just when I need Him most,
Just when I need Him most,
Jesus is near to comfort and cheer,
Just when I need Him most.

2.
Just when I need Him, Jesus is true,
Never forsaking, all the way through,
Giving for burdens pleasures anew,
Just when I need Him most.
Just when I need Him most,
Just when I need Him most,
Jesus is near to comfort and cheer,
Just when I need Him most.

3.
Just when I need Him, Jesus is strong,
Bearing my burdens all the day long;
For all my sorrow giving a song,
Just when I need Him most.
Just when I need Him most,
Just when I need Him most,
Jesus is near to comfort and cheer,
Just when I need Him most.

4.
Just when I need Him, He is my all,
Answering when upon Him I call;
Tenderly watching lest I should fall,
Just when I need Him most.
Just when I need Him most,
Just when I need Him most,
Jesus is near to comfort and cheer,
Just when I need Him most.



```

- |   -  |
-------------|------------|
Title | Just When I Need Him Most |
Key |  |
Titles | undefined |
First Line | Just when I need Him, Jesus is near, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
