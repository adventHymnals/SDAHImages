---
title: 517. My Faith Looks Up to Thee - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 517. My Faith Looks Up to Thee. 1. My faith looks up to thee, thou Lamb of Calvary, Savior divine; Now hear me while I pray, take all my guilt away, O let me from this day be wholly Thine.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, My Faith Looks Up to Thee, My faith looks up to thee, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 517. MY FAITH LOOKS UP TO THEE
#### Seventh Day Adventist Hymnal

```txt



1.
My faith looks up to thee,
thou Lamb of Calvary,
Savior divine;
Now hear me while I pray,
take all my guilt away,
O let me from this day
be wholly Thine.

2.
May thy rich grace impart
strength to my fainting heart,
my zeal inspire!
As thou hast died for me,
O may my love to thee
pure, warm, and changeless be,
a living fire!

3.
While life’s dark maze I tread,
and griefs around me spread,
be thou my guide;
bid darkness turn to day,
wipe sorrow’s tears away,
nor let me ever stray
from Thee aside.



```

- |   -  |
-------------|------------|
Title | My Faith Looks Up to Thee |
Key |  |
Titles | undefined |
First Line | My faith looks up to thee, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
