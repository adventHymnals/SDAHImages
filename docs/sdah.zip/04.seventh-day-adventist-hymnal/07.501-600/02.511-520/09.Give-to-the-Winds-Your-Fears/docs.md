---
title: 519. Give to the Winds Your Fears - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 519. Give to the Winds Your Fears. 1. Give to the winds your fears; In hope be undismayed: God hears your sighs and coundts your tears, God shall lift up your head.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Give to the Winds Your Fears, Give to the winds your fears; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 519. GIVE TO THE WINDS YOUR FEARS
#### Seventh Day Adventist Hymnal

```txt



1.
Give to the winds your fears;
In hope be undismayed:
God hears your sighs and coundts your tears,
God shall lift up your head.

2.
To Him commit your griefs;
Your ways put in His hands
To His sure truth adn tender care
Who earth adn heave commands.

3.
O put your trust in God;
In duty’s path go on.
Walk in His strength with faith and hope,
So shall your work be done.

4.
Leave to His sovereign sway
To choose and to command;
So you shall, faithful, seek His way
how wise, how strong His hand!



```

- |   -  |
-------------|------------|
Title | Give to the Winds Your Fears |
Key |  |
Titles | undefined |
First Line | Give to the winds your fears; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
