---
title: 515. The Lord Is My Light - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 515. The Lord Is My Light. 1. The Lord is my light; then why should I fear? By day and by night His presence is near; He is my salvation from sorrow and sin; This blessed persuasion the Spirit brings in. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, The Lord Is My Light, The Lord is my light; then why should I fear? ,The Lord is my light, my joy, and my song;
    author: Brian Onang'o
---

#### Advent Hymnals
## 515. THE LORD IS MY LIGHT
#### Seventh Day Adventist Hymnal

```txt



1.
The Lord is my light; then why should I fear?
By day and by night His presence is near;
He is my salvation from sorrow and sin;
This blessed persuasion the Spirit brings in.


Refrain:
The Lord is my light, my joy, and my song;
By day and by night He leads me along;
The Lord is my light, my joy, and my song;
By day and by night He leads me along.


2.
The Lord is my light; though clods may arise,
Faith, stronger than sight, looks up to the skies
Where Jesus forever in glory doth reign:
Then how can I ever in darkness remain?


Refrain:
The Lord is my light, my joy, and my song;
By day and by night He leads me along;
The Lord is my light, my joy, and my song;
By day and by night He leads me along.

3.
The Lord is my light, the Lord is my strength;
I know in His might I’ll conquer at length;
My weakness in mercy He covers with power,
And, walking by faith, He upholds me each hour.


Refrain:
The Lord is my light, my joy, and my song;
By day and by night He leads me along;
The Lord is my light, my joy, and my song;
By day and by night He leads me along.

4.
The lord is my light, my all and in all;
There is in His sight no darkness at all;
He is my Redeemer, my Savior and King;
With saints and with angels His praises I sing.

Refrain:
The Lord is my light, my joy, and my song;
By day and by night He leads me along;
The Lord is my light, my joy, and my song;
By day and by night He leads me along.




```

- |   -  |
-------------|------------|
Title | The Lord Is My Light |
Key |  |
Titles | The Lord is my light, my joy, and my song; |
First Line | The Lord is my light; then why should I fear? |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
