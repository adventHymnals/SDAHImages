---
title: 516. All the Way - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 516. All the Way. 1. All the way my Savior leads me; What have I to ask beside? Can I doubt His tender mercy, Who through life has been my guide? Heavenly peace, divinest comfort, Here by faith in Him to dwell; For I know whate’er befall me, Jesus doeth all things well; For I know whate’er befall me, Jesus doeth all things well.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, All the Way, All the way my Savior leads me; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 516. ALL THE WAY
#### Seventh Day Adventist Hymnal

```txt



1.
All the way my Savior leads me;
What have I to ask beside?
Can I doubt His tender mercy,
Who through life has been my guide?
Heavenly peace, divinest comfort,
Here by faith in Him to dwell;
For I know whate’er befall me,
Jesus doeth all things well;
For I know whate’er befall me,
Jesus doeth all things well.

2.
All the way my Savior leads me;
Cheers each winding path I tread;
Gives me grace for every trial,
Feeds me with the living bread;
Though my weary steps may falter,
And my soul athirst may be,
Gushing from the Rock before me,
Lo, a spring of joy I see;
Gushing from the Rock before me,
Lo, a spring of joy I see.

3.
All the way my Savior leads me;
O the fullness of His love!
Perfect rest to me is promised
In my Father’s house above;
When I wake to life immortal,
Wing my flight to realms of day,
This my song through endless ages,
Jesus led me all the way;
This my song through endless ages,
Jesus led me all the way.



```

- |   -  |
-------------|------------|
Title | All the Way |
Key |  |
Titles | undefined |
First Line | All the way my Savior leads me; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
