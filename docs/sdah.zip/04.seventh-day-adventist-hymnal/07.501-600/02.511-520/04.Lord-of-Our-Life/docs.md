---
title: 514. Lord of Our Life - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 514. Lord of Our Life. 1. Lord of our life, and God of our salvation, Star of our night, and hope of every nation, Hear and receive Thy church’s supplication, Lord God Almighty.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord of Our Life, Lord of our life, and God of our salvation, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 514. LORD OF OUR LIFE
#### Seventh Day Adventist Hymnal

```txt



1.
Lord of our life, and God of our salvation,
Star of our night, and hope of every nation,
Hear and receive Thy church’s supplication,
Lord God Almighty.

2.
Lord, Thou canst help when earthly armor faileth;
Lord, Thou canst save when deadly sin assaileth;
Lord, o’er Thy rock nor death nor hell prevaileth;
Grant us Thy peace, Lord

3.
Peace in our hearts our evil thoughts assuaging;
Peace in Thy church, where brothers are engaging;
Peace, when the world its busy war is waging;
Send us, O Savior.

4.
Grant us Thy help till foes are backward driven;
Grant them Thy truth that they may be forgiven;
Grant peace on earth, and, after we have striven,
Peace in Thy heaven.



```

- |   -  |
-------------|------------|
Title | Lord of Our Life |
Key |  |
Titles | undefined |
First Line | Lord of our life, and God of our salvation, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
