---
title: 525. Hiding in Thee - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 525. Hiding in Thee. 1. O safe to the Rock that is higher than I, My soul in its conflicts and sorrows would fly; So sinful, so weary, Thine, Thine, would I be; Thou blest “Rock of Ages,” I’m hiding in Thee. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Hiding in Thee, O safe to the Rock that is higher than I, ,Hiding in Thee, hiding in Thee,
    author: Brian Onang'o
---

#### Advent Hymnals
## 525. HIDING IN THEE
#### Seventh Day Adventist Hymnal

```txt



1.
O safe to the Rock that is higher than I,
My soul in its conflicts and sorrows would fly;
So sinful, so weary, Thine, Thine, would I be;
Thou blest “Rock of Ages,” I’m hiding in Thee.


Refrain:
Hiding in Thee, hiding in Thee,
Thou blest “Rock of Ages,”
I’m hiding in Thee.


2.
In the calm of the noontide, in sorrow’s lone hour,
In times when temptation casts over me its power;
In the tempests of life, on its wide, heaving sea,
Thou blest “Rock of Ages,“ I’m hiding in Thee.


Refrain:
Hiding in Thee, hiding in Thee,
Thou blest “Rock of Ages,”
I’m hiding in Thee.

3.
How oft in the conflict, when pressed by the foe,
I have fled to my refuge and breathed out my woe;
How often, when trials like sea billows roll,
Have I hidden in Thee, O Thou Rock of my soul.

Refrain:
Hiding in Thee, hiding in Thee,
Thou blest “Rock of Ages,”
I’m hiding in Thee.




```

- |   -  |
-------------|------------|
Title | Hiding in Thee |
Key |  |
Titles | Hiding in Thee, hiding in Thee, |
First Line | O safe to the Rock that is higher than I, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
