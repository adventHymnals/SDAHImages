---
title: 526. Because He Lives - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 526. Because He Lives. 1. God sent His Son, they called Him Jesus, He came to love, heal, and forgive; He lived and died to buy my pardon, An empty grave is there to prove my Savior lives. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Because He Lives, God sent His Son, they called Him Jesus, ,Because He lives I can face tomorrow,
    author: Brian Onang'o
---

#### Advent Hymnals
## 526. BECAUSE HE LIVES
#### Seventh Day Adventist Hymnal

```txt



1.
God sent His Son, they called Him Jesus,
He came to love, heal, and forgive;
He lived and died to buy my pardon,
An empty grave is there to prove my Savior lives.


Refrain:
Because He lives I can face tomorrow,
Because He lives all fear is gone;
Because I know He holds the future.
And life is worth the living just because He lives.


2.
How sweet to hold a newborn baby,
And feel the pride, and joy He gives;
But greater still the calm assurance,
This child can face uncertain days because He lives.

Refrain:
Because He lives I can face tomorrow,
Because He lives all fear is gone;
Because I know He holds the future.
And life is worth the living just because He lives.




```

- |   -  |
-------------|------------|
Title | Because He Lives |
Key |  |
Titles | Because He lives I can face tomorrow, |
First Line | God sent His Son, they called Him Jesus, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
