---
title: 529. Under His Wings - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 529. Under His Wings. 1. Under His wings I am safely abiding; Though the night deepens and tempests are wild, Still I can trust Him; I know He will keep me; he has redeemed me, and I am His child. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Under His Wings, Under His wings I am safely abiding; ,Under His wings, under His wings,
    author: Brian Onang'o
---

#### Advent Hymnals
## 529. UNDER HIS WINGS
#### Seventh Day Adventist Hymnal

```txt



1.
Under His wings I am safely abiding;
Though the night deepens and tempests are wild,
Still I can trust Him; I know He will keep me;
he has redeemed me, and I am His child.


Refrain:
Under His wings, under His wings,
Who from His love can sever?
Under His wings, my soul shall abide,
Safely abide forever.


2.
Under His wings, what a refuge in sorrow!
How the heart yearningly turns to its rest!
Often when earth has no balm for my healing,
There I find comfort, and there I am blest.


Refrain:
Under His wings, under His wings,
Who from His love can sever?
Under His wings, my soul shall abide,
Safely abide forever.

3.
Under His wings, O what precious enjoyment!
There will I hide till life’s trials are over;
Sheltered, protected, no evil can harm me;
Resting in Jesus I’m safe evermore.

Refrain:
Under His wings, under His wings,
Who from His love can sever?
Under His wings, my soul shall abide,
Safely abide forever.




```

- |   -  |
-------------|------------|
Title | Under His Wings |
Key |  |
Titles | Under His wings, under His wings, |
First Line | Under His wings I am safely abiding; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
