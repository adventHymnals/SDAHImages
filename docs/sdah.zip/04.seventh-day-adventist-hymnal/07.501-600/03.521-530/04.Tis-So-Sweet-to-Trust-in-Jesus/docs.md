---
title: 524. Tis So Sweet to Trust in Jesus - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 524. Tis So Sweet to Trust in Jesus. 1. ‘Tis so sweet to trust in Jesus, and to take him at his word; just to rest upon his promise, and to know, “Thus saith the Lord.” 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Tis So Sweet to Trust in Jesus, ‘Tis so sweet to trust in Jesus, ,Jesus, Jesus, how I trust him!
    author: Brian Onang'o
---

#### Advent Hymnals
## 524. TIS SO SWEET TO TRUST IN JESUS
#### Seventh Day Adventist Hymnal

```txt



1.
‘Tis so sweet to trust in Jesus,
and to take him at his word;
just to rest upon his promise,
and to know, “Thus saith the Lord.”


Refrain:
Jesus, Jesus, how I trust him!
How I’ve proved him o’er and o’er!
Jesus, Jesus, precious Jesus!
O for grace to trust him more!


2.
O how sweet to trust in Jesus,
just to trust his cleansing blood;
and in simple faith to plunge me
neath the healing, cleansing flood!


Refrain:
Jesus, Jesus, how I trust him!
How I’ve proved him o’er and o’er!
Jesus, Jesus, precious Jesus!
O for grace to trust him more!

3.
Yes, ’tis sweet to trust in Jesus,
just from sin and self to cease;
just from Jesus simply taking
life and rest, and joy and peace.


Refrain:
Jesus, Jesus, how I trust him!
How I’ve proved him o’er and o’er!
Jesus, Jesus, precious Jesus!
O for grace to trust him more!

4.
I’m so glad I learned to trust thee,
precious Jesus, Savior, friend;
and I know that thou art with me,
wilt be with me to the end.

Refrain:
Jesus, Jesus, how I trust him!
How I’ve proved him o’er and o’er!
Jesus, Jesus, precious Jesus!
O for grace to trust him more!




```

- |   -  |
-------------|------------|
Title | Tis So Sweet to Trust in Jesus |
Key |  |
Titles | Jesus, Jesus, how I trust him! |
First Line | ‘Tis so sweet to trust in Jesus, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
