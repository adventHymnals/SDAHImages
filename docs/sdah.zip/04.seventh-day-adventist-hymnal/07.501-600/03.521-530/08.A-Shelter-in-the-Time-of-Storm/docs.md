---
title: 528. A Shelter in the Time of Storm - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 528. A Shelter in the Time of Storm. 1. The Lord’s our Rock, in Him we hide, A shelter in the time of storm; Secure whatever ill betide, A shelter in the time of storm. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, A Shelter in the Time of Storm, The Lord’s our Rock, in Him we hide, ,Mighty Rock in a weary land,
    author: Brian Onang'o
---

#### Advent Hymnals
## 528. A SHELTER IN THE TIME OF STORM
#### Seventh Day Adventist Hymnal

```txt



1.
The Lord’s our Rock, in Him we hide,
A shelter in the time of storm;
Secure whatever ill betide,
A shelter in the time of storm.


Refrain:
Mighty Rock in a weary land,
Cooling shade on the burning sand,
Faithful guide for the pilgrim band—
A shelter in the time of storm.


2.
A shade by day, defense by night,
A shelter in the time of storm;
No fears alarm, no foes afright,
A shelter in the time of storm.


Refrain:
Mighty Rock in a weary land,
Cooling shade on the burning sand,
Faithful guide for the pilgrim band—
A shelter in the time of storm.

3.
The raging storms may round us beat,
A shelter in the time of storm
We’ll never leave our safe retreat,
A shelter in the time of storm.


Refrain:
Mighty Rock in a weary land,
Cooling shade on the burning sand,
Faithful guide for the pilgrim band—
A shelter in the time of storm.

4.
O Rock divine, O Refuge dear,
A Shelter in the time of storm;
Be Thou our helper ever near,
A Shelter in the time of storm.

Refrain:
Mighty Rock in a weary land,
Cooling shade on the burning sand,
Faithful guide for the pilgrim band—
A shelter in the time of storm.




```

- |   -  |
-------------|------------|
Title | A Shelter in the Time of Storm |
Key |  |
Titles | Mighty Rock in a weary land, |
First Line | The Lord’s our Rock, in Him we hide, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
