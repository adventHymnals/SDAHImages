---
title: 530. It Is Well With My Soul - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 530. It Is Well With My Soul. 1. When peace, like a river, attendeth my way, when sorrows like sea billows roll; whatever my lot, thou hast taught me to say, It is well, it is well with my soul. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, It Is Well With My Soul, When peace, like a river, attendeth my way, ,It is well with my soul,
    author: Brian Onang'o
---

#### Advent Hymnals
## 530. IT IS WELL WITH MY SOUL
#### Seventh Day Adventist Hymnal

```txt



1.
When peace, like a river, attendeth my way,
when sorrows like sea billows roll;
whatever my lot, thou hast taught me to say,
It is well, it is well with my soul.


Refrain:
It is well with my soul,
it is well, it is well with my soul.


2.
My sin–oh, the joy of this glorious thought–
My sin, not in part but the whole,
is nailed to the cross, and I bear it no more,
praise the Lord, praise the Lord, O my soul!


Refrain:
It is well with my soul,
it is well, it is well with my soul.

3.
And, Lord, haste the day when my faith shall be sight,
the clouds be rolled back as a scroll;
the trump shall resound, and the Lord shall descend,
even so, it is well with my soul.

Refrain:
It is well with my soul,
it is well, it is well with my soul.




```

- |   -  |
-------------|------------|
Title | It Is Well With My Soul |
Key |  |
Titles | It is well with my soul, |
First Line | When peace, like a river, attendeth my way, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
