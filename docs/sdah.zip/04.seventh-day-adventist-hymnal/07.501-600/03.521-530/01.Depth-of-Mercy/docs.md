---
title: 521. Depth of Mercy - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 521. Depth of Mercy. 1. Depth of mercy!–can there be Mercy still reserved for me? Can my God His wrath forbear? Me, the chief of sinners, spare?
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Depth of Mercy, Depth of mercy!–can there be 
    author: Brian Onang'o
---

#### Advent Hymnals
## 521. DEPTH OF MERCY
#### Seventh Day Adventist Hymnal

```txt



1.
Depth of mercy!–can there be
Mercy still reserved for me?
Can my God His wrath forbear?
Me, the chief of sinners, spare?

2.
I have long withstood His grace,
Long provoked Him to His face,
Would not hearken to His calls,
Grieved Him by a thousand falls.

3.
Now incline me to repent;
Let me now my sins lament;
Now my foul revolt deplore,
Weep, believe, and sin no more.

4.
There for me the Savior stands,
Shows His wounds and spreads His hands;
God is love! I know, I feel;
Jesus weeps, and loves me still.



```

- |   -  |
-------------|------------|
Title | Depth of Mercy |
Key |  |
Titles | undefined |
First Line | Depth of mercy!–can there be |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
