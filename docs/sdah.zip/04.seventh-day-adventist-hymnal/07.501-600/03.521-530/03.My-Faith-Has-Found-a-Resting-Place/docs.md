---
title: 523. My Faith Has Found a Resting Place - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 523. My Faith Has Found a Resting Place. 1. My faith has found a resting place, Not in a manmade creed; I trust the ever living One, That He for me shall plead. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, My Faith Has Found a Resting Place, My faith has found a resting place, ,I need no other evidence,
    author: Brian Onang'o
---

#### Advent Hymnals
## 523. MY FAITH HAS FOUND A RESTING PLACE
#### Seventh Day Adventist Hymnal

```txt



1.
My faith has found a resting place,
Not in a manmade creed;
I trust the ever living One,
That He for me shall plead.


Refrain:
I need no other evidence,
I need no other plea;
It is enough that Jesus died,
And rose again for me.


2.
Enough for me that Jesus saves,
This ends my fear and doubt;
A sinful soul, I come to Him,
He will not cast me out.


Refrain:
I need no other evidence,
I need no other plea;
It is enough that Jesus died,
And rose again for me.

3.
My soul is resting on the Word,
The living Word of God,
Salvation in my Savior’s name,
Salvation through His blood.


Refrain:
I need no other evidence,
I need no other plea;
It is enough that Jesus died,
And rose again for me.

4.
My great Physician heals the sick,
The lost He came to save;
For me His precious blood He shed,
For me His life He gave.

Refrain:
I need no other evidence,
I need no other plea;
It is enough that Jesus died,
And rose again for me.




```

- |   -  |
-------------|------------|
Title | My Faith Has Found a Resting Place |
Key |  |
Titles | I need no other evidence, |
First Line | My faith has found a resting place, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
