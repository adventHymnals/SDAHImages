---
title: 522. My Hope Is Built on Nothing Less - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 522. My Hope Is Built on Nothing Less. 1. My hope is built on nothing less than Jesus’ blood and righteousness. I dare not trust the sweetest frame, but wholly lean on Jesus’ name. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, My Hope Is Built on Nothing Less, My hope is built on nothing less ,On Christ the solid rock I stand;
    author: Brian Onang'o
---

#### Advent Hymnals
## 522. MY HOPE IS BUILT ON NOTHING LESS
#### Seventh Day Adventist Hymnal

```txt



1.
My hope is built on nothing less
than Jesus’ blood and righteousness.
I dare not trust the sweetest frame,
but wholly lean on Jesus’ name.


Refrain:
On Christ the solid rock I stand;
all other ground is sinking sand,
all other ground is sinking sand.


2.
When Darkness veils his lovely face,
I rest on his unchanging grace.
in every high and stormy gale,
my anchor holds within the veil.


Refrain:
On Christ the solid rock I stand;
all other ground is sinking sand,
all other ground is sinking sand.

3.
His oath, his covenant, his blood
supports me in the whelming flood.
When all around my soul gives way,
he then is all my hope and stay.


Refrain:
On Christ the solid rock I stand;
all other ground is sinking sand,
all other ground is sinking sand.

4.
When He shall come with trumpet sound,
O may I then in him be found!
Dressed in his righteousness alone,
faultless to stand before the throne.

Refrain:
On Christ the solid rock I stand;
all other ground is sinking sand,
all other ground is sinking sand.




```

- |   -  |
-------------|------------|
Title | My Hope Is Built on Nothing Less |
Key |  |
Titles | On Christ the solid rock I stand; |
First Line | My hope is built on nothing less |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
