---
title: 508. Anywhere With Jesus - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 508. Anywhere With Jesus. 1. Anywhere with Jesus I can safely go, Anywhere He leads me in this world below; Anywhere without Him dearest joys would fade; Anywhere with Jesus I am not afraid. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Anywhere With Jesus, Anywhere with Jesus I can safely go, ,Anywhere, anywhere! Fear I cannot know;
    author: Brian Onang'o
---

#### Advent Hymnals
## 508. ANYWHERE WITH JESUS
#### Seventh Day Adventist Hymnal

```txt



1.
Anywhere with Jesus I can safely go,
Anywhere He leads me in this world below;
Anywhere without Him dearest joys would fade;
Anywhere with Jesus I am not afraid.


Refrain:
Anywhere, anywhere! Fear I cannot know;
Anywhere with Jesus I can safely go.


2.
Anywhere with Jesus I am not alone;
Other friends may fail me, He is still my own;
Though His hand may lead me over drearest ways,
Anywhere with Jesus is a house of praise.


Refrain:
Anywhere, anywhere! Fear I cannot know;
Anywhere with Jesus I can safely go.

3.
Anywhere with Jesus I can go to sleep,
When the darkening shadows round about me creep,
Knowing I shall waken nevermore to roam;
Anywhere with Jesus will be home, sweet home.

Refrain:
Anywhere, anywhere! Fear I cannot know;
Anywhere with Jesus I can safely go.




```

- |   -  |
-------------|------------|
Title | Anywhere With Jesus |
Key |  |
Titles | Anywhere, anywhere! Fear I cannot know; |
First Line | Anywhere with Jesus I can safely go, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
