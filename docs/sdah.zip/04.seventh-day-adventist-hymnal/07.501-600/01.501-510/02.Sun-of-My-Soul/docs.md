---
title: 502. Sun of My Soul - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 502. Sun of My Soul. 1. Sun of my soul, O Savior dear! It is not night if Thou be near; O may no earth-born cloud arise To hide Thee from Thy servant’s eyes.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Sun of My Soul, Sun of my soul, O Savior dear! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 502. SUN OF MY SOUL
#### Seventh Day Adventist Hymnal

```txt



1.
Sun of my soul, O Savior dear!
It is not night if Thou be near;
O may no earth-born cloud arise
To hide Thee from Thy servant’s eyes.

2.
When soft the dews of kindly sleep
My weary eyelids gently steep,
Be my last thought how sweet to rest
Forever on my Savior’s breast!

3.
Abide with me from morn till eve,
For without Thee I cannot live;
Abide with me when night is nigh,
For without Thee I dare not die.

4.
Be near and bless me when I wake,
Ere through the world my way I take;
Till in the ocean of Thy love
I lose myself in heaven above.



```

- |   -  |
-------------|------------|
Title | Sun of My Soul |
Key |  |
Titles | undefined |
First Line | Sun of my soul, O Savior dear! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
