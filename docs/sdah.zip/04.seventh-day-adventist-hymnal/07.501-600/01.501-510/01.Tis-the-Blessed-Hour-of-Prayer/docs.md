---
title: 501. Tis the Blessed Hour of Prayer - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 501. Tis the Blessed Hour of Prayer. 1. ‘Tis the blessed hour of prayer, when our hearts lowly bend, And we gather to Jesus, our Savior and Friend; If we come to Him in faith, His protection to share, 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Tis the Blessed Hour of Prayer, ‘Tis the blessed hour of prayer, when our hearts lowly bend, ,What a balm for the weary! O how sweet to be there!
    author: Brian Onang'o
---

#### Advent Hymnals
## 501. TIS THE BLESSED HOUR OF PRAYER
#### Seventh Day Adventist Hymnal

```txt



1.
‘Tis the blessed hour of prayer, when our hearts lowly bend,
And we gather to Jesus, our Savior and Friend;
If we come to Him in faith, His protection to share,


Refrain:
What a balm for the weary! O how sweet to be there!
Blessed hour of prayer, Blessed hour of prayer,
What a balm for the weary! O how sweet to be there!


2.
‘Tis the blessed hour of prayer, when the Savior draws near,
With a tender compassion His children to hear;
When He tells us we may cast at His feet every care,


Refrain:
What a balm for the weary! O how sweet to be there!
Blessed hour of prayer, Blessed hour of prayer,
What a balm for the weary! O how sweet to be there!

3.
‘Tis the blessed hour of prayer, when the tempted and tried
To the Savior who loves them their sorrows confide;
With a sympathizing heart He removes every care;


Refrain:
What a balm for the weary! O how sweet to be there!
Blessed hour of prayer, Blessed hour of prayer,
What a balm for the weary! O how sweet to be there!

4.
‘Tis the blessed hour of prayer, trusting Him we believe,
That the blessings we’re needing we’ll surely receive;
In the fullness of this trust we shall lose every care;

Refrain:
What a balm for the weary! O how sweet to be there!
Blessed hour of prayer, Blessed hour of prayer,
What a balm for the weary! O how sweet to be there!




```

- |   -  |
-------------|------------|
Title | Tis the Blessed Hour of Prayer |
Key |  |
Titles | What a balm for the weary! O how sweet to be there! |
First Line | ‘Tis the blessed hour of prayer, when our hearts lowly bend, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
