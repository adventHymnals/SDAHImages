---
title: 504. Lord Jesus, Think on Me - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 504. Lord Jesus, Think on Me. 1. Lord Jesus, think on me, And purge away my sin; From earth-born passions set me free, And make me pure within.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Lord Jesus, Think on Me, Lord Jesus, think on me, And purge away my sin; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 504. LORD JESUS, THINK ON ME
#### Seventh Day Adventist Hymnal

```txt



1.
Lord Jesus, think on me, And purge away my sin;
From earth-born passions set me free, And make me pure within.

2.
Lord Jesus, think on me, With care and woe oppressed;
Let me Thy loving servant be, And taste Thy promised rest.

3.
Lord Jesus, think on me, Nor let me go astray;
Through darkness and perplexity Point Thou the heavenly way.

4.
Lord Jesus, think on me, That I may sing above
To Father, Spirit, and to Thee, The strains of praise and love.



```

- |   -  |
-------------|------------|
Title | Lord Jesus, Think on Me |
Key |  |
Titles | undefined |
First Line | Lord Jesus, think on me, And purge away my sin; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
