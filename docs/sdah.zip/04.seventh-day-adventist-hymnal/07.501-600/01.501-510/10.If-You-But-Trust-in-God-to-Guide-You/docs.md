---
title: 510. If You But Trust in God to Guide You - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 510. If You But Trust in God to Guide You. 1. If you but trust in God to guide you And place your confidence in Him, You’ll find Him always there beside you, To give you hope and strength within. For those who trust God’s changeless love Build on the rock that will not move.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, If You But Trust in God to Guide You, If you but trust in God to guide you 
    author: Brian Onang'o
---

#### Advent Hymnals
## 510. IF YOU BUT TRUST IN GOD TO GUIDE YOU
#### Seventh Day Adventist Hymnal

```txt



1.
If you but trust in God to guide you
And place your confidence in Him,
You’ll find Him always there beside you,
To give you hope and strength within.
For those who trust God’s changeless love
Build on the rock that will not move.

2.
What gain is there in futile weeping,
In helpless anger and distress?
If you are in His care and keeping,
In sorrow will He love you less?
For He who took for you a cross
Will bring you safe through every loss.

3.
In patient trust await His leisure
In cheerful hope, with heart content
To take whate’er your Father’s pleasure
And all discerning love have sent;
Doubt not your inmost wants are known
To Him who chose you for His own.

4.
Sing, pray, and keep His ways unswerving,
Offer your service faithfully,
And trust His word; though undeserving,
You’ll find His promise true to be.
God never will forsake in need
The soul that trusts in Him indeed.



```

- |   -  |
-------------|------------|
Title | If You But Trust in God to Guide You |
Key |  |
Titles | undefined |
First Line | If you but trust in God to guide you |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
