---
title: 506. A Mighty Fortress - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 506. A Mighty Fortress. 1. A mighty fortress is our God, a bulwark never failing; our helper he amid the flood of mortal ills prevaling. For still our ancient foe doth seek to work us woe; his craft and power are great, and armed with cruel hate, on earth is not his equal.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, A Mighty Fortress, A mighty fortress is our God, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 506. A MIGHTY FORTRESS
#### Seventh Day Adventist Hymnal

```txt



1.
A mighty fortress is our God,
a bulwark never failing;
our helper he amid the flood
of mortal ills prevaling.
For still our ancient foe
doth seek to work us woe;
his craft and power are great,
and armed with cruel hate,
on earth is not his equal.

2.
Did we in our own strength confide,
our striving would be losing,
were not the right man on our side,
the man of God’s own choosing.
Dost ask who that may be?
Christ Jesus, it is he;
Lord Sabbaoth, his name,
from age to age the same,
and he must win the battle.

3.
And though this world, with devils filled,
should threaten to undo us,
we will not fear, for God hath willed
his truth to triumph through us.
The Prince of Darkness grim,
we tremble not for him;
his rage we can endure,
for lo, his doom is sure;
one little word shall fell him.

4.
That word above all earthly powers,
no thanks to them, abideth;
the Spirit and the gifts are ours,
thru him who with us sideth.
Let goods and kindred go,
this mortal life also;
the body they may kill;
God’s truth abideth still;
his kingdom is forever.



```

- |   -  |
-------------|------------|
Title | A Mighty Fortress |
Key |  |
Titles | undefined |
First Line | A mighty fortress is our God, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
