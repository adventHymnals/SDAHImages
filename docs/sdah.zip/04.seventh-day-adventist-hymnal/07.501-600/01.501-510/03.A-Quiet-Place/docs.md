---
title: 503. A Quiet Place - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 503. A Quiet Place. 1. There is a quiet place, Far from the rapid pace where God can soothe my troubled mind. Sheltered by tree and flow’r, There in my quiet hour with Him my cares are left behind. Whether a garden small, Or on a mountain tall, New strength and courage there I find; Then from this quiet place I go prepared to face a new day With love for all mankind.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, A Quiet Place, There is a quiet place, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 503. A QUIET PLACE
#### Seventh Day Adventist Hymnal

```txt



1.
There is a quiet place,
Far from the rapid pace where God can soothe my troubled mind.
Sheltered by tree and flow’r,
There in my quiet hour with Him my cares are left behind.
Whether a garden small,
Or on a mountain tall,
New strength and courage there I find;
Then from this quiet place
I go prepared to face a new day
With love for all mankind.



```

- |   -  |
-------------|------------|
Title | A Quiet Place |
Key |  |
Titles | undefined |
First Line | There is a quiet place, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
