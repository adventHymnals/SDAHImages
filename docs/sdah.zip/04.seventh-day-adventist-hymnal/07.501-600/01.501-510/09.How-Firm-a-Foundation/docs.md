---
title: 509. How Firm a Foundation - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 509. How Firm a Foundation. 1. How firm a foundation, ye saints of the Lord, is laid for your faith in his excellent word! What more can he say than to you he hath said, to you who for refuge to Jesus have fled?
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, How Firm a Foundation, How firm a foundation, ye saints of the Lord, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 509. HOW FIRM A FOUNDATION
#### Seventh Day Adventist Hymnal

```txt



1.
How firm a foundation, ye saints of the Lord,
is laid for your faith in his excellent word!
What more can he say than to you he hath said,
to you who for refuge to Jesus have fled?

2.
“Fear not, I am with thee, O be not dismayed,
for I am thy God and will still give thee aid;
I’ll strengthen and help thee, and cause thee to stand
upheld by my righteous, omnipotent hand.”

3.
“When through deep waters I call thee to go,
the rivers of woe shall not thee overflow;
for I will be with thee, thy troubles to bless,
and sanctify to thee thy deepest distress.”

4.
“When through fiery trials thy pathways shall lie,
my grace, all-sufficient, shall be thy supply;
the flame shall not hurt thee; I only design
thy dross to consume, and thy gold to refine.”

5.
“The soul that on Jesus hath leaned for respose,
I will not, I will not depart to His foes;
That soul, though all hell should endeavor to shake,
I’ll never, no never, no never forsake!”



```

- |   -  |
-------------|------------|
Title | How Firm a Foundation |
Key |  |
Titles | undefined |
First Line | How firm a foundation, ye saints of the Lord, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
