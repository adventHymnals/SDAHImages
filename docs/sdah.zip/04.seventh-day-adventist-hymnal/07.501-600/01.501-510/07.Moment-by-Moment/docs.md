---
title: 507. Moment by Moment - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 507. Moment by Moment. 1. Dying with Jesus, by death reckoned mine, Living with Jesus, a new life divine, Looking to Jesus till glory doth shine, Moment by moment, O Lord, I am Thine. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Moment by Moment, Dying with Jesus, by death reckoned mine, ,Moment by moment I’m kept in His love;
    author: Brian Onang'o
---

#### Advent Hymnals
## 507. MOMENT BY MOMENT
#### Seventh Day Adventist Hymnal

```txt



1.
Dying with Jesus, by death reckoned mine,
Living with Jesus, a new life divine,
Looking to Jesus till glory doth shine,
Moment by moment, O Lord, I am Thine.


Refrain:
Moment by moment I’m kept in His love;
Moment by moment I’ve life from above;
Looking to Jesus till glory doth shine;
Moment by moment, O Lord, I am Thine.


2.
Never a trial that He is not there,
Never a burden that He doth not bear,
Never a sorrow that He doth not share,
Moment by moment I’m under His care.


Refrain:
Moment by moment I’m kept in His love;
Moment by moment I’ve life from above;
Looking to Jesus till glory doth shine;
Moment by moment, O Lord, I am Thine.

3.
Never a heart-ache, and never a groan,
Never a teardrop and never a moan;
Never a danger but there on teh throne,
Moment by moment He thinks of His own.


Refrain:
Moment by moment I’m kept in His love;
Moment by moment I’ve life from above;
Looking to Jesus till glory doth shine;
Moment by moment, O Lord, I am Thine.

4.
Never a weakness that He doth not feel,
Never a sickness that He cannot heal;
Moment by moment, in woe or in weal,
Jesus, my Savior, abides with me still.

Refrain:
Moment by moment I’m kept in His love;
Moment by moment I’ve life from above;
Looking to Jesus till glory doth shine;
Moment by moment, O Lord, I am Thine.




```

- |   -  |
-------------|------------|
Title | Moment by Moment |
Key |  |
Titles | Moment by moment I’m kept in His love; |
First Line | Dying with Jesus, by death reckoned mine, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
