---
title: 505. I Need the Prayers - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 505. I Need the Prayers. 1. I need the prayers of those I love, While trav’ling o’er life’s rugged way, That I may true and faithful be, And live for Jesus every day. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Need the Prayers, I need the prayers of those I love, ,I want my friends to pray for me,
    author: Brian Onang'o
---

#### Advent Hymnals
## 505. I NEED THE PRAYERS
#### Seventh Day Adventist Hymnal

```txt



1.
I need the prayers of those I love,
While trav’ling o’er life’s rugged way,
That I may true and faithful be,
And live for Jesus every day.


Refrain:
I want my friends to pray for me,
To bear my tempted soul above,
And intercede with God for me;
I need the prayers of those I love.


2.
I need the prayers of those I love,
To help me in each trying hour,
To bear my tempted sould to Him,
That He may keep me by His pow’r.


Refrain:
I want my friends to pray for me,
To bear my tempted soul above,
And intercede with God for me;
I need the prayers of those I love.

Refrain:
I want my friends to pray for me,
To hold me up on wing of faith,
That I may walk the narrow way,
Kept by our Father’s glorious grace.



```

- |   -  |
-------------|------------|
Title | I Need the Prayers |
Key |  |
Titles | I want my friends to pray for me, |
First Line | I need the prayers of those I love, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
