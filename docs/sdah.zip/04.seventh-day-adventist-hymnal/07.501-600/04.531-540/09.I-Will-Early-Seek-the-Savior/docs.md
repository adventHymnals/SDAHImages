---
title: 539. I Will Early Seek the Savior - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 539. I Will Early Seek the Savior. 1. I will early seek the Savior, I will learn of Him each day; I will follow in His footsteps, I will walk the narrow way. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Will Early Seek the Savior, I will early seek the Savior, ,For He loves me, yes, He loves me,
    author: Brian Onang'o
---

#### Advent Hymnals
## 539. I WILL EARLY SEEK THE SAVIOR
#### Seventh Day Adventist Hymnal

```txt



1.
I will early seek the Savior,
I will learn of Him each day;
I will follow in His footsteps,
I will walk the narrow way.


Refrain:
For He loves me, yes, He loves me,
Jesus loves me, this I know.
Jesus loves me, died to save me,
This is why I love Him so.


2.
I will hasten where He bids me,
I am not too young to go
In the pathway where He leadeth,
Not too young His will to know.


Refrain:
For He loves me, yes, He loves me,
Jesus loves me, this I know.
Jesus loves me, died to save me,
This is why I love Him so.

3.
He is standing at the doorway
Of escape from every sin;
I will knock, for He has promised,
He will hear and let me in.

Refrain:
For He loves me, yes, He loves me,
Jesus loves me, this I know.
Jesus loves me, died to save me,
This is why I love Him so.




```

- |   -  |
-------------|------------|
Title | I Will Early Seek the Savior |
Key |  |
Titles | For He loves me, yes, He loves me, |
First Line | I will early seek the Savior, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
