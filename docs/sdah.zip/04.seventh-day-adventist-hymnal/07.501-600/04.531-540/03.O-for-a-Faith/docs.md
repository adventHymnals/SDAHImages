---
title: 533. O for a Faith - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 533. O for a Faith. 1. O, for a faith that will not shrink, Though pressed by many a foe, That will not tremble on the brink of poverty, Of poverty or woe; Of poverty or woe;
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O for a Faith, O, for a faith that will not shrink, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 533. O FOR A FAITH
#### Seventh Day Adventist Hymnal

```txt



1.
O, for a faith that will not shrink,
Though pressed by many a foe,
That will not tremble on the brink of poverty,
Of poverty or woe; Of poverty or woe;

2.
That will not murmur or complain
Beneath the chastening rod,
But in the hour of grief or pain, of grief or pain
Can lean upon its God; Can lean upon its God.

3.
A faith that shines more bright and clear
When tempests rage without;
That when in danger knows no fear, knows of no fear,
In darkness feels no doubt; In darkness feels no doubt.

4.
That bears unmoved the world’s dread frown,
Nor heeds its scornful smile;
That sin’s wild ocean cannot drown, no, cannot drown,
Nor its soft arts beguile; Nor its soft arts beguile.

5.
Lord, give me such a faith as this,
And then, whate’er may come
I’ll taste, e’en here the hallowed bliss, the hallowed bliss
Of an eternal home; Of an eternal home.



```

- |   -  |
-------------|------------|
Title | O for a Faith |
Key |  |
Titles | undefined |
First Line | O, for a faith that will not shrink, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
