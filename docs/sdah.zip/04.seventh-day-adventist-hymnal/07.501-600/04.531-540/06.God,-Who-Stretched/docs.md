---
title: 536. God, Who Stretched - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 536. God, Who Stretched. 1. God, who stretched the spangled heavens Infinite in time and place, Flung the suns in burning radiance Through the silent fields of space; We, Your children in Your likeness, Share inventive powers with You; Great Creator, still creating, Show us what we yet may do.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, God, Who Stretched, God, who stretched the spangled heavens 
    author: Brian Onang'o
---

#### Advent Hymnals
## 536. GOD, WHO STRETCHED
#### Seventh Day Adventist Hymnal

```txt



1.
God, who stretched the spangled heavens
Infinite in time and place,
Flung the suns in burning radiance
Through the silent fields of space;
We, Your children in Your likeness,
Share inventive powers with You;
Great Creator, still creating,
Show us what we yet may do.

2.
We have ventured worlds undreamed of
Since the childhood of our race;
Knowing the ecstasy of winging
Through untraveled realms of space,
Probed the secrets of the atom,
Yielding unimagined power,
Facing us with life’s destruction
Or our most triumphant hour.

3.
As each far horizon beckons,
May it challenge us anew:
Children of creative purpose,
Serving others, honoring You.
May our dreams prove rich with promise;
Each endeavor well begun;
Great Creator, give us guidance
Till our goals and Yours are one.



```

- |   -  |
-------------|------------|
Title | God, Who Stretched |
Key |  |
Titles | undefined |
First Line | God, who stretched the spangled heavens |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
