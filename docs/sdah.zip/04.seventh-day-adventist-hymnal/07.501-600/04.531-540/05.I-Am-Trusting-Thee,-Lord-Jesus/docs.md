---
title: 535. I Am Trusting Thee, Lord Jesus - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 535. I Am Trusting Thee, Lord Jesus. 1. I am trusting Thee, Lord Jesus, Trusting only Thee; Trusting Thee for full salvation, Great and free.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I Am Trusting Thee, Lord Jesus, I am trusting Thee, Lord Jesus, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 535. I AM TRUSTING THEE, LORD JESUS
#### Seventh Day Adventist Hymnal

```txt



1.
I am trusting Thee, Lord Jesus,
Trusting only Thee;
Trusting Thee for full salvation,
Great and free.

2.
I am trusting Thee for pardon;
At Thy feet I bow;
For Thy grace and tender mercy,
Trusting now.

3.
I am trusting Thee to guide me;
Thou alone shalt lead;
Every day and hour supplying
All my need.

4.
I am trusting Thee, Lord Jesus;
Never let me fall;
I am trusting Thee forever,
And for all.



```

- |   -  |
-------------|------------|
Title | I Am Trusting Thee, Lord Jesus |
Key |  |
Titles | undefined |
First Line | I am trusting Thee, Lord Jesus, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
