---
title: 538. Guide Me, O Thou Great Jehovah - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 538. Guide Me, O Thou Great Jehovah. 1. Guide me, O thou great Jehovah, pilgrim through this barren land. I am weak, but thou art mighty; hold me with thy powerful hand. Bread of heaven, bread of heaven, feed me till I want no more; feed me till I want no more.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Guide Me, O Thou Great Jehovah, Guide me, O thou great Jehovah, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 538. GUIDE ME, O THOU GREAT JEHOVAH
#### Seventh Day Adventist Hymnal

```txt



1.
Guide me, O thou great Jehovah,
pilgrim through this barren land.
I am weak, but thou art mighty;
hold me with thy powerful hand.
Bread of heaven, bread of heaven,
feed me till I want no more;
feed me till I want no more.

2.
Open now the crystal fountain,
whence the healing stream doth flow;
let the fire and cloudy pillar
lead me all my journey through.
Strong deliverer, strong deliverer,
be thou still my strength and shield;
be thou still my strength and shield.

3.
When I tread the verge of Jordan,
bid my anxious fears subside;
death of death and hell’s destruction,
land me safe on Canaan’s side.
Songs of praises, songs of praises,
I will ever give to thee;
I will ever give to thee.



```

- |   -  |
-------------|------------|
Title | Guide Me, O Thou Great Jehovah |
Key |  |
Titles | undefined |
First Line | Guide me, O thou great Jehovah, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
