---
title: 537. He Leadeth Me - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 537. He Leadeth Me. 1. He leadeth me: O blessed thought! O words with heavenly comfort fraught! Whate’er I do, where’er I be, still ’tis God’s hand that leadeth me. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, He Leadeth Me, He leadeth me; O blessed thought! ,He leadeth me, he leadeth me,
    author: Brian Onang'o
---

#### Advent Hymnals
## 537. HE LEADETH ME
#### Seventh Day Adventist Hymnal

```txt



1.
He leadeth me: O blessed thought!
O words with heavenly comfort fraught!
Whate’er I do, where’er I be,
still ’tis God’s hand that leadeth me.


Refrain:
He leadeth me, he leadeth me,
by his own hand he leadeth me;
his faithful follower I would be,
for by his hand he leadeth me.


2.
Sometimes mid scenes of deepest gloom,
sometimes where Eden’s bowers bloom,
by waters still, o’er troubled sea,
still ’tis his hand that leadeth me.


Refrain:
He leadeth me, he leadeth me,
by his own hand he leadeth me;
his faithful follower I would be,
for by his hand he leadeth me.

3.
Lord, I would place my hand in thine,
nor ever murmur nor repine;
content, whatever lot I see,
since ’tis my God that leadeth me.


Refrain:
He leadeth me, he leadeth me,
by his own hand he leadeth me;
his faithful follower I would be,
for by his hand he leadeth me.

4.
And when my task on earth is done,
when by thy grace the victory’s won,
e’en death’s cold wave I will not flee,
since God through Jordan leadeth me.

Refrain:
He leadeth me, he leadeth me,
by his own hand he leadeth me;
his faithful follower I would be,
for by his hand he leadeth me.




```

- |   -  |
-------------|------------|
Title | He Leadeth Me |
Key |  |
Titles | He leadeth me, he leadeth me, |
First Line | He leadeth me: O blessed thought! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
