---
title: 540. Gentle Jesus, Meek and Mild - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 540. Gentle Jesus, Meek and Mild. 1. Gentle Jesus, meek and mild, Look upon a little child; Pity my simplicity, Suffer me to come to Thee.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Gentle Jesus, Meek and Mild, Gentle Jesus, meek and mild, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 540. GENTLE JESUS, MEEK AND MILD
#### Seventh Day Adventist Hymnal

```txt



1.
Gentle Jesus, meek and mild,
Look upon a little child;
Pity my simplicity,
Suffer me to come to Thee.

2.
Lamb of God, I look to Thee;
Thou shalt my example be;
Thou art gentle, meek, and mild,
Thou wast once a little child.

3.
Fain I would be as Thou art;
Give me Thy obedient heart;
Thou art pitiful and kind,
Let me have Thy loving mind.

4.
I shall then show forth Thy praise,
Serve Thee all my happy days;
Then the world shall always see
Christ, the Holy Child, in me.



```

- |   -  |
-------------|------------|
Title | Gentle Jesus, Meek and Mild |
Key |  |
Titles | undefined |
First Line | Gentle Jesus, meek and mild, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
