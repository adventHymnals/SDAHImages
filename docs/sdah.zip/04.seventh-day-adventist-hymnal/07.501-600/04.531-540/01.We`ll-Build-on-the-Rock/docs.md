---
title: 531. We`ll Build on the Rock - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 531. We`ll Build on the Rock. 1. We’ll build on the Rock, the living Rock, On Jesus, the Rock of Ages; So shall we abide the fearful shock, When loud the tempest rages. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, We`ll Build on the Rock, We’ll build on the Rock, the living Rock, ,We’ll build on the Rock,
    author: Brian Onang'o
---

#### Advent Hymnals
## 531. WE`LL BUILD ON THE ROCK
#### Seventh Day Adventist Hymnal

```txt



1.
We’ll build on the Rock, the living Rock,
On Jesus, the Rock of Ages;
So shall we abide the fearful shock,
When loud the tempest rages.


Refrain:
We’ll build on the Rock,
We’ll build on the Rock;
We’ll build on the Rock, on the solid Rock,
On Christ, the mighty Rock.


2.
Some build on the sinking sands of life,
On visions of earthly treasure;
Some build on the waves of sin and strife,
Of fame, and worldly pleasure.


Refrain:
We’ll build on the Rock,
We’ll build on the Rock;
We’ll build on the Rock, on the solid Rock,
On Christ, the mighty Rock.

3.
O build on the Rock, for ever sure,
The firm and the true foundation;
Its hope is the hope which shall endure,
The hope of our salvation.

Refrain:
We’ll build on the Rock,
We’ll build on the Rock;
We’ll build on the Rock, on the solid Rock,
On Christ, the mighty Rock.




```

- |   -  |
-------------|------------|
Title | We`ll Build on the Rock |
Key |  |
Titles | We’ll build on the Rock, |
First Line | We’ll build on the Rock, the living Rock, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
