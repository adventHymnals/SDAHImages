---
title: 575. Let Your Heart Be Broken - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 575. Let Your Heart Be Broken. 1. Let your heart be broken for a world in need: Feed the mouths that hunger, soothe the wounds that bleed, Give the cup of water and the loaf of bread Be the hands of Jesus, serving in His stead.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Let Your Heart Be Broken, Let your heart be broken for a world in need; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 575. LET YOUR HEART BE BROKEN
#### Seventh Day Adventist Hymnal

```txt



1.
Let your heart be broken for a world in need:
Feed the mouths that hunger, soothe the wounds that bleed,
Give the cup of water and the loaf of bread
Be the hands of Jesus, serving in His stead.

2.
Here on earth applying principles of love,
Visible expression – God still rules above
Living illustration of the Living Word
To the minds of all who’ve Never seen or heard.

3.
Blest to be a blessing privileged to care,
Challenged by the need apparent everywhere.
Where mankind is wanting, fill the vacant place.
Be the means through which the Lord reveals His grace.

4.
Add to your believing deeds that prove it true,
Knowing Christ as Savior, make Him Master, too.
Follow in His footsteps, go where He has trod;
In the world’s great trouble risk yourself for God.

5.
Let your heart be tender and your vision clear;
See mankind as God sees, serve Him far and near.
Let your heart be broken by a brother’s pain;
Share your rich resources, give and give again.



```

- |   -  |
-------------|------------|
Title | Let Your Heart Be Broken |
Key |  |
Titles | undefined |
First Line | Let your heart be broken for a world in need: |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
