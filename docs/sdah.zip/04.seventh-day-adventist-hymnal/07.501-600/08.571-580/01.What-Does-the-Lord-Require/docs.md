---
title: 571. What Does the Lord Require? - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 571. What Does the Lord Require?. 1. What does the Lord require for praise and offering? What sacrifice, desire or tribute bid you bring? Do justly; Love mercy; Walk humbly with your God.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, What Does the Lord Require?, What does the Lord require for praise and offering? 
    author: Brian Onang'o
---

#### Advent Hymnals
## 571. WHAT DOES THE LORD REQUIRE?
#### Seventh Day Adventist Hymnal

```txt



1.
What does the Lord require for praise and offering?
What sacrifice, desire or tribute bid you bring?
Do justly; Love mercy; Walk humbly with your God.

2.
Rulers of men, give ear! Should you not justice show?
Will God your pleading hear, while crime and cruelty grow?
Do justly; Love mercy; Walk humbly with your God.

3.
How shall our life fulfill God’s law so hard and high?
Let Christ endue our will with grace to fortify.
Then justly, in mercy we’ll humbly walk with God.



```

- |   -  |
-------------|------------|
Title | What Does the Lord Require? |
Key |  |
Titles | undefined |
First Line | What does the Lord require for praise and offering? |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
