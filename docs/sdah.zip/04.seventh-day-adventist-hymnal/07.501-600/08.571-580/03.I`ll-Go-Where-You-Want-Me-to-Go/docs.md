---
title: 573. I`ll Go Where You Want Me to Go - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 573. I`ll Go Where You Want Me to Go. 1. It may not be on the mountain height Or over the stormy sea, It may not be at the battle’s front My Lord will have need of me. But if, by a still, small voice he calls To paths that I do not know, I’ll answer, dear Lord, with my hand in thine; I’ll go where you want me to go. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, I`ll Go Where You Want Me to Go, It may not be on the mountain height ,I’ll go where you want me to go, dear Lord,
    author: Brian Onang'o
---

#### Advent Hymnals
## 573. I`LL GO WHERE YOU WANT ME TO GO
#### Seventh Day Adventist Hymnal

```txt



1.
It may not be on the mountain height
Or over the stormy sea,
It may not be at the battle’s front
My Lord will have need of me.
But if, by a still, small voice he calls
To paths that I do not know,
I’ll answer, dear Lord, with my hand in thine;
I’ll go where you want me to go.


Refrain:
I’ll go where you want me to go, dear Lord,
Over mountain or plain or sea;
I’ll say what you want me to say, dear Lord;
I’ll be what you want me to be.


2.
Perhaps today there are loving words
Which Jesus would have me speak
There may be now in the paths of sin
Some wand’rer whom I should seek.
O Savior, if thou wilt be my guide,
Tho dark and rugged the way,
My voice shall echo the message sweet;
I’ll say what you want me to say.


Refrain:
I’ll go where you want me to go, dear Lord,
Over mountain or plain or sea;
I’ll say what you want me to say, dear Lord;
I’ll be what you want me to be.

3.
There’s surely somewhere a lowly place
In earth’s harvest fields so wide
Where I may labor through life’s short day
For Jesus, the Crucified.
So trusting my all to thy tender care,
And knowing thou lovest me,
I’ll do thy will with a heart sincere:
I’ll be what you want me to be.

Refrain:
I’ll go where you want me to go, dear Lord,
Over mountain or plain or sea;
I’ll say what you want me to say, dear Lord;
I’ll be what you want me to be.




```

- |   -  |
-------------|------------|
Title | I`ll Go Where You Want Me to Go |
Key |  |
Titles | I’ll go where you want me to go, dear Lord, |
First Line | It may not be on the mountain height |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
