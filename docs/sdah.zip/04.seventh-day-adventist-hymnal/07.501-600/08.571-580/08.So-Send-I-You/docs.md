---
title: 578. So Send I You - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 578. So Send I You. 1. So sent I you- by grace made strong to triumph O’er hosts of hell, o’er darkness, death, and sin, My name to bear, and in that name to conquer- So send I you, My victory to win.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, So Send I You, So sent I you- by grace made strong to triumph 
    author: Brian Onang'o
---

#### Advent Hymnals
## 578. SO SEND I YOU
#### Seventh Day Adventist Hymnal

```txt



1.
So sent I you- by grace made strong to triumph
O’er hosts of hell, o’er darkness, death, and sin,
My name to bear, and in that name to conquer-
So send I you, My victory to win.

2.
So send I you- to take to souls in bondage
The word of truth that sets the captive fee,
To break the bonds of sin, to loose dearth’s fetters-
So send I you, to bring the lost to Me.

3.
So send I you- My strength to know in weakness,
My joy in grief, my perfect peace in pain,
To prove My power, My grace, My promised presence-
So send I you, eternal fruit to gain.

4.
So Send I you – to bear My cross with patience,
And then one day with joy to lay it down
To hear My voice, “Well done, My faithful servant –
Come, share My throne, My Kingdom, and My crown!”
As the Father hath sent Me, so send I You.”



```

- |   -  |
-------------|------------|
Title | So Send I You |
Key |  |
Titles | undefined |
First Line | So sent I you- by grace made strong to triumph |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
