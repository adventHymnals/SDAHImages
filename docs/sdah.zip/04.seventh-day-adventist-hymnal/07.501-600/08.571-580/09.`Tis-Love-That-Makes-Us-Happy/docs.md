---
title: 579. `Tis Love That Makes Us Happy - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 579. `Tis Love That Makes Us Happy. 1. 'Tis love that makes us happy, 'Tis love that smooths the way; It helps us "mind," it makes us kind To others ev'ry day. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, `Tis Love That Makes Us Happy, 'Tis love that makes us happy, ,God is love; we're his little children.
    author: Brian Onang'o
---

#### Advent Hymnals
## 579. `TIS LOVE THAT MAKES US HAPPY
#### Seventh Day Adventist Hymnal

```txt



1.
'Tis love that makes us happy,
'Tis love that smooths the way;
It helps us "mind," it makes us kind
To others ev'ry day.

Refrain:
God is love; we're his little children.
God is love; we would be like him.
'Tis love that makes us happy,
'Tis love that smooths the way;
It helps us "mind," it makes us kind
To others ev'ry day.

2.
This world is full of sorrow,
Of sickness, death, and sin;
With loving heart we'll do our part,
And try some soul to win. 

Refrain:
God is love; we're his little children.
God is love; we would be like him.
'Tis love that makes us happy,
'Tis love that smooths the way;
It helps us "mind," it makes us kind
To others ev'ry day.


3.
And when this life is over,
And we are called above,
Our song shall be, eternally,
Of Jesus and his love. 

Refrain:
God is love; we're his little children.
God is love; we would be like him.
'Tis love that makes us happy,
'Tis love that smooths the way;
It helps us "mind," it makes us kind
To others ev'ry day.



```

- |   -  |
-------------|------------|
Title | `Tis Love That Makes Us Happy |
Key |  |
Titles | God is love; we're his little children. |
First Line | 'Tis love that makes us happy, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
