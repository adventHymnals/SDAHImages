---
title: 577. In the Heart of Jesus - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 577. In the Heart of Jesus. 1. In the heart of Jesus there is love for you, Love most pure and tender, love most deep and true; Why should you be lonely, why for friendship sigh, When the heart of Jesus has a full supply?
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, In the Heart of Jesus, In the heart of Jesus there is love for you, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 577. IN THE HEART OF JESUS
#### Seventh Day Adventist Hymnal

```txt



1.
In the heart of Jesus there is love for you,
Love most pure and tender, love most deep and true;
Why should you be lonely, why for friendship sigh,
When the heart of Jesus has a full supply?

2.
In the mind of Jesus there is thought for you,
Warm as summer sunshine, sweet as morning dew;
Why should you be fearful, why take anxious thought,
Since the mind of Jesus cares for those He bought?

3.
In the field of Jesus there is work for you;
Such as even angels might rejoice to do;
Why stand idly sighing for some lifework grand,
While the field of Jesus seeks your reaping hand?

4.
In the home of Jesus there’s a place for you;
Glorious, bright, and joyous, calm and peaceful too;
Why then, like a wanderer, roam with weary pace,
If the home of Jesus holds for you a place?



```

- |   -  |
-------------|------------|
Title | In the Heart of Jesus |
Key |  |
Titles | undefined |
First Line | In the heart of Jesus there is love for you, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
