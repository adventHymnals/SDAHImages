---
title: 576. Awake, Awake to Love and Work - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 576. Awake, Awake to Love and Work. 1. Awake, awake to love and work! The lark is in the sky; The fields are wet with diamond dew; The worlds awake to cry Their blessings on the Lord of life, As He goes meekly by.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Awake, Awake to Love and Work, Awake, awake to love and work! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 576. AWAKE, AWAKE TO LOVE AND WORK
#### Seventh Day Adventist Hymnal

```txt



1.
Awake, awake to love and work!
The lark is in the sky;
The fields are wet with diamond dew;
The worlds awake to cry
Their blessings on the Lord of life,
As He goes meekly by.

2.
Come, let thy voice be one with theirs,
Shout with their shout of praise;
See how the giant sun soars up,
Great lord of years and days!
So let the love of Jesus come
And set thy soul ablaze.

3.
To give and give, and give again,
What God hath given thee;
To spend thyself nor count the cost;
To serve right gloriously
The God who gave all worlds that are,
And all that are to be.



```

- |   -  |
-------------|------------|
Title | Awake, Awake to Love and Work |
Key |  |
Titles | undefined |
First Line | Awake, awake to love and work! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
