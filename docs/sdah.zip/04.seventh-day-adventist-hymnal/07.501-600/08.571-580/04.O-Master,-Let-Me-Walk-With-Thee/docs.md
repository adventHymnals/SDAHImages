---
title: 574. O Master, Let Me Walk With Thee - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 574. O Master, Let Me Walk With Thee. 1. O Master, let me walk with thee in lowly paths of service free; tell me thy secret; help me bear the strain of toil, the fret of care.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Master, Let Me Walk With Thee, O Master, let me walk with thee 
    author: Brian Onang'o
---

#### Advent Hymnals
## 574. O MASTER, LET ME WALK WITH THEE
#### Seventh Day Adventist Hymnal

```txt



1.
O Master, let me walk with thee
in lowly paths of service free;
tell me thy secret; help me bear
the strain of toil, the fret of care.

2.
Help me the slow of heart to move
by some clear, winning word of love;
teach me the wayward feet to stay,
and guide them in the homeward way.

3.
Teach me thy patience; still with thee
in closer, dearer company,
in work that keeps faith sweet and strong,
in trust that triumphs over wrong;

4.
In hope that sends a shining ray
far down the future’s broadening way,
in peace that only thou canst give,
with thee, O Master, let me live.



```

- |   -  |
-------------|------------|
Title | O Master, Let Me Walk With Thee |
Key |  |
Titles | undefined |
First Line | O Master, let me walk with thee |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
