---
title: 572. Give of Your Best to the Master - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 572. Give of Your Best to the Master. 1. Give of your best to the master, Give of the strength of your youth; Throw your soul’s fresh, glowing ardor Into the battle for truth. Jesus has set the example – Dauntless was He, young and brave; Give Him your loyal devotion, Give Him the best that you have. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Give of Your Best to the Master, Give of your best to the master, ,Give of your best to the master,
    author: Brian Onang'o
---

#### Advent Hymnals
## 572. GIVE OF YOUR BEST TO THE MASTER
#### Seventh Day Adventist Hymnal

```txt



1.
Give of your best to the master,
Give of the strength of your youth;
Throw your soul’s fresh, glowing ardor
Into the battle for truth.
Jesus has set the example –
Dauntless was He, young and brave;
Give Him your loyal devotion,
Give Him the best that you have.


Refrain:
Give of your best to the master,
Give of the strength of your youth;
Clad in salvation’s full armor,
Join in the battle for truth.


2.
Give of your best to the Master,
Give Him first place in your heart;
Give Him first place in your service,
Consecrate every part.
Give, and to you shall be given –
God His beloved Son gave;
Gratefully seeking to serve Him,
Give Him the best that you have.


Refrain:
Give of your best to the master,
Give of the strength of your youth;
Clad in salvation’s full armor,
Join in the battle for truth.

3.
Give of your best to the Master,
Naught else is worthy His love;
He gave Himself for your ransom,
Have up His glory above;
Laid down His life without murmur,
You from sin’s ruin to save;
Give Him your heart’s adoration,
Give Him the best that you have.

Refrain:
Give of your best to the master,
Give of the strength of your youth;
Clad in salvation’s full armor,
Join in the battle for truth.




```

- |   -  |
-------------|------------|
Title | Give of Your Best to the Master |
Key |  |
Titles | Give of your best to the master, |
First Line | Give of your best to the master, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
