---
title: 580. This Little Light of Mine - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 580. This Little Light of Mine. 1. This little light of mine, I’m going to let it shine, (shine) This little light of mine, I’m going to let it shine, (shine) This little light of mine, I’m going to let it shine, Let it shine, let it shine, let it shine.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, This Little Light of Mine, This little light of mine, I’m going to let it shine, (shine) 
    author: Brian Onang'o
---

#### Advent Hymnals
## 580. THIS LITTLE LIGHT OF MINE
#### Seventh Day Adventist Hymnal

```txt



1.
This little light of mine, I’m going to let it shine, (shine)
This little light of mine, I’m going to let it shine, (shine)
This little light of mine, I’m going to let it shine,
Let it shine, let it shine, let it shine.

2.
Every where I go, I’m going to let it shine, (shine)
Every where I go, I’m going to let it shine, (shine)
Every where I go, I’m going to let it shine,
Let it shine, let it shine, let it shine.

3.
All through the night, I’m going to let it shine, (shine)
All through the night, I’m going to let it shine, (shine)
All through the night, I’m going to let it shine,
Let it shine, let it shine, let it shine.



```

- |   -  |
-------------|------------|
Title | This Little Light of Mine |
Key |  |
Titles | undefined |
First Line | This little light of mine, I’m going to let it shine, (shine) |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
