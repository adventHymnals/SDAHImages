---
title: 593. In Times Like These - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 593. In Times Like These. 1. In times like these you need a Savior, In times like these you need and anchor; Be very sure, be very sure Your anchor holds and grips the Solid rock! This Rock is Jesus, Yes, He’s the One; This Rock is Jesus, The only One! Be very sure, be very sure Your anchor holds and grips the Solid rock!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, In Times Like These, In times like these you need a Savior, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 593. IN TIMES LIKE THESE
#### Seventh Day Adventist Hymnal

```txt



1.
In times like these you need a Savior,
In times like these you need and anchor;
Be very sure, be very sure Your anchor holds and grips the Solid rock!
This Rock is Jesus, Yes, He’s the One;
This Rock is Jesus, The only One!
Be very sure, be very sure Your anchor holds and grips the Solid rock!

2.
In times like these you need the Bible,
In times like these O be not idle;
Be very sure, be very sure Your anchor holds and grips the Solid rock!
This Rock is Jesus, Yes, He’s the One;
This Rock is Jesus, The only One!
Be very sure, be very sure Your anchor holds and grips the Solid rock!

3.
In times like these I have a Savior,
In times like these I have an anchor
I’m very sure, be very sure Your anchor holds and grips the Solid rock!
This Rock is Jesus, Yes, He’s the One;
This Rock is Jesus, The only One!
I’m very sure, be very sure Your anchor holds and grips the Solid rock!



```

- |   -  |
-------------|------------|
Title | In Times Like These |
Key |  |
Titles | undefined |
First Line | In times like these you need a Savior, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
