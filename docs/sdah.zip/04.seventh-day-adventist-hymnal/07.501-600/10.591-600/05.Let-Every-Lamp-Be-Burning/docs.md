---
title: 595. Let Every Lamp Be Burning - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 595. Let Every Lamp Be Burning. 1. Let every lamp be burning bright, The darkest hour is nearing; The darkest hour of earth’s long night, Before the Lord’s appearing. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Let Every Lamp Be Burning, Let every lamp be burning bright, ,Then trim your lamps, my brethren dear,
    author: Brian Onang'o
---

#### Advent Hymnals
## 595. LET EVERY LAMP BE BURNING
#### Seventh Day Adventist Hymnal

```txt



1.
Let every lamp be burning bright,
The darkest hour is nearing;
The darkest hour of earth’s long night,
Before the Lord’s appearing.


Refrain:
Then trim your lamps, my brethren dear,
Then trim your lamps with godly fear;
The Master’s coming draweth near,
Let every lamp be burning.


2.
Though thousands calmly slumber on,
The last great message spuring,
Wel’ll rest our living faith upon
His promise of returning.


Refrain:
Then trim your lamps, my brethren dear,
Then trim your lamps with godly fear;
The Master’s coming draweth near,
Let every lamp be burning.

3.
His word our lamp, His truth our guide,
We cannot be mistaken;
Though dangers rise on every side,
We shall not be forsaken.


Refrain:
Then trim your lamps, my brethren dear,
Then trim your lamps with godly fear;
The Master’s coming draweth near,
Let every lamp be burning.

4.
Then let good works with faith appear,
To help the world atound us;
Obedience bring the blessing near
When faith has firmly bound us.

Refrain:
Then trim your lamps, my brethren dear,
Then trim your lamps with godly fear;
The Master’s coming draweth near,
Let every lamp be burning.




```

- |   -  |
-------------|------------|
Title | Let Every Lamp Be Burning |
Key |  |
Titles | Then trim your lamps, my brethren dear, |
First Line | Let every lamp be burning bright, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
