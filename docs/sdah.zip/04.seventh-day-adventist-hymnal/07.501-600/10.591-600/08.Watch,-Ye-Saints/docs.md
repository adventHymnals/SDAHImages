---
title: 598. Watch, Ye Saints - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 598. Watch, Ye Saints. 1. Watch, ye saints, with eyelids waking; Lo! The powers of heaven are shaking; Keep your lamps all trimmed an burning, Ready for your Lord’s returning. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Watch, Ye Saints, Watch, ye saints, with eyelids waking; ,Lo! He comes, lo! Jesus comes;
    author: Brian Onang'o
---

#### Advent Hymnals
## 598. WATCH, YE SAINTS
#### Seventh Day Adventist Hymnal

```txt



1.
Watch, ye saints, with eyelids waking;
Lo! The powers of heaven are shaking;
Keep your lamps all trimmed an burning,
Ready for your Lord’s returning.


Refrain:
Lo! He comes, lo! Jesus comes;
Lo! He come, He comes all glorious!
Jesus comes to reign victorious,
Lo! He comes, yes, Jesus comes.


2.
Lo! the promise of your Savior,
Pardoned sin and purchased favor,
Blood-washed robes and crowns of glory;
Haste to tell redemption’s story.


Refrain:
Lo! He comes, lo! Jesus comes;
Lo! He come, He comes all glorious!
Jesus comes to reign victorious,
Lo! He comes, yes, Jesus comes.

3.
Kingdoms at their base are crumbling,
Hark! His chariot wheels are rumbling;
Tell, O tell of grace abounding,
While the seventh trump is sounding.


Refrain:
Lo! He comes, lo! Jesus comes;
Lo! He come, He comes all glorious!
Jesus comes to reign victorious,
Lo! He comes, yes, Jesus comes.

4.
Nations wane, though proud and stately;
Christ His kingdom hasteneth greatly;
Earth her latest pangs is summing;
Shout, ye saints, your Lord is coming.


Refrain:
Lo! He comes, lo! Jesus comes;
Lo! He come, He comes all glorious!
Jesus comes to reign victorious,
Lo! He comes, yes, Jesus comes.

5.
Sinners, come, while Christ is pleading;
Now for you He’s interceding;
Haste, ere grace and time diminished
Shall proclaim the mystery finished.

Refrain:
Lo! He comes, lo! Jesus comes;
Lo! He come, He comes all glorious!
Jesus comes to reign victorious,
Lo! He comes, yes, Jesus comes.




```

- |   -  |
-------------|------------|
Title | Watch, Ye Saints |
Key |  |
Titles | Lo! He comes, lo! Jesus comes; |
First Line | Watch, ye saints, with eyelids waking; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
