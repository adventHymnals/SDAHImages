---
title: 597. Ye Servants of the Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 597. Ye Servants of the Lord. 1. Ye servants of the Lord, Each in his office wait, Observant of His heavenly Word, And watchful at His gate.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Ye Servants of the Lord, Ye servants of the Lord, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 597. YE SERVANTS OF THE LORD
#### Seventh Day Adventist Hymnal

```txt



1.
Ye servants of the Lord,
Each in his office wait,
Observant of His heavenly Word,
And watchful at His gate.

2.
Let all your lamps be bright,
And trim the golden flame,
Gird up your loins as in His sight,
His coming thus proclaim.

3.
Watch, ’tis your Lord’s command,
And while we speak He’s near;
Mark the first signal of His hand,
And ready all appear.

4.
O happy servant, he,
In such a posture found!
He shall His Lord with rapture see,
And be with honor crowned.



```

- |   -  |
-------------|------------|
Title | Ye Servants of the Lord |
Key |  |
Titles | undefined |
First Line | Ye servants of the Lord, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
