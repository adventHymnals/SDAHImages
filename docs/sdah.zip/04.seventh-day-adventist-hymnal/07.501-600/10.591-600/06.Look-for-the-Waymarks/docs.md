---
title: 596. Look for the Waymarks - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 596. Look for the Waymarks. 1. Look for the way-marks as you journey on, Look for the way-marks passing one by one; Down through the ages, past the kingdoms four— Where are we standing? Look the way-marks o’er. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Look for the Waymarks, Look for the way-marks as you journey on, ,Look for the way-marks, the great prophetic way-marks,
    author: Brian Onang'o
---

#### Advent Hymnals
## 596. LOOK FOR THE WAYMARKS
#### Seventh Day Adventist Hymnal

```txt



1.
Look for the way-marks as you journey on,
Look for the way-marks passing one by one;
Down through the ages, past the kingdoms four—
Where are we standing? Look the way-marks o’er.


Refrain:
Look for the way-marks, the great prophetic way-marks,
Down through the ages, past the kingdoms four.
Look for the waymarks, the great prophetic way-marks;
The journey’s almost o’er.


2.
First, the Assyrian kingdom ruled the world,
Then Medo-Persia’s banners were unfurled;
And after Greece held universal sway,
Rome seized the scepter—where are we today?


Refrain:
Look for the way-marks, the great prophetic way-marks,
Down through the ages, past the kingdoms four.
Look for the waymarks, the great prophetic way-marks;
The journey’s almost o’er.

3.
Down in the feet of iron and of clay,
Weak and divided, soon to pass away;
What will the next great, glorious drama be?
Christ and His coming, and eternity.

Refrain:
Look for the way-marks, the great prophetic way-marks,
Down through the ages, past the kingdoms four.
Look for the waymarks, the great prophetic way-marks;
The journey’s almost o’er.




```

- |   -  |
-------------|------------|
Title | Look for the Waymarks |
Key |  |
Titles | Look for the way-marks, the great prophetic way-marks, |
First Line | Look for the way-marks as you journey on, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
