---
title: 600. Hold Fast Till I Come - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 600. Hold Fast Till I Come. 1. Sweet promise is given to all who believe– “Behold I come quickly, Mine own to receive; Hold fast till I come; the danger is great; Sleep not as do others; be watchful, and wait.” 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Hold Fast Till I Come, Sweet promise is given to all who believe– ,“Hold fast till I come,” sweet promise of heaven–
    author: Brian Onang'o
---

#### Advent Hymnals
## 600. HOLD FAST TILL I COME
#### Seventh Day Adventist Hymnal

```txt



1.
Sweet promise is given to all who believe–
“Behold I come quickly, Mine own to receive;
Hold fast till I come; the danger is great;
Sleep not as do others; be watchful, and wait.”


Refrain:
“Hold fast till I come,” sweet promise of heaven–
“The kingdom restored, to you shall be given.”
“Come, enter My joy, sit down on the throne;
Bright crowns are in waiting; hold fast till I come.”


2.
We’ll “watch unto prayer” with lamps burning bright;
He comes to all others a “thief in the night.”
We know He is near, but know not the day–
As spring shows that summer is not far away.


Refrain:
“Hold fast till I come,” sweet promise of heaven–
“The kingdom restored, to you shall be given.”
“Come, enter My joy, sit down on the throne;
Bright crowns are in waiting; hold fast till I come.”

3.
Yes! this is our hope, ’tis built on His word–
The glorious appearing of Jesus, our Lord;
Of promises all, it stands as the sum:
“Behold I come quickly; hold fast till I come.”

Refrain:
“Hold fast till I come,” sweet promise of heaven–
“The kingdom restored, to you shall be given.”
“Come, enter My joy, sit down on the throne;
Bright crowns are in waiting; hold fast till I come.”




```

- |   -  |
-------------|------------|
Title | Hold Fast Till I Come |
Key |  |
Titles | “Hold fast till I come,” sweet promise of heaven– |
First Line | Sweet promise is given to all who believe– |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
