---
title: 591. In Our Work and in Our Play - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 591. In Our Work and in Our Play. 1. In our work and in our play, Jesus, ever with us stay; May be always strive to be True and faithful unto Thee. Then we truthfully can sing, We are children of the King.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, In Our Work and in Our Play, In our work and in our play, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 591. IN OUR WORK AND IN OUR PLAY
#### Seventh Day Adventist Hymnal

```txt



1.
In our work and in our play,
Jesus, ever with us stay;
May be always strive to be
True and faithful unto Thee.
Then we truthfully can sing,
We are children of the King.

2.
May we in Thy strength subdue
Evil tempers, words untrue,
Thoughts impure, and deeds unkind,
All things hateful to Thy mind.
Then we truthfully can sing,
We are children of the King.

3.
Children of the King are we!
May we loyal to Him be;
Try to please Him every day,
In our work and in our play.
Then we truthfully can sing,
We are children of the King.



```

- |   -  |
-------------|------------|
Title | In Our Work and in Our Play |
Key |  |
Titles | undefined |
First Line | In our work and in our play, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
