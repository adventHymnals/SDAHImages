---
title: 594. Heir of the Kingdom - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 594. Heir of the Kingdom. 1. Heir of the kingdom, O why dost thou slumber? Why art thou sleeping so near thy blest home? Wake thee, arouse thee, and gird on thine armor, Speed, for the moments are hurrying on.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Heir of the Kingdom, Heir of the kingdom, O why dost thou slumber? 
    author: Brian Onang'o
---

#### Advent Hymnals
## 594. HEIR OF THE KINGDOM
#### Seventh Day Adventist Hymnal

```txt



1.
Heir of the kingdom, O why dost thou slumber?
Why art thou sleeping so near thy blest home?
Wake thee, arouse thee, and gird on thine armor,
Speed, for the moments are hurrying on.

2.
Heir of the kingdom, say, why dost thou linger?
How canst thou tarry in sight of the prize?
Up, and adorn thee, the Savior is coming;
Haste to receive Him descending the skies.

3.
Earth’s mighty nations, in strife and commotion,
Tremble with terror, and sink in dismay;
Listen, ’tis nought but the chariot’s loud rumbling;
Heir of the kingdom, no longer delay.

4.
Stay not, O stay not for earth’s vain allurements!
See how its glory is passing away;
Break the strong fetters the foe hath bound o’er thee;
Heir of the kingdom, turn, turn thee away.

5.
Keep the eye single, the head upward lifted;
Watch for the glory of earth’s coming King;
Lo! o’er the mountaintops light is now breaking;
Heirs of the kingdom, rejoice ye and sing.



```

- |   -  |
-------------|------------|
Title | Heir of the Kingdom |
Key |  |
Titles | undefined |
First Line | Heir of the kingdom, O why dost thou slumber? |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
