---
title: 599. Rejoice, Rejoice, Believers - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 599. Rejoice, Rejoice, Believers. 1. Rejoice, rejoice, believers, and let your lights appear: The evening is advancing, and darker night is near. The Bridegroom is arising, and soon He draweth nigh. Up, pray, and watch, and wrestle, at midnight comes the cry.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Rejoice, Rejoice, Believers, Rejoice, rejoice, believers, and let your lights appear; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 599. REJOICE, REJOICE, BELIEVERS
#### Seventh Day Adventist Hymnal

```txt



1.
Rejoice, rejoice, believers, and let your lights appear:
The evening is advancing, and darker night is near.
The Bridegroom is arising, and soon He draweth nigh.
Up, pray, and watch, and wrestle, at midnight comes the cry.

2.
The watchers on the mountain proclaim the Bride-groom near.
Go, meet Him as He cometh, with hallelujahs clear.
The marriage feast is waiting, the gates wide open stand;
Up, up, you heirs of glory, the Bride-groom is at hand.

3.
You saints who here in patience your cross and suff’rings bore,
Shall live and reign forever, when sorrow is no more.
Upon the throne of glory the Lamb you shall behold,
In triumph cast before Him your diadems of gold!

4.
Our hope and expectation, O Jesus, now appear;
Arise, O sun so longed for, o’er this benighted sphere!
With hearts and hands uplifted, we plead, O Lord, to see
The day of earth’s redemption that brings us unto Thee.



```

- |   -  |
-------------|------------|
Title | Rejoice, Rejoice, Believers |
Key |  |
Titles | undefined |
First Line | Rejoice, rejoice, believers, and let your lights appear: |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
