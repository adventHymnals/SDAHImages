---
title: 592. Watchman, Tell Us of the Night - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 592. Watchman, Tell Us of the Night. 1. Watchman, tell us of the night what its signs of promise are. Traveler, o’er yon mountain’s height, see that glory beaming star. Watchman, does its beauteous ray aught of joy or hope foretell? Traveler, yes; it brings the day, promised day of Israel.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Watchman, Tell Us of the Night, Watchman, tell us of the night what its signs of promise are. 
    author: Brian Onang'o
---

#### Advent Hymnals
## 592. WATCHMAN, TELL US OF THE NIGHT
#### Seventh Day Adventist Hymnal

```txt



1.
Watchman, tell us of the night what its signs of promise are.
Traveler, o’er yon mountain’s height, see that glory beaming star.
Watchman, does its beauteous ray aught of joy or hope foretell?
Traveler, yes; it brings the day, promised day of Israel.

2.
Watchman, tell us of the night, higher yet that star ascends.
Traveler, blessedness and light, peace and truth its course portends.
Watchman, will its beams alone gild the spot that gave them birth?
Traveler, ages are its own; See it bursts o’er all the earth.

3.
Watchman, tell us of the night, for the morning seems to dawn.
Traveler, darkness takes its flight, doubt and terror are withdrawn.
Watchman, let your wanderings cease; hasten to your quiet home.
Traveler, lo, the Prince of Peace, lo, the Son of God is come!



```

- |   -  |
-------------|------------|
Title | Watchman, Tell Us of the Night |
Key |  |
Titles | undefined |
First Line | Watchman, tell us of the night what its signs of promise are. |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
