---
title: 561. We Plow the Fields - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 561. We Plow the Fields. 1. We plow the fields, and scatter the good seed on the land, But it is fed and watered by God’s almighty hand. He sends the snow in winter, the warmth to swell the grain, The breezes and the sunshine, and soft refreshing rain. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, We Plow the Fields, We plow the fields, and scatter the good seed on the land, ,All good gifts around us
    author: Brian Onang'o
---

#### Advent Hymnals
## 561. WE PLOW THE FIELDS
#### Seventh Day Adventist Hymnal

```txt



1.
We plow the fields, and scatter the good seed on the land,
But it is fed and watered by God’s almighty hand.
He sends the snow in winter, the warmth to swell the grain,
The breezes and the sunshine, and soft refreshing rain.


Refrain:
All good gifts around us
Are sent from heaven above;
Then thank the Lord, O thank the Lord
For all His love.


2.
He only is the Maker of all things near and far;
He paints the wayside flower, He lights the evening star.
The winds and waves obey Him, by Him the birds are fed;
Much more, to us His children, He gives our daily bread.


Refrain:
All good gifts around us
Are sent from heaven above;
Then thank the Lord, O thank the Lord
For all His love.

3.
We thank Thee then, O Father, for all things bright and good,
The seed-time and the harvest, our life, our health, and food.
Accept the gifts we to offer for all Thy love imparts,
And, what Thou most desirest, our humble, thankful hearts.

Refrain:
All good gifts around us
Are sent from heaven above;
Then thank the Lord, O thank the Lord
For all His love.




```

- |   -  |
-------------|------------|
Title | We Plow the Fields |
Key |  |
Titles | All good gifts around us |
First Line | We plow the fields, and scatter the good seed on the land, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
