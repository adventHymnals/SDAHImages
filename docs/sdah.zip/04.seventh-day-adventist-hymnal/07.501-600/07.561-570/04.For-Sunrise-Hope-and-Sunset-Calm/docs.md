---
title: 564. For Sunrise Hope and Sunset Calm - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 564. For Sunrise Hope and Sunset Calm. 1. For sunrise hope and sunset calm, and all that lies between, For all the sweetness and the balm that is and that has been, For comradeship for peace in strife, and light on darkened days; For work to do and strength for life we sing our hymn of praise.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, For Sunrise Hope and Sunset Calm, For sunrise hope and sunset calm, and all that lies between, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 564. FOR SUNRISE HOPE AND SUNSET CALM
#### Seventh Day Adventist Hymnal

```txt



1.
For sunrise hope and sunset calm, and all that lies between,
For all the sweetness and the balm that is and that has been,
For comradeship for peace in strife, and light on darkened days;
For work to do and strength for life we sing our hymn of praise.

2.
But O, we press far, far above these gifts of pure delight,
And find in Thee, and in Thy love contentment infinite.
O Lord, beloved, in whom are found all joys of time and place,
What will it be when joy is crowned by vision of Thy face?



```

- |   -  |
-------------|------------|
Title | For Sunrise Hope and Sunset Calm |
Key |  |
Titles | undefined |
First Line | For sunrise hope and sunset calm, and all that lies between, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
