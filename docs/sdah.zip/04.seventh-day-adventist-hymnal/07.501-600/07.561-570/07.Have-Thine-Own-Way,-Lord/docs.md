---
title: 567. Have Thine Own Way, Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 567. Have Thine Own Way, Lord. 1. Have thine own way, Lord! Have thine own way! Thou art the potter, I am the clay. Mold me and make me after thy will, while I am waiting, yielded and still.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Have Thine Own Way, Lord, Have thine own way, Lord! Have thine own way! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 567. HAVE THINE OWN WAY, LORD
#### Seventh Day Adventist Hymnal

```txt



1.
Have thine own way, Lord! Have thine own way!
Thou art the potter, I am the clay.
Mold me and make me after thy will,
while I am waiting, yielded and still.

2.
Have thine own way, Lord! Have thine own way!
Search me and try me, Savior today!
Wash me just now, Lord, wash me just now,
as in thy presence humbly I bow.

3.
Have thine own way, Lord! Have thine own way!
Wounded and weary, help me I pray!
Power, all power, surely is thine!
Touch me and heal me, Savior divine!

4.
Have thine own way, Lord! Have thine own way!
Hold o’er my being absolute sway.
Fill with thy Spirit till all shall see
Christ only, always, living in me!



```

- |   -  |
-------------|------------|
Title | Have Thine Own Way, Lord |
Key |  |
Titles | undefined |
First Line | Have thine own way, Lord! Have thine own way! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
