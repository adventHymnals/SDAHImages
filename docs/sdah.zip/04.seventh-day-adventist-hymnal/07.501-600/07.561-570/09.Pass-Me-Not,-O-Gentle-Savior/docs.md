---
title: 569. Pass Me Not, O Gentle Savior - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 569. Pass Me Not, O Gentle Savior. 1. Pass me not, O gentle Savior, hear my humble cry; while on others thou art calling, do not pass me by. 
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Pass Me Not, O Gentle Savior, Pass me not, O gentle Savior, ,Savior, Savior, hear my humble cry;
    author: Brian Onang'o
---

#### Advent Hymnals
## 569. PASS ME NOT, O GENTLE SAVIOR
#### Seventh Day Adventist Hymnal

```txt



1.
Pass me not, O gentle Savior,
hear my humble cry;
while on others thou art calling,
do not pass me by.


Refrain:
Savior, Savior, hear my humble cry;
while on others thou art calling,
do not pass me by.


2.
Let me at thy throne of mercy
find a sweet relief,
kneeling there in deep contrition;
help my unbelief.


Refrain:
Savior, Savior, hear my humble cry;
while on others thou art calling,
do not pass me by.

3.
Trusting only in thy merit,
would I seek thy face;
heal my wounded, broken spirit,
save me by thy grace.


Refrain:
Savior, Savior, hear my humble cry;
while on others thou art calling,
do not pass me by.

4.
Thou the spring of all my comfort,
more than life to me,
whom have I on earth beside thee?
Whom in heaven but thee?

Refrain:
Savior, Savior, hear my humble cry;
while on others thou art calling,
do not pass me by.




```

- |   -  |
-------------|------------|
Title | Pass Me Not, O Gentle Savior |
Key |  |
Titles | Savior, Savior, hear my humble cry; |
First Line | Pass me not, O gentle Savior, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
