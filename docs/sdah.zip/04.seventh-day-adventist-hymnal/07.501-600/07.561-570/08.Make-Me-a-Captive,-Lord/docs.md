---
title: 568. Make Me a Captive, Lord - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 568. Make Me a Captive, Lord. 1. Make me a captive, Lord, and then I shall be free; Force me to render up my sword, and I shall conqueror be. I sink in life’s alarms when by myself I stand; Imprison me within Thine arms, and strong shall be my hand.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Make Me a Captive, Lord, Make me a captive, Lord, and then I shall be free; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 568. MAKE ME A CAPTIVE, LORD
#### Seventh Day Adventist Hymnal

```txt



1.
Make me a captive, Lord, and then I shall be free;
Force me to render up my sword, and I shall conqueror be.
I sink in life’s alarms when by myself I stand;
Imprison me within Thine arms, and strong shall be my hand.

2.
My heart is weak and poor until it amaster find;
It has no spring of action sure, it varies with the wind.
It cannot freely move till Thou has wrought its chain;
Enslave it with Thy matchless love, and deathless it shall reign.

3.
My will is not my own till Thou hast made it Thine;
If it would reach a monarch’s throne, it must its crown resign;
It only stands unbent, amid the clashing strife,
When on Thy bosom it has leant, and found in Thee its life.



```

- |   -  |
-------------|------------|
Title | Make Me a Captive, Lord |
Key |  |
Titles | undefined |
First Line | Make me a captive, Lord, and then I shall be free; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
