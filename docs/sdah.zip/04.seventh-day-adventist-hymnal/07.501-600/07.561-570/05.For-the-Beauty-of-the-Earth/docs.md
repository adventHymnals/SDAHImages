---
title: 565. For the Beauty of the Earth - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 565. For the Beauty of the Earth. 1. For the beauty of the earth, for the glory of the skies, for the love which from our birth over and around us lies; Lord of all, to Thee we raise this our grateful song of praise.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, For the Beauty of the Earth, For the beauty of the earth, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 565. FOR THE BEAUTY OF THE EARTH
#### Seventh Day Adventist Hymnal

```txt



1.
For the beauty of the earth,
for the glory of the skies,
for the love which from our birth
over and around us lies;
Lord of all, to Thee we raise
this our grateful song of praise.

2.
For the joy of human love,
brother, sister, parent, child,
friends on earth and friends above,
Pleasures pure and undefiled,
Lord of all, to Thee we raise
this our grateful song of praise.

3.
For the gift of Thy dear Son,
for the hope of heaven at last,
for the Spirit’s victory won,
For the crown when life is past,
Lord of all, to Thee we raise
Songs of gratitude and praise.



```

- |   -  |
-------------|------------|
Title | For the Beauty of the Earth |
Key |  |
Titles | undefined |
First Line | For the beauty of the earth, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
