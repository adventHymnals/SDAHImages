---
title: 566. Father, We Thank You - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 566. Father, We Thank You. 1. Father, we thank You for the light that shines all the day; For the bright sky You have given most like Your heaven; Father, we thank You.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Father, We Thank You, Father, we thank You for the light that shines all the day; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 566. FATHER, WE THANK YOU
#### Seventh Day Adventist Hymnal

```txt



1.
Father, we thank You for the light that shines all the day;
For the bright sky You have given most like Your heaven;
Father, we thank You.

2.
Father, we thank You for the lamps that lighten the way;
For human skill’s exploration of Your creation;
Father, we thank You.

3.
Father, we thank You for the friends who brighten our play;
For Your command to call others sisters and brothers;
Father, we thank You.

4.
Father, we thank You for Your love in Jesus today,
Giving us hope for tomorrow through joy and sorrow;
Father, we thank You.



```

- |   -  |
-------------|------------|
Title | Father, We Thank You |
Key |  |
Titles | undefined |
First Line | Father, we thank You for the light that shines all the day; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
