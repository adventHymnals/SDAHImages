---
title: 570. Not I, But Christ - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 570. Not I, But Christ. 1. Not I, but Christ, be honored, loved, exalted; Not I, but Christ, be seen, be known, be heard; Not I, but Christ, in every look and action, Not I, but Christ, in every thought and word.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Not I, But Christ, Not I, but Christ, be honored, loved, exalted; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 570. NOT I, BUT CHRIST
#### Seventh Day Adventist Hymnal

```txt



1.
Not I, but Christ, be honored, loved, exalted;
Not I, but Christ, be seen, be known, be heard;
Not I, but Christ, in every look and action,
Not I, but Christ, in every thought and word.

2.
Not I, but Christ, to gently soothe in sorrow,
Not I, but Christ, to wipe the falling tear;
Not I, but Christ, to lift the weary burden,
Not I, but Christ, to hush away all fear.

3.
Christ, only Christ! No idle words e’er falling,
Christ, only Christ; no needless bustling sound;
Christ, only Christ, no self important bearing;
Christ, only Christ, no trace of “I” be found.

4.
Not I, but Christ, my every need supplying,
Not I, but Christ, my strength and health to be;
Christ, only Christ, for body, soul, and spirit,
Christ, only Christ, here and eternally.



```

- |   -  |
-------------|------------|
Title | Not I, But Christ |
Key |  |
Titles | undefined |
First Line | Not I, but Christ, be honored, loved, exalted; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
