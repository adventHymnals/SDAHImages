---
title: 562. Come, Sing a Song of Harvest - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 562. Come, Sing a Song of Harvest. 1. Come, sing a song of harvest, Of thanks for daily food! To offer God the first-fruits is old as gratitude.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Come, Sing a Song of Harvest, Come, sing a song of harvest, Of thanks for daily food! 
    author: Brian Onang'o
---

#### Advent Hymnals
## 562. COME, SING A SONG OF HARVEST
#### Seventh Day Adventist Hymnal

```txt



1.
Come, sing a song of harvest, Of thanks for daily food!
To offer God the first-fruits is old as gratitude.

2.
Long, long ago, the reapers, before they kept the feast,
Put first-fruits in a basket, and took it to the priest.

3.
Shall we, sometimes forgetful oh where creation starts,
With science in our pockets lose wonder from our hearts?

4.
May God, the great Creator, to whom all life belongs,
Accept these gifts we offer, our service and our songs.

5.
And lest the world go hungry while we ourselves are fed,
Make each of us more ready to share our daily bread.



```

- |   -  |
-------------|------------|
Title | Come, Sing a Song of Harvest |
Key |  |
Titles | undefined |
First Line | Come, sing a song of harvest, Of thanks for daily food! |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
