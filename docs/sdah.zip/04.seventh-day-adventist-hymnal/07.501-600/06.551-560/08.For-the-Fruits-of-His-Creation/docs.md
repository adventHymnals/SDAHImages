---
title: 558. For the Fruits of His Creation - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 558. For the Fruits of His Creation. 1. For the fruits of His creation, thanks be to God; For the gifts to every nation, thanks be to God; For the plowing, sowing, reaping, Silent growth while men are sleeping, Future needs in earth’s safe keeping, thanks be to God!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, For the Fruits of His Creation, For the fruits of His creation, thanks be to God; 
    author: Brian Onang'o
---

#### Advent Hymnals
## 558. FOR THE FRUITS OF HIS CREATION
#### Seventh Day Adventist Hymnal

```txt



1.
For the fruits of His creation, thanks be to God;
For the gifts to every nation, thanks be to God;
For the plowing, sowing, reaping,
Silent growth while men are sleeping,
Future needs in earth’s safe keeping, thanks be to God!

2.
In the just reward of labor, God’s will is done;
In the hop we give our neighbor, God’s will is done;
In our worldwide take of caring
For the hungry and despairing,
In the harvests men are sharing, God’s will is done.

3.
For the harvests of His Spirit, thanks be to God;
For the good all men inherit, thanks be to God;
For the wonders that astound us,
For the truths that still confound us,
Most of all, that love has found us, thanks be to God!



```

- |   -  |
-------------|------------|
Title | For the Fruits of His Creation |
Key |  |
Titles | undefined |
First Line | For the fruits of His creation, thanks be to God; |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
