---
title: 552. The Lord`s My Shepherd
metadata:
    description: 
    keywords: Seventh Day Adventist Hymnal, The Lord`s My Shepherd, , 
    author: Brian Onang'o
---


## 552. THE LORD`S MY SHEPHERD

```txt
1.
The Lord’s my Shepherd, I’ll not want.
He makes me down to lie
In pastures green; He leadeth me
The quiet waters by.

2.
My soul He doth restore again.
And me to walk doth make
Within the paths of righteousness,
E’en for His own name’s sake.

3.
Yea, though I walk in death’s dark vale,
Yet will I fear no ill,
For Thou art with me; and Thy rod
And staff me comfort still.

4.
My table Thou hast furnished
In presence of my foes;
My head Thou dost with oil anoint,
And my cup overflows.

5.
Goodness and mercy all my life
Shall surely follow me;
And in God’s house forevermore
My dwelling place shall be.
```

- |   -  |
-------------|------------|
Title | The Lord`s My Shepherd |
Key |  |
Titles |  |
First Line |  |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas | 5 |
Chorus | No |
Chorus Type | - |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
