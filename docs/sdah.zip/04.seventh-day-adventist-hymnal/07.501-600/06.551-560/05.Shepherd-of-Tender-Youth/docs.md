---
title: 555. Shepherd of Tender Youth - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 555. Shepherd of Tender Youth. 1. Shepherd of tender you, Guiding in love and truth, Through devious way; Christ our triumphant King, We come Thy name to sin, Hither our children bring To shout Thy praise.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Shepherd of Tender Youth, Shepherd of tender you, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 555. SHEPHERD OF TENDER YOUTH
#### Seventh Day Adventist Hymnal

```txt



1.
Shepherd of tender you,
Guiding in love and truth,
Through devious way;
Christ our triumphant King,
We come Thy name to sin,
Hither our children bring
To shout Thy praise.

2.
Thou are our holy Lord,
Thee all subduing Word,
Healer of strife;
Thou didst Thyself abase,
That from sin’s deep disgrace
Thou mightest save our race,
And give us life.

3.
Thou are the great High Priest;
Thou has prepared the feast
Of heavenly love;
While in our mortal pain
None call on Thee in vain;
Help Thou does not disdain,
Help from above.

4.
Ever be Thou our Guide,
Our Shepherd and our pride,
Our staff and song;
Jesus, Thou Christ of God,
By Thy perennial word,
Lead us where Thou hast trod,
Make our faith strong.



```

- |   -  |
-------------|------------|
Title | Shepherd of Tender Youth |
Key |  |
Titles | undefined |
First Line | Shepherd of tender you, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
