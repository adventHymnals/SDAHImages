---
title: 556. As Saints of Old - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 556. As Saints of Old. 1. As saints of old their first fruits brought Of orchard, flock, and field To God the giver all good, The source of bounteous yield; So we today first fruits would bring: The wealth of this good land, Of farm and market, shop and home, Of mind, and heart, and hand.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, As Saints of Old, As saints of old their first fruits brought 
    author: Brian Onang'o
---

#### Advent Hymnals
## 556. AS SAINTS OF OLD
#### Seventh Day Adventist Hymnal

```txt



1.
As saints of old their first fruits brought
Of orchard, flock, and field
To God the giver all good,
The source of bounteous yield;
So we today first fruits would bring:
The wealth of this good land,
Of farm and market, shop and home,
Of mind, and heart, and hand.

2.
A world in need now summons us
To labor, love, and give;
To make our life an offering
To God, that all may live.
The Church of Christ is calling us
To make the dream come true:
A world redeemed by Christ-like love;
All life in Christ made new.

3.
In gratitude and humble trust
We bring our best today,
To serve Your cause and share Your love
With all along life’s way.
O God, who gave yourself to us
In Jesus Christ Your Son,
Teach us to give ourselves each day
Until life’s work is done.



```

- |   -  |
-------------|------------|
Title | As Saints of Old |
Key |  |
Titles | undefined |
First Line | As saints of old their first fruits brought |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
