---
title: 553. Jesus, Guide Our Way - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 553. Jesus, Guide Our Way. 1. Jesus, guide our way To eternal day: So shall we, no more delaying, Follow Thee, Thy voice obeying: Lead us by the hand To our Father’s land.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Jesus, Guide Our Way, Jesus, guide our way 
    author: Brian Onang'o
---

#### Advent Hymnals
## 553. JESUS, GUIDE OUR WAY
#### Seventh Day Adventist Hymnal

```txt



1.
Jesus, guide our way
To eternal day:
So shall we, no more delaying,
Follow Thee, Thy voice obeying:
Lead us by the hand
To our Father’s land.

2.
When we danger meet
Steadfast make our feet;
Lord, preserve us uncomplaining
Mid the darkness round us reigning:
Through adversity lies our way to Thee.

3.
Order all our way
Through the mortal day:
In our toil, with aid be near us:
In our need, with succour cheer us:
Till we safely stand
In our Father’s land.



```

- |   -  |
-------------|------------|
Title | Jesus, Guide Our Way |
Key |  |
Titles | undefined |
First Line | Jesus, guide our way |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
