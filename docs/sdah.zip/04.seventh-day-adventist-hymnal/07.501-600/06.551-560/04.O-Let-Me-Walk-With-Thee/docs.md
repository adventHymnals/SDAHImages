---
title: 554. O Let Me Walk With Thee - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 554. O Let Me Walk With Thee. 1. O let me walk with Thee, my God, As Enoch walked in days of old; Place Thou my trembling hand in Thine, And sweet communion with me hold; E’en though the path I may not see, Yet, Jesus, let me walk with Thee.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, O Let Me Walk With Thee, O let me walk with Thee, my God, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 554. O LET ME WALK WITH THEE
#### Seventh Day Adventist Hymnal

```txt



1.
O let me walk with Thee, my God,
As Enoch walked in days of old;
Place Thou my trembling hand in Thine,
And sweet communion with me hold;
E’en though the path I may not see,
Yet, Jesus, let me walk with Thee.

2.
I cannot, dare not, walk alone;
The tempest rages in the sky,
A thousand snares beset my feet,
A thousand foes are lurking nigh.
Still Thou the raging of the sea,
O Master! let me walk with Thee.

3.
If I may rest my hand in Thine,
I’ll count the joys of earth but loss,
And firmly, bravely journey on;
I’ll bear the banner of the cross
Till Zion’s glorious gates I see;
Yet, Savior, let me walk with Thee.



```

- |   -  |
-------------|------------|
Title | O Let Me Walk With Thee |
Key |  |
Titles | undefined |
First Line | O let me walk with Thee, my God, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
