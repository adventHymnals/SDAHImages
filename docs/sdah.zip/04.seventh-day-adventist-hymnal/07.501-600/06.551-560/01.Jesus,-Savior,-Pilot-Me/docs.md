---
title: 551. Jesus, Savior, Pilot Me - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 551. Jesus, Savior, Pilot Me. 1. Jesus, Savior, pilot me over life’s tempestuous sea; unknown waves before me roll, hiding rock and treacherous shoal. Chart and compass come from thee; Jesus, Savior, pilot me.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Jesus, Savior, Pilot Me, Jesus, Savior, pilot me 
    author: Brian Onang'o
---

#### Advent Hymnals
## 551. JESUS, SAVIOR, PILOT ME
#### Seventh Day Adventist Hymnal

```txt



1.
Jesus, Savior, pilot me
over life’s tempestuous sea;
unknown waves before me roll,
hiding rock and treacherous shoal.
Chart and compass come from thee;
Jesus, Savior, pilot me.

2.
As a mother stills her child,
thou canst hush the ocean wild;
boisterous waves obey thy will,
when thou sayest to them, “Be still!”
Wondrous sovreign of the sea,
Jesus, Savior, pilot me.

3.
When at last I near the shore,
and the fearful breakers roar
‘twixt me and the peaceful rest,
then, while leaning on thy breast,
may I hear thee say to me,
“Fear not, I will pilot thee.



```

- |   -  |
-------------|------------|
Title | Jesus, Savior, Pilot Me |
Key |  |
Titles | undefined |
First Line | Jesus, Savior, pilot me |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
