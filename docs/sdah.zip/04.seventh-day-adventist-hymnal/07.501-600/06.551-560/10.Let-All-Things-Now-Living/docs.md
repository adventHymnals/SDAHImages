---
title: 560. Let All Things Now Living - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 560. Let All Things Now Living. 1. Let all things now living a song of thanksgiving To God the Creator triumphantly raise, Who fashioned and made us, protected and stayed us, Who guideth us on to the end of our days. His banners are o’er us, His light goes before us, A pillar of fire shining forth in the night, ‘Til shadows have vanished and darkness is banished, as forward we travel from light into light.
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Let All Things Now Living, Let all things now living a song of thanksgiving 
    author: Brian Onang'o
---

#### Advent Hymnals
## 560. LET ALL THINGS NOW LIVING
#### Seventh Day Adventist Hymnal

```txt



1.
Let all things now living a song of thanksgiving
To God the Creator triumphantly raise,
Who fashioned and made us, protected and stayed us,
Who guideth us on to the end of our days.
His banners are o’er us,
His light goes before us,
A pillar of fire shining forth in the night,
‘Til shadows have vanished and darkness is banished,
as forward we travel from light into light.

2.
His law He enforces: the stars in their courses,
The sun in His orbit, obediently shine;
The hills and the mountains, the rivers and fountains,
The deeps of the ocean proclaim Him divine,
We too should be voicing our love and rejoicing,
With glad adoration a song let us raise,
‘Til all things now living unite in thanksgiving
To God in the highest, hosanna and praise.



```

- |   -  |
-------------|------------|
Title | Let All Things Now Living |
Key |  |
Titles | undefined |
First Line | Let all things now living a song of thanksgiving |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
