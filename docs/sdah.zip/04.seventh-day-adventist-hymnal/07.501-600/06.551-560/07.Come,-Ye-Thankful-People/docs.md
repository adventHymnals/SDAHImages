---
title: 557. Come, Ye Thankful People - Seventh Day Adventist Hymnal
metadata:
    description: |
      SDAH 557. Come, Ye Thankful People. 1. Come, ye thankful people, come, Raise the song of harvest home; All is safely gathered in, Ere the winter storms begin. God our Maker doth provide For our wants to be supplied; Come to God’s own temple, come; Raise the song of harvest home!
    keywords:  |
      SDAH, Seventh Day Adventist Hymnal, adventhymnals, advent hymnals, Come, Ye Thankful People, Come, ye thankful people, come, 
    author: Brian Onang'o
---

#### Advent Hymnals
## 557. COME, YE THANKFUL PEOPLE
#### Seventh Day Adventist Hymnal

```txt



1.
Come, ye thankful people, come,
Raise the song of harvest home;
All is safely gathered in,
Ere the winter storms begin.
God our Maker doth provide
For our wants to be supplied;
Come to God’s own temple, come;
Raise the song of harvest home!

2.
We ourselves are God’s own field,
Fruit unto His praise to yield;
Wheat and tares together sown,
Unto joy or sorrow grown;
First the blade and then the ear,
Then the full corn shall appear;
Grant, O harvest Lord, that we
Wholesome grain and pure may be.

3.
For the Lord our God shall come,
And shall take His harvest home;
From His field shall purge away
All that doth offend, that day;
Give His angels charge at last
In the fire the tares to cast;
But the fruitful ears to store
In His garner evermore.

4.
Then, thou church triumphant, come,
Raise the song of harvest home;
All are safely gathered in,
Free from sorrow, free from sin,
There, forever purified,
In God’s garner to abide;
Come, ten thousand angels, come,
Raise the glorious harvest home!



```

- |   -  |
-------------|------------|
Title | Come, Ye Thankful People |
Key |  |
Titles | undefined |
First Line | Come, ye thankful people, come, |
Author | 
Year | 
Composer|  |
Hymnal|  - |
Tune|  |
Metrical pattern | |
# Stanzas |  |
Chorus |  |
Chorus Type |  |
Subjects |  |
Texts |  |
Print Texts | 
Scripture Song |  |
  
